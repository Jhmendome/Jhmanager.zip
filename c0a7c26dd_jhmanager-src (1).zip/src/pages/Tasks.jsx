import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, ListChecks, CheckSquare, CheckCircle2, Circle, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useI18n } from "@/lib/i18n";
import TaskForm from "@/components/tasks/TaskForm";
import TaskItem from "@/components/tasks/TaskItem";
import ExportMenu from "@/components/ExportMenu";
import BulkActionBar from "@/components/common/BulkActionBar";
import { expandRecurrence } from "@/lib/recurrence";

const TASK_COLUMNS = [
  { key: "title", label: "Titre" },
  { key: "status", label: "Statut" },
  { key: "priority", label: "Priorité" },
  { key: "start", label: "Début", type: "date" },
  { key: "end", label: "Fin", type: "date" },
  { key: "duration_minutes", label: "Durée (min)" },
];

const FILTERS = [
  { value: "toutes", key: "tasks.filter.all" },
  { value: "a_faire", key: "tasks.filter.todo" },
  { value: "en_cours", key: "tasks.filter.progress" },
  { value: "terminee", key: "tasks.filter.done" },
];

const PAGE_SIZE = 100;

export default function Tasks() {
  const { t } = useI18n();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("toutes");
  const [formOpen, setFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => {
    const list = await base44.entities.Task.list("-start", 300);
    setTasks(list);
    setLoading(false);
  };

  useEffect(() => { register(load); });
  useEffect(() => { load(); }, []);

  const handleSave = async (data, recurrence) => {
    if (editingTask) {
      const prev = tasks;
      setTasks((cur) => cur.map((task) => (task.id === editingTask.id ? { ...task, ...data } : task)));
      try {
        await base44.entities.Task.update(editingTask.id, data);
        toast({ title: t("toast.taskUpdated") });
        load();
      } catch (err) {
        setTasks(prev);
        toast({ title: t("toast.error"), description: t("err.update"), variant: "destructive" });
      }
    } else {
      const items = expandRecurrence(data, recurrence?.frequency, recurrence?.count, ["start", "end"]);
      const tempIds = items.map(() => `tmp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
      setTasks((cur) => [...items.map((it, i) => ({ ...it, id: tempIds[i] })), ...cur]);
      try {
        await base44.entities.Task.bulkCreate(items);
        toast({ title: recurrence && recurrence.count > 1 ? `${items.length} tâches récurrentes créées` : t("toast.taskCreated") });
        load();
      } catch (err) {
        setTasks((cur) => cur.filter((item) => !tempIds.includes(item.id)));
        toast({ title: t("toast.error"), description: t("err.create"), variant: "destructive" });
      }
    }
    setFormOpen(false);
    setEditingTask(null);
  };

  const handleDelete = async (task) => {
    const prev = tasks;
    setTasks((cur) => cur.filter((item) => item.id !== task.id));
    try {
      await base44.entities.Task.delete(task.id);
      toast({ title: t("toast.taskDeleted") });
      load();
    } catch (err) {
      setTasks(prev);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  const handleToggleDone = async (task) => {
    const newStatus = task.status === "terminee" ? "a_faire" : "terminee";
    const prev = tasks;
    setTasks((cur) => cur.map((item) => (item.id === task.id ? { ...item, status: newStatus } : item)));
    try {
      await base44.entities.Task.update(task.id, { status: newStatus });
      load();
    } catch (err) {
      setTasks(prev);
      toast({ title: t("toast.error"), description: t("err.update"), variant: "destructive" });
    }
  };

  const toggleSelect = (id) => setSelected((s) => {
    const n = new Set(s);
    if (n.has(id)) n.delete(id); else n.add(id);
    return n;
  });
  const exitSelect = () => { setSelectMode(false); setSelected(new Set()); };

  const bulkDelete = async () => {
    const ids = [...selected];
    if (!ids.length) return;
    setBulkBusy(true);
    const prev = tasks;
    setTasks((cur) => cur.filter((t) => !selected.has(t.id)));
    try {
      await base44.entities.Task.deleteMany({ id: { $in: ids } });
      toast({ title: `${ids.length} tâche(s) supprimée(s)` });
      setSelected(new Set()); setBulkBusy(false); load();
    } catch {
      setTasks(prev); setBulkBusy(false);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  const bulkSetStatus = async (status) => {
    const ids = [...selected];
    if (!ids.length) return;
    setBulkBusy(true);
    const prev = tasks;
    setTasks((cur) => cur.map((t) => (selected.has(t.id) ? { ...t, status } : t)));
    try {
      await base44.entities.Task.updateMany({ id: { $in: ids } }, { $set: { status } });
      toast({ title: `${ids.length} tâche(s) mise(s) à jour` });
      setSelected(new Set()); setBulkBusy(false); load();
    } catch {
      setTasks(prev); setBulkBusy(false);
      toast({ title: t("toast.error"), description: t("err.update"), variant: "destructive" });
    }
  };

  const filtered = filter === "toutes" ? tasks : tasks.filter((task) => task.status === filter);
  const sorted = [...filtered].sort((a, b) => new Date(a.start) - new Date(b.start));
  const visible = sorted.slice(0, visibleCount);
  const allSelected = visible.length > 0 && visible.every((t) => selected.has(t.id));
  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(visible.map((t) => t.id)));

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{t("tasks.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("tasks.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2">
          <ExportMenu title="Tâches" subtitle="Liste des tâches" columns={TASK_COLUMNS} rows={sorted} currency="XAF" />
          <Button variant={selectMode ? "secondary" : "outline"} onClick={() => (selectMode ? exitSelect() : setSelectMode(true))}>
            <CheckSquare className="w-4 h-4 mr-2" /> {selectMode ? "Terminer" : "Sélectionner"}
          </Button>
          <Button onClick={() => { setEditingTask(null); setFormOpen(true); }}>
            <Plus className="w-4 h-4 mr-2" /> {t("tasks.new")}
          </Button>
        </div>
      </div>

      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList>
          {FILTERS.map((f) => (
            <TabsTrigger key={f.value} value={f.value}>{t(f.key)}</TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {sorted.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <ListChecks className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">{t("tasks.empty")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {selectMode && (
            <BulkActionBar
              count={selected.size}
              total={visible.length}
              allSelected={allSelected}
              onToggleAll={toggleAll}
              onClear={exitSelect}
              busy={bulkBusy}
            >
              <Button size="sm" variant="outline" onClick={() => bulkSetStatus("terminee")} disabled={!selected.size || bulkBusy}>
                <CheckCircle2 className="w-4 h-4 mr-1" /> Terminer
              </Button>
              <Button size="sm" variant="outline" onClick={() => bulkSetStatus("a_faire")} disabled={!selected.size || bulkBusy}>
                <Circle className="w-4 h-4 mr-1" /> À faire
              </Button>
              <Button size="sm" variant="destructive" onClick={bulkDelete} disabled={!selected.size || bulkBusy}>
                <Trash2 className="w-4 h-4 mr-1" /> Supprimer
              </Button>
            </BulkActionBar>
          )}
          {visible.map((task) => (
            <TaskItem
              key={task.id}
              task={task}
              selectable={selectMode}
              selected={selected.has(task.id)}
              onToggleSelect={toggleSelect}
              onEdit={(item) => { if (selectMode) return; setEditingTask(item); setFormOpen(true); }}
              onDelete={handleDelete}
              onToggleDone={selectMode ? () => toggleSelect(task.id) : handleToggleDone}
            />
          ))}
          {visibleCount < sorted.length && (
            <Button variant="outline" className="w-full" onClick={() => setVisibleCount((c) => c + PAGE_SIZE)}>
              {t("tasks.loadMore", { n: sorted.length - visibleCount })}
            </Button>
          )}
        </div>
      )}

      <TaskForm open={formOpen} onOpenChange={setFormOpen} task={editingTask} onSubmit={handleSave} />
    </div>
  );
}