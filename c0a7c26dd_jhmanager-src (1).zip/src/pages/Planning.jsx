import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { CalendarRange, CalendarClock, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import { formatDateFr } from "@/lib/format";
import TaskItem from "@/components/tasks/TaskItem";
import TaskForm from "@/components/tasks/TaskForm";
import EventItem from "@/components/events/EventItem";
import EventForm from "@/components/events/EventForm";

function overlaps(a, b) {
  return new Date(a.start) < new Date(b.end) && new Date(b.start) < new Date(a.end);
}

const PAGE_SIZE = 100;

export default function Planning() {
  const { t } = useI18n();
  const { space, activeCompanyId } = useSpace();
  const [tasks, setTasks] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [taskFormOpen, setTaskFormOpen] = useState(false);
  const [eventFormOpen, setEventFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [editingEvent, setEditingEvent] = useState(null);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => {
    try {
      const [taskList, eventList] = await Promise.all([
        base44.entities.Task.list("start", 300),
        base44.entities.Event.list("start", 300),
      ]);
      setTasks((taskList || []).filter((task) => task.status !== "terminee"));
      const scopedEvents = space === "jpm"
        ? (eventList || [])
        : (eventList || []).filter((e) => !activeCompanyId || e.company_id === activeCompanyId);
      setEvents(scopedEvents);
    } catch { /* ignore */ }
    setLoading(false);
  };

  useEffect(() => { register(load); });
  useEffect(() => { setLoading(true); setVisibleCount(PAGE_SIZE); load(); }, [space, activeCompanyId]);

  const handleToggleDone = async (task) => {
    const prev = tasks;
    setTasks((cur) => cur.filter((item) => item.id !== task.id));
    try {
      await base44.entities.Task.update(task.id, { status: "terminee" });
      toast({ title: t("toast.taskFinished") });
      load();
    } catch (err) {
      setTasks(prev);
      toast({ title: t("toast.error"), description: t("err.update"), variant: "destructive" });
    }
  };

  const handleTaskSave = async (data) => {
    if (editingTask) {
      const prev = tasks;
      setTasks((cur) => cur.map((item) => (item.id === editingTask.id ? { ...item, ...data } : item)));
      try {
        await base44.entities.Task.update(editingTask.id, data);
        toast({ title: t("toast.taskUpdated") });
        load();
      } catch (err) {
        setTasks(prev);
        toast({ title: t("toast.error"), description: t("err.modify"), variant: "destructive" });
      }
    }
    setTaskFormOpen(false);
    setEditingTask(null);
  };

  const handleTaskDelete = async (task) => {
    const prev = tasks;
    setTasks((cur) => cur.filter((item) => item.id !== task.id));
    try {
      await base44.entities.Task.delete(task.id);
      toast({ title: t("toast.taskDeleted") });
      load();
    } catch (err) {
      setTasks(prev);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  const handleEventSave = async (data) => {
    if (editingEvent) {
      const prev = events;
      setEvents((cur) => cur.map((i) => (i.id === editingEvent.id ? { ...i, ...data } : i)));
      try {
        await base44.entities.Event.update(editingEvent.id, data);
        toast({ title: "Événement mis à jour" });
        load();
      } catch {
        setEvents(prev);
        toast({ title: "Erreur", description: "Modification impossible.", variant: "destructive" });
      }
    } else {
      const payload = space === "jpm" ? data : { ...data, company_id: activeCompanyId };
      const tempId = `tmp_${Date.now()}`;
      setEvents((cur) => [{ ...payload, id: tempId }, ...cur]);
      try {
        await base44.entities.Event.create(payload);
        toast({ title: "Événement créé" });
        load();
      } catch {
        setEvents((cur) => cur.filter((i) => i.id !== tempId));
        toast({ title: "Erreur", description: "Création impossible.", variant: "destructive" });
      }
    }
    setEventFormOpen(false);
    setEditingEvent(null);
  };

  const handleEventDelete = async (ev) => {
    const prev = events;
    setEvents((cur) => cur.filter((i) => i.id !== ev.id));
    try {
      await base44.entities.Event.delete(ev.id);
      toast({ title: "Événement supprimé" });
      load();
    } catch {
      setEvents(prev);
      toast({ title: "Erreur", description: "Suppression impossible.", variant: "destructive" });
    }
  };

  const combined = useMemo(() => {
    const items = [
      ...tasks.map((tk) => ({ kind: "task", item: tk })),
      ...events.map((ev) => ({ kind: "event", item: ev })),
    ];
    return items.sort((a, b) => new Date(a.item.start) - new Date(b.item.start));
  }, [tasks, events]);

  const conflictIds = useMemo(() => {
    const ids = new Set();
    for (let i = 0; i < combined.length; i++) {
      for (let j = i + 1; j < combined.length; j++) {
        if (overlaps(combined[i].item, combined[j].item)) {
          ids.add(combined[i].item.id);
          ids.add(combined[j].item.id);
        }
      }
    }
    return ids;
  }, [combined]);

  const groups = useMemo(() => {
    const visible = combined.slice(0, visibleCount);
    return visible.reduce((acc, entry) => {
      const key = new Date(entry.item.start).toDateString();
      acc[key] = acc[key] || [];
      acc[key].push(entry);
      return acc;
    }, {});
  }, [combined, visibleCount]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-3xl">{t("planning.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("planning.subtitle")}</p>
          {conflictIds.size > 0 && (
            <p className="text-sm text-destructive mt-2">{t("planning.conflictWarn", { n: conflictIds.size })}</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => { setEditingEvent(null); setEventFormOpen(true); }}>
            <CalendarClock className="w-4 h-4 mr-2" /> Événement
          </Button>
          <Button onClick={() => { setEditingTask(null); setTaskFormOpen(true); }}>
            <Plus className="w-4 h-4 mr-2" /> {t("tasks.new")}
          </Button>
        </div>
      </div>

      {combined.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <CalendarRange className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">{t("planning.empty")}</p>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(groups).map(([day, dayItems]) => (
            <div key={day}>
              <h2 className="text-sm font-medium text-muted-foreground mb-2">{formatDateFr(dayItems[0].item.start)}</h2>
              <div className="space-y-2">
                {dayItems.map((entry) => entry.kind === "task" ? (
                  <TaskItem
                    key={entry.item.id}
                    task={entry.item}
                    onEdit={(item) => { setEditingTask(item); setTaskFormOpen(true); }}
                    onDelete={handleTaskDelete}
                    onToggleDone={handleToggleDone}
                    conflict={conflictIds.has(entry.item.id)}
                  />
                ) : (
                  <EventItem
                    key={entry.item.id}
                    event={entry.item}
                    onEdit={(item) => { setEditingEvent(item); setEventFormOpen(true); }}
                    onDelete={handleEventDelete}
                    conflict={conflictIds.has(entry.item.id)}
                  />
                ))}
              </div>
            </div>
          ))}
          {visibleCount < combined.length && (
            <Button variant="outline" className="w-full" onClick={() => setVisibleCount((c) => c + PAGE_SIZE)}>
              {t("planning.loadMore", { n: combined.length - visibleCount })}
            </Button>
          )}
        </div>
      )}

      <TaskForm open={taskFormOpen} onOpenChange={setTaskFormOpen} task={editingTask} onSubmit={handleTaskSave} />
      <EventForm open={eventFormOpen} onOpenChange={setEventFormOpen} event={editingEvent} onSubmit={handleEventSave} />
    </div>
  );
}