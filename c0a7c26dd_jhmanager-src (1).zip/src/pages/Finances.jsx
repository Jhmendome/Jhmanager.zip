import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, PiggyBank, CheckSquare, Trash2, Tag, Landmark, Percent, Wallet, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useSpace } from "@/lib/SpaceContext";
import { useI18n } from "@/lib/i18n";
import ExpenseForm from "@/components/finances/ExpenseForm";
import ExpenseItem from "@/components/finances/ExpenseItem";
import BulkActionBar from "@/components/common/BulkActionBar";
import PeriodPicker from "@/components/common/PeriodPicker";
import SavingsPlanList from "@/components/finances/SavingsPlanList";
import SavingsPlanForm from "@/components/finances/SavingsPlanForm";
import GainsPanel from "@/components/finances/GainsPanel";
import Loans from "@/pages/Loans";
import Taxes from "@/pages/Taxes";
import { expandRecurrence } from "@/lib/recurrence";
import { daysInPeriod, periodLabel, customOf } from "@/lib/periods";
import { formatCurrency } from "@/lib/format";
import ExportMenu from "@/components/ExportMenu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const PAGE_SIZE = 100;

export default function Finances() {
  const { t } = useI18n();
  const [expenses, setExpenses] = useState([]);
  const [savings, setSavings] = useState([]);
  const [taxesJpm, setTaxesJpm] = useState([]);
  const [activeLoans, setActiveLoans] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("depenses");
  const [formOpen, setFormOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);
  const [budgetOpen, setBudgetOpen] = useState(false);
  const [budgetInput, setBudgetInput] = useState("");
  const [budgetPeriod, setBudgetPeriod] = useState("mois");
  const [budgetCustomCount, setBudgetCustomCount] = useState("");
  const [budgetCustomUnit, setBudgetCustomUnit] = useState("jour");
  const [savingsOpen, setSavingsOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [fCat, setFCat] = useState("all");
  const [fPeriod, setFPeriod] = useState("all");
  const [fSort, setFSort] = useState("desc");
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkCat, setBulkCat] = useState("");
  const { toast } = useToast();
  const { register } = useRefresh();
  const { space, activeCompanyId } = useSpace();

  const load = async () => {
    const [e, s, p, tx, ln] = await Promise.all([
      base44.entities.Expense.list("-date", 300),
      base44.entities.SavingsPlan.list("-created_date", 200).catch(() => []),
      base44.entities.Preferences.list(),
      base44.entities.Tax.list("-created_date", 500).catch(() => []),
      base44.entities.Loan.list("-created_date", 200).catch(() => []),
    ]);
    setExpenses(e);
    setSavings(s || []);
    setPreferences(p?.[0] || null);
    setTaxesJpm((tx || []).filter((t) =>
      space === "jpm"
        ? t.scope === "jpm"
        : (t.scope === "jbm" && (!activeCompanyId || t.company_id === activeCompanyId))
    ));
    setActiveLoans((ln || []).filter((l) => l.status === "en_cours"));
    setLoading(false);
  };

  useEffect(() => { register(load); });
  useEffect(() => { load(); }, [space, activeCompanyId]);
  // Recalcul automatique du reste budgétaire dès qu'une taxe ou un emprunt change.
  useEffect(() => {
    const trySub = (entity, cb) => (typeof entity?.subscribe === "function" ? entity.subscribe(cb) : () => {});
    const unsubTax = trySub(base44.entities.Tax, () => load());
    const unsubLoan = trySub(base44.entities.Loan, () => load());
    return () => { unsubTax?.(); unsubLoan?.(); };
  }, []);

  const currency = preferences?.currency || "XAF";
  const budget = preferences?.initial_budget || 0;
  const bp = preferences?.budget_period || "mois";
  const bpCustom = { count: preferences?.budget_custom_count, unit: preferences?.budget_custom_unit };
  const budgetDays = daysInPeriod(bp, new Date(), bpCustom);
  const dailyBudget = budgetDays > 0 ? budget / budgetDays : 0;
  const totalExpense = expenses.reduce((sum, e) => sum + (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0), 0);

  const activePlans = savings.filter((p) => p.status !== "archive");
  const savingsForBudget = activePlans.reduce((acc, p) => {
    const pDays = daysInPeriod(p.period, new Date(p.start_date || Date.now()), customOf(p));
    const daily = pDays > 0 ? (Number(p.target_amount) || 0) / pDays : 0;
    return acc + daily * budgetDays;
  }, 0);
  const taxBurden = taxesJpm.reduce((s, t) => s + (Number(t.amount) || 0), 0);
  const loanBurden = activeLoans.reduce((s, l) => s + (Number(l.monthly_payment) || 0), 0) * (budgetDays / 30.44);
  const reste = budget - totalExpense - savingsForBudget - taxBurden - loanBurden;
  const dailyAvailable = budgetDays > 0 ? reste / budgetDays : 0;

  const categories = useMemo(
    () => [...new Set(expenses.map((e) => e.category).filter(Boolean))],
    [expenses]
  );
  const filtered = useMemo(() => {
    let list = expenses;
    if (fCat !== "all") list = list.filter((e) => e.category === fCat);
    if (fPeriod !== "all") {
      const now = new Date();
      list = list.filter((e) => {
        const d = new Date(e.date);
        if (fPeriod === "month") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
        if (fPeriod === "30") return d >= new Date(now.getTime() - 30 * 86400000);
        if (fPeriod === "year") return d.getFullYear() === now.getFullYear();
        return true;
      });
    }
    return [...list].sort((a, b) =>
      fSort === "desc" ? new Date(b.date) - new Date(a.date) : new Date(a.date) - new Date(b.date)
    );
  }, [expenses, fCat, fPeriod, fSort]);
  const visible = filtered.slice(0, visibleCount);

  const toggleSelect = (id) => setSelected((s) => {
    const n = new Set(s);
    if (n.has(id)) n.delete(id); else n.add(id);
    return n;
  });
  const allSelected = visible.length > 0 && visible.every((e) => selected.has(e.id));
  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(visible.map((e) => e.id)));
  const exitSelect = () => { setSelectMode(false); setSelected(new Set()); };

  const bulkDelete = async () => {
    const ids = [...selected];
    if (!ids.length) return;
    setBulkBusy(true);
    const prev = expenses;
    setExpenses((cur) => cur.filter((e) => !selected.has(e.id)));
    try {
      await base44.entities.Expense.deleteMany({ id: { $in: ids } });
      toast({ title: `${ids.length} dépense(s) supprimée(s)` });
      setSelected(new Set()); setBulkBusy(false); load();
    } catch {
      setExpenses(prev); setBulkBusy(false);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  const bulkSetCategory = async () => {
    const ids = [...selected];
    if (!ids.length || !bulkCat.trim()) return;
    setBulkBusy(true);
    const prev = expenses;
    const cat = bulkCat.trim();
    setExpenses((cur) => cur.map((e) => (selected.has(e.id) ? { ...e, category: cat } : e)));
    try {
      await base44.entities.Expense.updateMany({ id: { $in: ids } }, { $set: { category: cat } });
      toast({ title: `${ids.length} dépense(s) mise(s) à jour` });
      setSelected(new Set()); setBulkCat(""); setBulkBusy(false); load();
    } catch {
      setExpenses(prev); setBulkBusy(false);
      toast({ title: t("toast.error"), description: t("err.update"), variant: "destructive" });
    }
  };

  const handleSaveExpense = async (data, recurrence) => {
    if (editingExpense) {
      const prev = expenses;
      setExpenses((cur) => cur.map((e) => (e.id === editingExpense.id ? { ...e, ...data } : e)));
      try {
        await base44.entities.Expense.update(editingExpense.id, data);
        toast({ title: t("toast.expenseUpdated") });
        load();
      } catch (err) {
        setExpenses(prev);
        toast({ title: t("toast.error"), description: t("err.modify"), variant: "destructive" });
      }
    } else {
      const items = expandRecurrence(data, recurrence?.frequency, recurrence?.count, ["date"], recurrence?.custom);
      const tempIds = items.map(() => `tmp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
      setExpenses((cur) => [...items.map((it, i) => ({ ...it, id: tempIds[i] })), ...cur]);
      try {
        await base44.entities.Expense.bulkCreate(items);
        toast({ title: recurrence && recurrence.count > 1 ? `${items.length} dépenses récurrentes créées` : t("toast.expenseAdded") });
        load();
      } catch (err) {
        setExpenses((cur) => cur.filter((e) => !tempIds.includes(e.id)));
        toast({ title: t("toast.error"), description: t("err.create"), variant: "destructive" });
      }
    }
    setFormOpen(false);
    setEditingExpense(null);
  };

  const handleDelete = async (expense) => {
    const prev = expenses;
    setExpenses((cur) => cur.filter((e) => e.id !== expense.id));
    try {
      await base44.entities.Expense.delete(expense.id);
      toast({ title: t("toast.expenseDeleted") });
      load();
    } catch (err) {
      setExpenses(prev);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  const handleSaveBudget = async (e) => {
    e.preventDefault();
    const value = parseFloat(budgetInput);
    if (isNaN(value) || value < 0) return;
    const prevPrefs = preferences;
    const customCount = budgetPeriod === "personnalise" ? (parseInt(budgetCustomCount, 10) || 0) : null;
    const customUnit = budgetPeriod === "personnalise" ? budgetCustomUnit : null;
    const optimistic = preferences
      ? { ...preferences, initial_budget: value, budget_period: budgetPeriod, budget_custom_count: customCount, budget_custom_unit: customUnit }
      : { initial_budget: value, budget_period: budgetPeriod, budget_custom_count: customCount, budget_custom_unit: customUnit, currency };
    setPreferences(optimistic);
    setBudgetOpen(false);
    try {
      if (preferences) {
        await base44.entities.Preferences.update(preferences.id, { initial_budget: value, budget_period: budgetPeriod, budget_custom_count: customCount, budget_custom_unit: customUnit });
      } else {
        const created = await base44.entities.Preferences.create({ initial_budget: value, budget_period: budgetPeriod, budget_custom_count: customCount, budget_custom_unit: customUnit, currency });
        setPreferences(created);
      }
      toast({ title: t("toast.budgetUpdated") });
      load();
    } catch (err) {
      setPreferences(prevPrefs);
      toast({ title: t("toast.error"), description: t("err.budget"), variant: "destructive" });
    }
  };

  const createSavingsPlan = async (data) => {
    try {
      await base44.entities.SavingsPlan.create(data);
      toast({ title: "Plan d'épargne créé" });
      setSavingsOpen(false);
      load();
    } catch { toast({ title: t("toast.error"), description: t("err.create"), variant: "destructive" }); }
  };

  const deleteSavingsPlan = async (p) => {
    const prev = savings;
    setSavings((cur) => cur.filter((x) => x.id !== p.id));
    try {
      await base44.entities.SavingsPlan.delete(p.id);
      toast({ title: "Plan supprimé" });
      load();
    } catch {
      setSavings(prev);
      toast({ title: t("toast.error"), variant: "destructive" });
    }
  };

  const togglePlanReached = async (p) => {
    const next = p.status === "atteint" ? "actif" : "atteint";
    setSavings((cur) => cur.map((x) => (x.id === p.id ? { ...x, status: next } : x)));
    try {
      await base44.entities.SavingsPlan.update(p.id, { status: next });
      load();
    } catch {
      setSavings(savings);
      toast({ title: t("toast.error"), variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{t("finances.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("finances.subtitle")}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-card border border-border rounded-2xl p-4">
          <p className="text-sm text-muted-foreground">{t("finances.budget")} <span className="text-xs">· par {periodLabel(bp, bpCustom)}</span></p>
          <p className="font-display text-xl mt-1">{formatCurrency(budget, currency)}</p>
          <p className="text-xs text-muted-foreground mt-1">≈ {formatCurrency(dailyBudget, currency)} / jour · {budgetDays} j</p>
          <button onClick={() => { setBudgetInput(String(budget)); setBudgetPeriod(bp); setBudgetCustomCount(bpCustom.count ? String(bpCustom.count) : ""); setBudgetCustomUnit(bpCustom.unit || "jour"); setBudgetOpen(true); }} className="text-sm text-primary hover:underline mt-2">
            {t("finances.editBudget")}
          </button>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <p className="text-sm text-muted-foreground">{t("finances.totalExpenses")}</p>
          <p className="font-display text-xl mt-1">{formatCurrency(totalExpense, currency)}</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <p className="text-sm text-muted-foreground">Épargne programmée</p>
          <p className="font-display text-xl mt-1">{formatCurrency(savingsForBudget, currency)}</p>
          <p className="text-xs text-muted-foreground mt-1">{activePlans.length} plan(s) actif(s)</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-4">
          <p className="text-sm text-muted-foreground">Reste · budget journalier</p>
          <p className={`font-display text-xl mt-1 ${reste < 0 ? "text-destructive" : ""}`}>{formatCurrency(reste, currency)}</p>
          <p className="text-xs text-muted-foreground mt-1">≈ {formatCurrency(dailyAvailable, currency)} / jour</p>
          <p className="text-xs text-muted-foreground">dont taxes {formatCurrency(taxBurden, currency)} · emprunts {formatCurrency(loanBurden, currency)}</p>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="w-full justify-start overflow-x-auto no-scrollbar">
          <TabsTrigger value="depenses"><Wallet className="w-4 h-4 mr-1.5" />Dépenses</TabsTrigger>
          <TabsTrigger value="epargne"><PiggyBank className="w-4 h-4 mr-1.5" />Épargne</TabsTrigger>
          <TabsTrigger value="emprunts"><Landmark className="w-4 h-4 mr-1.5" />Emprunts</TabsTrigger>
          <TabsTrigger value="taxes"><Percent className="w-4 h-4 mr-1.5" />Taxes</TabsTrigger>
          <TabsTrigger value="gains"><TrendingUp className="w-4 h-4 mr-1.5" />Gains & formules</TabsTrigger>
        </TabsList>

        <TabsContent value="depenses" className="space-y-4">
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <ExportMenu
              title={t("report.expenses")}
              subtitle={t("report.expensesSub")}
              currency={currency}
              rows={expenses.map((e) => ({ ...e, total: (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0) }))}
              columns={[
                { key: "name", label: t("finances.history") },
                { key: "category", label: t("jbm.product.category") },
                { key: "date", label: t("jbm.sale.date"), type: "date" },
                { key: "quantity", label: t("jbm.sale.quantity") },
                { key: "unit_cost", label: t("jbm.product.unitCost"), type: "currency" },
                { key: "total", label: t("finances.totalExpenses"), type: "currency" },
              ]}
              summary={[
                { label: t("finances.budget"), value: formatCurrency(budget, currency) },
                { label: t("finances.totalExpenses"), value: formatCurrency(totalExpense, currency) },
                { label: t("finances.remaining"), value: formatCurrency(reste, currency) },
              ]}
            />
            <Button variant={selectMode ? "secondary" : "outline"} onClick={() => (selectMode ? exitSelect() : setSelectMode(true))}>
              <CheckSquare className="w-4 h-4 mr-2" /> {selectMode ? "Terminer" : "Sélectionner"}
            </Button>
            <Button onClick={() => { setEditingExpense(null); setFormOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" /> {t("finances.add")}
            </Button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Select value={fCat} onValueChange={setFCat}>
              <SelectTrigger className="h-9 w-auto text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes catégories</SelectItem>
                {categories.map((c) => (<SelectItem key={c} value={c}>{c}</SelectItem>))}
              </SelectContent>
            </Select>
            <Select value={fPeriod} onValueChange={setFPeriod}>
              <SelectTrigger className="h-9 w-auto text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toute période</SelectItem>
                <SelectItem value="month">Ce mois</SelectItem>
                <SelectItem value="30">30 derniers jours</SelectItem>
                <SelectItem value="year">Cette année</SelectItem>
              </SelectContent>
            </Select>
            <Select value={fSort} onValueChange={setFSort}>
              <SelectTrigger className="h-9 w-auto text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="desc">Plus récent</SelectItem>
                <SelectItem value="asc">Plus ancien</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            {filtered.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <PiggyBank className="w-8 h-8 mx-auto mb-3 opacity-50" />
                <p className="text-sm">{expenses.length === 0 ? t("finances.empty") : "Aucune dépense ne correspond aux filtres."}</p>
              </div>
            ) : (
              <div className="space-y-2">
                {selectMode && (
                  <BulkActionBar
                    count={selected.size}
                    total={visible.length}
                    allSelected={allSelected}
                    onToggleAll={toggleAll}
                    onClear={exitSelect}
                    busy={bulkBusy}
                  >
                    <div className="flex items-center gap-2">
                      <Select value={bulkCat} onValueChange={setBulkCat}>
                        <SelectTrigger className="h-9 w-40 text-sm"><SelectValue placeholder="Catégorie" /></SelectTrigger>
                        <SelectContent>
                          {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <Button size="sm" variant="outline" onClick={bulkSetCategory} disabled={!selected.size || !bulkCat || bulkBusy}>
                        <Tag className="w-4 h-4 mr-1" /> Appliquer
                      </Button>
                    </div>
                    <Button size="sm" variant="destructive" onClick={bulkDelete} disabled={!selected.size || bulkBusy}>
                      <Trash2 className="w-4 h-4 mr-1" /> Supprimer
                    </Button>
                  </BulkActionBar>
                )}
                {visible.map((e) => (
                  <ExpenseItem
                    key={e.id}
                    expense={e}
                    currency={currency}
                    selectable={selectMode}
                    selected={selected.has(e.id)}
                    onToggleSelect={toggleSelect}
                    onEdit={(exp) => { if (selectMode) return; setEditingExpense(exp); setFormOpen(true); }}
                    onDelete={handleDelete}
                  />
                ))}
                {visibleCount < filtered.length && (
                  <Button variant="outline" className="w-full" onClick={() => setVisibleCount((c) => c + PAGE_SIZE)}>
                    {t("finances.loadMore", { n: filtered.length - visibleCount })}
                  </Button>
                )}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="epargne" className="space-y-4">
          <div className="flex items-center justify-end">
            <Button onClick={() => setSavingsOpen(true)}><Plus className="w-4 h-4 mr-2" /> Nouveau plan</Button>
          </div>
          <SavingsPlanList
            plans={activePlans}
            currency={currency}
            onDelete={deleteSavingsPlan}
            onToggleReached={togglePlanReached}
          />
        </TabsContent>

        <TabsContent value="emprunts">
          <Loans />
        </TabsContent>

        <TabsContent value="taxes">
          <Taxes scope={space} />
        </TabsContent>

        <TabsContent value="gains">
          <GainsPanel currency={currency} />
        </TabsContent>
      </Tabs>

      <ExpenseForm open={formOpen} onOpenChange={setFormOpen} expense={editingExpense} onSubmit={handleSaveExpense} />

      <SavingsPlanForm open={savingsOpen} onOpenChange={setSavingsOpen} onSubmit={createSavingsPlan} currency={currency} />

      <Dialog open={budgetOpen} onOpenChange={setBudgetOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-display">{t("finances.setBudget")}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSaveBudget} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="budget">{t("finances.budgetLabel", { currency })}</Label>
              <Input id="budget" type="number" min="0" step="any" value={budgetInput} onChange={(e) => setBudgetInput(e.target.value)} autoFocus />
            </div>
            <PeriodPicker
              period={budgetPeriod}
              customCount={budgetCustomCount}
              customUnit={budgetCustomUnit}
              onChange={({ period, customCount, customUnit }) => { setBudgetPeriod(period); setBudgetCustomCount(customCount); setBudgetCustomUnit(customUnit); }}
              label="Période du budget"
              id="budget-period"
            />
            {budgetPeriod !== "personnalise" && (
              <p className="text-xs text-muted-foreground">
                Budget journalier : ≈ {formatCurrency((parseFloat(budgetInput) || 0) / (daysInPeriod(budgetPeriod, new Date(), { count: budgetCustomCount, unit: budgetCustomUnit }) || 1), currency)}
              </p>
            )}
            <DialogFooter>
              <Button type="submit" className="w-full">{t("common.save")}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}