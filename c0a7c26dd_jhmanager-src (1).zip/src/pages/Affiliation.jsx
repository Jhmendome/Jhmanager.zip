import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Gift, Copy, Check, Loader2, Users, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { formatCurrency, formatDateFr } from "@/lib/format";

const genCode = () => "JM" + Math.random().toString(36).slice(2, 8).toUpperCase();

export default function Affiliation() {
  const { toast } = useToast();
  const [affiliate, setAffiliate] = useState(null);
  const [commissions, setCommissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [phone, setPhone] = useState("");
  const [provider, setProvider] = useState("airtel");
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const list = await base44.entities.Affiliate.list("-created_date", 10);
        const aff = list?.[0] || null;
        setAffiliate(aff);
        if (aff) {
          const coms = await base44.entities.Commission.list("-paid_at", 200);
          setCommissions(coms || []);
        }
      } catch (e) {
        setAffiliate(null);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const createAffiliate = async (e) => {
    e.preventDefault();
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 6) {
      toast({ title: "Numéro invalide", description: "Entrez un numéro d'au moins 6 chiffres.", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      const created = await base44.entities.Affiliate.create({
        referral_code: genCode(),
        phone_number: "+241" + digits,
        provider,
        status: "actif",
      });
      setAffiliate(created);
      toast({ title: "Bienvenue affilié !", description: "Votre lien d'affiliation est prêt." });
    } catch (err) {
      toast({ title: "Erreur", description: err?.message || "Création impossible", variant: "destructive" });
    }
    setCreating(false);
  };

  const link = affiliate ? `${window.location.origin}/register?ref=${affiliate.referral_code}` : "";
  const totalEarned = commissions.reduce((s, c) => s + (Number(c.amount) || 0), 0);
  const referralsCount = new Set(commissions.map((c) => c.referred_user_email).filter(Boolean)).size;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* ignore */
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!affiliate) {
    return (
      <div className="space-y-6 max-w-lg mx-auto">
        <div>
          <h1 className="font-display text-3xl">Devenir affilié</h1>
          <p className="text-muted-foreground mt-1">
            Inscrivez-vous comme affilié, partagez votre lien et gagnez 20 % du montant de chaque
            abonnement souscrit via votre lien (particulier 5 000 → 1 000 XAF, entreprise 20 000 → 4 000 XAF, etc.).
          </p>
        </div>
        <form onSubmit={createAffiliate} className="bg-card border border-border rounded-2xl p-5 space-y-4">
          <div className="space-y-2">
            <Label>Opérateur Mobile Money</Label>
            <Select value={provider} onValueChange={setProvider}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="airtel">Airtel Money</SelectItem>
                <SelectItem value="moov">Moov Money</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="aff-phone">Numéro Mobile Money</Label>
            <div className="flex items-center gap-2">
              <span className="px-3 h-9 inline-flex items-center rounded-md border border-input bg-muted text-sm shrink-0">+241</span>
              <Input id="aff-phone" type="tel" inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="60367591" />
            </div>
            <p className="text-xs text-muted-foreground">Vos commissions seront versées sur ce numéro.</p>
          </div>
          <Button type="submit" disabled={creating} className="w-full">
            {creating ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Traitement…</> : "S'inscrire comme affilié"}
          </Button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl">Mon espace affiliation</h1>
        <p className="text-muted-foreground mt-1">Partagez votre lien et touchez 20 % de chaque abonnement parrainé.</p>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 space-y-3">
        <div className="flex items-center gap-2">
          <Gift className="w-5 h-5 text-accent" />
          <h2 className="font-display text-lg">Votre lien d'affiliation</h2>
        </div>
        <div className="flex items-center gap-2">
          <Input readOnly value={link} className="font-mono text-xs" />
          <Button onClick={copyLink} variant="outline" className="shrink-0">
            {copied ? <><Check className="w-4 h-4 mr-1" /> Copié</> : <><Copy className="w-4 h-4 mr-1" /> Copier</>}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">Code : <span className="font-mono">{affiliate.referral_code}</span></p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-2"><Users className="w-4 h-4 text-muted-foreground" /><p className="text-sm text-muted-foreground">Filleuls</p></div>
          <p className="font-display text-2xl">{referralsCount}</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-2"><Wallet className="w-4 h-4 text-muted-foreground" /><p className="text-sm text-muted-foreground">Gains cumulés</p></div>
          <p className="font-display text-2xl">{formatCurrency(totalEarned, "XAF")}</p>
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5">
        <h2 className="font-display text-lg mb-3">Commissions</h2>
        {commissions.length === 0 ? (
          <p className="text-sm text-muted-foreground">Aucune commission pour l'instant. Partagez votre lien !</p>
        ) : (
          <div className="space-y-2">
            {commissions.map((c) => (
              <div key={c.id} className="flex items-center justify-between border border-border rounded-lg p-3 text-sm">
                <div className="min-w-0">
                  <p className="font-medium truncate">{c.referred_user_email || "Filleul"}</p>
                  <p className="text-xs text-muted-foreground">{c.account_type === "entreprise" ? "Entreprise" : "Particulier"} · {c.paid_at ? formatDateFr(c.paid_at, true) : "—"}</p>
                </div>
                <p className="font-medium text-accent-foreground shrink-0">{formatCurrency(c.amount, "XAF")}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}