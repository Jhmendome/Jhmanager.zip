import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Building2, Check, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BUSINESS_TYPES } from "@/lib/businessTypes";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import { useAuth } from "@/lib/AuthContext";
import SubscribeDialog from "@/components/onboarding/SubscribeDialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const empty = { name: "", business_type: "", location: "", sector: "", address: "", phone: "", email: "", tax_id: "" };
const PRICE_PER_COMPANY = 20000;

export default function Companies() {
  const { t } = useI18n();
  const { user } = useAuth();
  const { companies, activeCompanyId, setActiveCompanyId, refreshCompanies } = useSpace();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [delTarget, setDelTarget] = useState(null);
  const [payPlan, setPayPlan] = useState(null);
  const [allowedCount, setAllowedCount] = useState(1);
  const { toast } = useToast();
  const isAdmin = user?.role === "admin";

  useEffect(() => {
    refreshCompanies();
    (async () => {
      try {
        const subs = await base44.entities.Subscription.list("-paid_at", 50);
        const mine = (subs || []).filter((s) => s.account_type === "entreprise" && s.status === "payee");
        const cnt = mine.length ? Math.max(...mine.map((s) => Number(s.companies_count) || 1)) : 1;
        setAllowedCount(cnt);
      } catch {
        setAllowedCount(1);
      }
    })();
  }, []);

  const openNew = () => {
    if (!isAdmin && companies.length >= allowedCount) {
      setPayPlan({ type: "entreprise", label: "Ajouter une entreprise", unitPrice: PRICE_PER_COMPANY });
      return;
    }
    setEditing(null); setForm(empty); setOpen(true);
  };
  const openEdit = (c) => { setEditing(c); setForm({ name: c.name || "", business_type: c.business_type || "", location: c.location || "", sector: c.sector || "", address: c.address || "", phone: c.phone || "", email: c.email || "", tax_id: c.tax_id || "" }); setOpen(true); };

  const save = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.business_type || !form.location.trim()) return;
    try {
      if (editing) {
        await base44.entities.Company.update(editing.id, form);
        toast({ title: t("toast.taskUpdated") });
      } else {
        await base44.entities.Company.create(form);
        toast({ title: t("toast.expenseAdded") });
      }
      refreshCompanies();
      setOpen(false);
    } catch (err) {
      toast({ title: t("toast.error"), description: t("err.save"), variant: "destructive" });
    }
  };

  const remove = async (c) => {
    try {
      await base44.entities.Company.delete(c.id);
      toast({ title: t("toast.taskDeleted") });
      refreshCompanies();
    } catch (e) {
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
    setDelTarget(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{t("jbm.companies.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("jbm.companies.subtitle")}</p>
        </div>
        <Button onClick={openNew}>
          <Plus className="w-4 h-4 mr-2" /> {t("jbm.companies.new")}
        </Button>
      </div>

      {!isAdmin && (
        <div className="text-xs text-muted-foreground bg-secondary/60 border border-border rounded-lg px-3 py-2">
          Entreprises : {companies.length} / {allowedCount}
          {companies.length >= allowedCount && ` — ajouter une entreprise coûte ${PRICE_PER_COMPANY.toLocaleString("fr-FR")} XAF (débit Mobile Money) et donne accès à toutes les fonctions JBM pour la nouvelle entreprise.`}
        </div>
      )}
      {companies.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Building2 className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">{t("jbm.companies.empty")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {companies.map((c) => (
            <div key={c.id} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
              <button onClick={() => setActiveCompanyId(c.id)} className="flex items-center gap-3 min-w-0 text-left">
                <span className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${activeCompanyId === c.id ? "bg-primary text-primary-foreground" : "border border-border"}`}>
                  {activeCompanyId === c.id && <Check className="w-3 h-3" />}
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{c.name}</p>
                  <p className="text-xs text-muted-foreground">{[c.business_type, c.location].filter(Boolean).join(" • ") || c.sector || t("common.other")}</p>
                </div>
              </button>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => openEdit(c)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDelTarget(c)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="font-display">{editing ? t("jbm.companies.edit") : t("jbm.companies.new")}</DialogTitle></DialogHeader>
          <form onSubmit={save} className="space-y-3">
            <div className="space-y-2"><Label>{t("jbm.companies.name")}</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Type d'entreprise *</Label>
                <Select value={form.business_type} onValueChange={(v) => setForm({ ...form, business_type: v })}>
                  <SelectTrigger><SelectValue placeholder="Sélectionner…" /></SelectTrigger>
                  <SelectContent>{BUSINESS_TYPES.map((bt) => <SelectItem key={bt} value={bt}>{bt}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>Lieu *</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Ville / quartier" /></div>
            </div>
            <div className="space-y-2"><Label>{t("jbm.companies.sector")}</Label><Input value={form.sector} onChange={(e) => setForm({ ...form, sector: e.target.value })} /></div>
            <div className="space-y-2"><Label>{t("jbm.companies.address")}</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2"><Label>{t("jbm.companies.phone")}</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div className="space-y-2"><Label>{t("jbm.companies.email")}</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            </div>
            <div className="space-y-2"><Label>{t("jbm.companies.taxId")}</Label><Input value={form.tax_id} onChange={(e) => setForm({ ...form, tax_id: e.target.value })} /></div>
            <DialogFooter><Button type="submit" className="w-full">{t("common.save")}</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!delTarget} onOpenChange={(o) => !o && setDelTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("jbm.companies.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("jbm.companies.deleteDesc", { name: delTarget?.name })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); remove(delTarget); }}>{t("common.delete")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <SubscribeDialog
        plan={payPlan}
        open={!!payPlan}
        onOpenChange={(o) => !o && setPayPlan(null)}
        defaultCount={companies.length + 1}
        alreadyCovered={allowedCount}
        onSuccess={() => { setPayPlan(null); window.location.reload(); }}
      />
    </div>
  );
}