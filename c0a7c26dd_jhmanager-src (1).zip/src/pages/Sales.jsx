import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import { formatCurrency } from "@/lib/format";
import ExportMenu from "@/components/ExportMenu";
import SaleForm from "@/components/business/SaleForm";
import SaleItem from "@/components/business/SaleItem";
import { expandRecurrence } from "@/lib/recurrence";

export default function Sales() {
  const { t } = useI18n();
  const { activeCompanyId } = useSpace();
  const [sales, setSales] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => {
    const [s, prefs] = await Promise.all([
      base44.entities.Sale.list("-date", 500),
      base44.entities.Preferences.list(),
    ]);
    setSales(s);
    setPreferences(prefs?.[0] || null);
    setLoading(false);
  };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const currency = preferences?.currency || "XAF";
  const mySales = activeCompanyId ? sales.filter((s) => s.company_id === activeCompanyId) : sales;
  const total = mySales.filter((s) => s.status !== "annulee").reduce((sum, s) => sum + (Number(s.quantity) || 0) * (Number(s.unit_price) || 0), 0);

  const save = async (data, recurrence) => {
    const payload = { ...data, company_id: activeCompanyId };
    if (editing) {
      const prev = sales;
      setSales((cur) => cur.map((s) => (s.id === editing.id ? { ...s, ...payload } : s)));
      try {
        await base44.entities.Sale.update(editing.id, payload);
        toast({ title: t("toast.taskUpdated") });
        load();
      } catch (e) {
        setSales(prev);
        toast({ title: t("toast.error"), description: t("err.modify"), variant: "destructive" });
      }
    } else {
      const items = expandRecurrence(payload, recurrence?.frequency, recurrence?.count, ["date"]);
      const tempIds = items.map(() => `tmp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
      setSales((cur) => [...items.map((it, i) => ({ ...it, id: tempIds[i] })), ...cur]);
      try {
        await base44.entities.Sale.bulkCreate(items);
        toast({ title: recurrence && recurrence.count > 1 ? `${items.length} ventes récurrentes créées` : t("toast.expenseAdded") });
        load();
      } catch (e) {
        setSales((cur) => cur.filter((s) => !tempIds.includes(s.id)));
        toast({ title: t("toast.error"), description: t("err.create"), variant: "destructive" });
      }
    }
    setFormOpen(false);
    setEditing(null);
  };

  const remove = async (sale) => {
    const prev = sales;
    setSales((cur) => cur.filter((s) => s.id !== sale.id));
    try {
      await base44.entities.Sale.delete(sale.id);
      toast({ title: t("toast.taskDeleted") });
      load();
    } catch (e) {
      setSales(prev);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{t("jbm.sales.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("jbm.sales.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2">
          <ExportMenu
            title={t("report.sales")}
            subtitle={t("report.salesSub")}
            currency={currency}
            rows={mySales}
            columns={[
              { key: "item_name", label: t("jbm.sale.item") },
              { key: "customer_name", label: t("jbm.sale.customer") },
              { key: "quantity", label: t("jbm.sale.quantity") },
              { key: "unit_price", label: t("jbm.sale.unitPrice"), type: "currency" },
              { key: "date", label: t("jbm.sale.date"), type: "date" },
              { key: "status", label: t("jbm.sale.status") },
            ]}
            summary={[{ label: t("jbm.kpi.sales"), value: formatCurrency(total, currency) }]}
          />
          <Button onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Plus className="w-4 h-4 mr-2" /> {t("jbm.add")}
          </Button>
        </div>
      </div>
      <div className="bg-card border border-border rounded-2xl p-5">
        <p className="text-sm text-muted-foreground">{t("jbm.kpi.sales")}</p>
        <p className="font-display text-xl mt-1">{formatCurrency(total, currency)}</p>
      </div>
      {mySales.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <ShoppingCart className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">{t("jbm.sales.empty")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {mySales.map((s) => (
            <SaleItem key={s.id} sale={s} currency={currency} onEdit={(x) => { setEditing(x); setFormOpen(true); }} onDelete={remove} />
          ))}
        </div>
      )}
      <SaleForm open={formOpen} onOpenChange={setFormOpen} sale={editing} onSubmit={save} />
    </div>
  );
}