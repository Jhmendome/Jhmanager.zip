import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import { formatCurrency } from "@/lib/format";
import ExportMenu from "@/components/ExportMenu";
import InvoiceForm from "@/components/business/InvoiceForm";
import InvoiceItem from "@/components/business/InvoiceItem";

export default function Invoices() {
  const { t } = useI18n();
  const { activeCompanyId } = useSpace();
  const [invoices, setInvoices] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => {
    const [i, prefs] = await Promise.all([
      base44.entities.Invoice.list("-issue_date", 500),
      base44.entities.Preferences.list(),
    ]);
    setInvoices(i);
    setPreferences(prefs?.[0] || null);
    setLoading(false);
  };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const currency = preferences?.currency || "XAF";
  const myInvoices = activeCompanyId ? invoices.filter((i) => i.company_id === activeCompanyId) : invoices;
  const unpaid = myInvoices.filter((i) => i.status !== "payee").reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  const nextNumber = `F-${new Date().getFullYear()}-${String(myInvoices.length + 1).padStart(4, "0")}`;

  const save = async (data) => {
    const payload = { ...data, company_id: activeCompanyId };
    if (editing) {
      const prev = invoices;
      setInvoices((cur) => cur.map((i) => (i.id === editing.id ? { ...i, ...payload } : i)));
      try {
        await base44.entities.Invoice.update(editing.id, payload);
        toast({ title: t("toast.taskUpdated") });
        load();
      } catch (e) {
        setInvoices(prev);
        toast({ title: t("toast.error"), description: t("err.modify"), variant: "destructive" });
      }
    } else {
      const tmpId = `tmp_${Date.now()}`;
      setInvoices((cur) => [{ ...payload, id: tmpId }, ...cur]);
      try {
        await base44.entities.Invoice.create(payload);
        toast({ title: t("toast.expenseAdded") });
        load();
      } catch (e) {
        setInvoices((cur) => cur.filter((x) => x.id !== tmpId));
        toast({ title: t("toast.error"), description: t("err.create"), variant: "destructive" });
      }
    }
    setFormOpen(false);
    setEditing(null);
  };

  const remove = async (inv) => {
    const prev = invoices;
    setInvoices((cur) => cur.filter((i) => i.id !== inv.id));
    try {
      await base44.entities.Invoice.delete(inv.id);
      toast({ title: t("toast.taskDeleted") });
      load();
    } catch (e) {
      setInvoices(prev);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{t("jbm.invoices.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("jbm.invoices.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2">
          <ExportMenu
            title={t("report.invoices")}
            subtitle={t("report.invoicesSub")}
            currency={currency}
            rows={myInvoices}
            columns={[
              { key: "number", label: t("jbm.invoice.number") },
              { key: "customer_name", label: t("jbm.invoice.customer") },
              { key: "amount", label: t("jbm.invoice.amount"), type: "currency" },
              { key: "issue_date", label: t("jbm.invoice.issueDate"), type: "date" },
              { key: "due_date", label: t("jbm.invoice.dueDate"), type: "date" },
              { key: "status", label: t("jbm.invoice.status") },
            ]}
            summary={[{ label: t("jbm.kpi.unpaid"), value: formatCurrency(unpaid, currency) }]}
          />
          <Button onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Plus className="w-4 h-4 mr-2" /> {t("jbm.add")}
          </Button>
        </div>
      </div>
      <div className="bg-card border border-border rounded-2xl p-5">
        <p className="text-sm text-muted-foreground">{t("jbm.kpi.unpaid")}</p>
        <p className="font-display text-xl mt-1">{formatCurrency(unpaid, currency)}</p>
      </div>
      {myInvoices.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <FileText className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">{t("jbm.invoices.empty")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {myInvoices.map((i) => (
            <InvoiceItem key={i.id} invoice={i} currency={currency} onEdit={(x) => { setEditing(x); setFormOpen(true); }} onDelete={remove} />
          ))}
        </div>
      )}
      <InvoiceForm open={formOpen} onOpenChange={setFormOpen} invoice={editing} onSubmit={save} nextNumber={nextNumber} />
    </div>
  );
}