import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Tag, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSpace } from "@/lib/SpaceContext";

const DOMAINS = [
  { key: "depense", label: "Dépenses", scope: "jpm" },
  { key: "produit", label: "Produits", scope: "jbm" },
  { key: "vente", label: "Ventes", scope: "jbm" },
  { key: "tache", label: "Tâches", scope: "jpm" },
  { key: "evenement", label: "Événements", scope: "jpm" },
];

export default function Categories() {
  const { space, activeCompanyId } = useSpace();
  const [all, setAll] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState("");
  const [domain, setDomain] = useState("depense");
  const [scopeFilter, setScopeFilter] = useState("all");
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.Category.list("-created_date", 500);
      setAll(list || []);
    } catch {
      setAll([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    return all.filter((c) => {
      if (scopeFilter !== "all" && c.scope !== scopeFilter) return false;
      if (c.domain !== domain) return false;
      if (c.scope === "jbm" && activeCompanyId && c.company_id && c.company_id !== activeCompanyId) return false;
      return true;
    });
  }, [all, domain, scopeFilter, activeCompanyId]);

  const handleCreate = async (e) => {
    e.preventDefault();
    const name = newName.trim();
    if (!name) { setError("Saisissez un nom."); return; }
    const def = DOMAINS.find((d) => d.key === domain);
    const scope = def ? def.scope : (space === "jbm" ? "jbm" : "jpm");
    try {
      const created = await base44.entities.Category.create({
        name, scope, domain, company_id: scope === "jbm" ? (activeCompanyId || undefined) : undefined,
      });
      setAll((prev) => [created, ...prev]);
      setNewName("");
      setError("");
    } catch (err) {
      setError(err?.message || "Erreur à la création.");
    }
  };

  const handleDelete = async (id) => {
    try {
      await base44.entities.Category.delete(id);
      setAll((prev) => prev.filter((c) => c.id !== id));
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl flex items-center gap-2"><Tag className="w-6 h-6 text-accent" /> Catégories</h1>
        <p className="text-muted-foreground mt-1">Créez et organisez vos catégories pour dépenses, produits, ventes, tâches et événements.</p>
      </div>

      <form onSubmit={handleCreate} className="bg-card border border-border rounded-2xl p-4 flex flex-col sm:flex-row gap-3 sm:items-end">
        <div className="space-y-1.5 flex-1">
          <label className="text-xs font-medium">Domaine</label>
          <Select value={domain} onValueChange={setDomain}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {DOMAINS.map((d) => <SelectItem key={d.key} value={d.key}>{d.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5 flex-1">
          <label className="text-xs font-medium">Espace</label>
          <Select value={scopeFilter} onValueChange={setScopeFilter}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous</SelectItem>
              <SelectItem value="jpm">Personnel (JPM)</SelectItem>
              <SelectItem value="jbm">Entreprise (JBM)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5 flex-[2]">
          <label className="text-xs font-medium">Nouvelle catégorie</label>
          <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nom de la catégorie" />
        </div>
        <Button type="submit" className="flex items-center gap-1"><Plus className="w-4 h-4" /> Ajouter</Button>
        {error && <p className="text-sm text-destructive sm:col-span-3">{error}</p>}
      </form>

      {loading ? (
        <div className="flex items-center justify-center h-32">
          <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.length === 0 && (
            <p className="text-sm text-muted-foreground col-span-full">Aucune catégorie. Créez-en une ci-dessus.</p>
          )}
          {filtered.map((c) => (
            <div key={c.id} className="bg-card border border-border rounded-2xl p-3 flex items-center justify-between gap-2">
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{c.name}</p>
                <p className="text-xs text-muted-foreground capitalize">
                  {c.scope === "jbm" ? "Entreprise" : "Personnel"} · {DOMAINS.find((d) => d.key === c.domain)?.label || c.domain}
                </p>
              </div>
              <Button size="icon" variant="ghost" onClick={() => handleDelete(c.id)} aria-label="Supprimer">
                <Trash2 className="w-4 h-4 text-destructive" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}