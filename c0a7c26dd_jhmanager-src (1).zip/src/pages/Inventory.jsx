import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Boxes } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import { formatCurrency } from "@/lib/format";
import ExportMenu from "@/components/ExportMenu";
import ProductForm from "@/components/business/ProductForm";
import ProductItem from "@/components/business/ProductItem";

export default function Inventory() {
  const { t } = useI18n();
  const { activeCompanyId } = useSpace();
  const [products, setProducts] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => {
    const [p, prefs] = await Promise.all([
      base44.entities.Product.list("-created_date", 500),
      base44.entities.Preferences.list(),
    ]);
    setProducts(p);
    setPreferences(prefs?.[0] || null);
    setLoading(false);
  };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const currency = preferences?.currency || "XAF";
  const myProducts = activeCompanyId
    ? products.filter((p) => p.company_id === activeCompanyId)
    : products;

  const save = async (data) => {
    const payload = { ...data, company_id: activeCompanyId };
    if (editing) {
      const prev = products;
      setProducts((cur) => cur.map((p) => (p.id === editing.id ? { ...p, ...payload } : p)));
      try {
        await base44.entities.Product.update(editing.id, payload);
        toast({ title: t("toast.taskUpdated") });
        load();
      } catch (e) {
        setProducts(prev);
        toast({ title: t("toast.error"), description: t("err.modify"), variant: "destructive" });
      }
    } else {
      const tmpId = `tmp_${Date.now()}`;
      setProducts((cur) => [{ ...payload, id: tmpId }, ...cur]);
      try {
        await base44.entities.Product.create(payload);
        toast({ title: t("toast.expenseAdded") });
        load();
      } catch (e) {
        setProducts((cur) => cur.filter((p) => p.id !== tmpId));
        toast({ title: t("toast.error"), description: t("err.create"), variant: "destructive" });
      }
    }
    setFormOpen(false);
    setEditing(null);
  };

  const remove = async (product) => {
    const prev = products;
    setProducts((cur) => cur.filter((p) => p.id !== product.id));
    try {
      await base44.entities.Product.delete(product.id);
      toast({ title: t("toast.taskDeleted") });
      load();
    } catch (e) {
      setProducts(prev);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{t("jbm.stock.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("jbm.stock.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2">
          <ExportMenu
            title={t("report.stock")}
            subtitle={t("report.stockSub")}
            currency={currency}
            rows={myProducts}
            columns={[
              { key: "name", label: t("jbm.product.name") },
              { key: "sku", label: t("jbm.product.sku") },
              { key: "category", label: t("jbm.product.category") },
              { key: "quantity", label: t("jbm.product.quantity") },
              { key: "unit_cost", label: t("jbm.product.unitCost"), type: "currency" },
              { key: "sale_price", label: t("jbm.product.salePrice"), type: "currency" },
              { key: "reorder_level", label: t("jbm.product.reorder") },
            ]}
            summary={[{ label: t("jbm.kpi.stock"), value: formatCurrency(myProducts.reduce((s, p) => s + (Number(p.quantity) || 0) * (Number(p.unit_cost) || 0), 0), currency) }]}
          />
          <Button onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Plus className="w-4 h-4 mr-2" /> {t("jbm.add")}
          </Button>
        </div>
      </div>
      {myProducts.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <Boxes className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">{t("jbm.stock.empty")}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {myProducts.map((p) => (
            <ProductItem key={p.id} product={p} currency={currency} onEdit={(x) => { setEditing(x); setFormOpen(true); }} onDelete={remove} />
          ))}
        </div>
      )}
      <ProductForm open={formOpen} onOpenChange={setFormOpen} product={editing} onSubmit={save} />
    </div>
  );
}