import React from "react";
import { Link } from "react-router-dom";
import { useI18n } from "@/lib/i18n";

export default function Privacy() {
  const { t } = useI18n();
  return (
    <div className="min-h-screen bg-background font-body px-5 py-10 max-w-2xl mx-auto">
      <h1 className="font-display text-3xl mb-4">{t("legal.privacyTitle")}</h1>
      <div className="prose prose-sm text-muted-foreground space-y-3">
        <p>{t("legal.privacyIntro")}</p>
        <h2 className="font-display text-base text-foreground">{t("legal.privacyCollectTitle")}</h2>
        <p>{t("legal.privacyCollect")}</p>
        <h2 className="font-display text-base text-foreground">{t("legal.privacyUseTitle")}</h2>
        <p>{t("legal.privacyUse")}</p>
        <h2 className="font-display text-base text-foreground">{t("legal.privacyStorageTitle")}</h2>
        <p>{t("legal.privacyStorage")}</p>
        <h2 className="font-display text-base text-foreground">{t("legal.privacyRightsTitle")}</h2>
        <p>{t("legal.privacyRights")}</p>
      </div>
      <Link to="/login" className="text-sm text-primary hover:underline mt-6 inline-block">{t("legal.back")}</Link>
    </div>
  );
}