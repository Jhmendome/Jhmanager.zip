import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Truck, Pencil, Trash2, Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useSpace } from "@/lib/SpaceContext";

const empty = { name: "", category: "", contact_person: "", phone: "", email: "", address: "", notes: "" };

export default function Suppliers() {
  const { activeCompanyId } = useSpace();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [del, setDel] = useState(null);
  const [processingId, setProcessingId] = useState(null);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => { const list = await base44.entities.Supplier.list("-created_date", 500); setItems(list || []); setLoading(false); };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const mine = activeCompanyId ? items.filter((s) => s.company_id === activeCompanyId) : items;

  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (s) => { setEditing(s); setForm({ name: s.name || "", category: s.category || "", contact_person: s.contact_person || "", phone: s.phone || "", email: s.email || "", address: s.address || "", notes: s.notes || "" }); setOpen(true); };

  const save = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    const payload = { ...form, company_id: activeCompanyId };
    try {
      if (editing) { await base44.entities.Supplier.update(editing.id, payload); toast({ title: "Prestataire mis à jour" }); }
      else { await base44.entities.Supplier.create(payload); toast({ title: "Prestataire ajouté" }); }
      setOpen(false); load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const remove = async (s) => { try { await base44.entities.Supplier.delete(s.id); toast({ title: "Prestataire supprimé" }); load(); } catch { toast({ title: "Erreur", variant: "destructive" }); } setDel(null); };

  const processAI = async (s) => {
    const text = [s.notes, s.category && `Catégorie: ${s.category}`, s.contact_person && `Contact: ${s.contact_person}`].filter(Boolean).join("\n");
    if (!text.trim()) { toast({ title: "Aucune note à traiter", variant: "destructive" }); return; }
    setProcessingId(s.id);
    try {
      const res = await base44.functions.invoke('processNotes', { note: text, scope: "jbm", company_id: activeCompanyId });
      const c = res?.created || {};
      toast({ title: "Note traitée par l'IA", description: `Ajouté : ${c.expenses || 0} dépense(s), ${c.tasks || 0} tâche(s), ${c.events || 0} événement(s).` });
    } catch (e) { toast({ title: "Échec du traitement IA", description: e?.message || "Erreur", variant: "destructive" }); }
    setProcessingId(null);
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div><h1 className="font-display text-2xl sm:text-3xl">Prestataires</h1><p className="text-muted-foreground mt-1">Vos fournisseurs et prestataires de service.</p></div>
        <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" /> Ajouter</Button>
      </div>

      {mine.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><Truck className="w-8 h-8 mx-auto mb-3 opacity-50" /><p className="text-sm">Aucun prestataire enregistré.</p></div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {mine.map((s) => (
            <div key={s.id} className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{s.name}</p>
                  {s.category && <p className="text-xs text-muted-foreground truncate">{s.category}</p>}
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button onClick={() => processAI(s)} disabled={processingId === s.id} title="Traiter la note par l'IA" className="no-select-tap min-touch p-2 rounded-lg hover:bg-accent/10 text-accent-foreground disabled:opacity-50">
                    {processingId === s.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  </button>
                  <button onClick={() => openEdit(s)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => setDel(s)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
              <div className="mt-2 text-xs text-muted-foreground space-y-0.5">
                {s.contact_person && <p>{s.contact_person}</p>}
                {s.phone && <p>{s.phone}</p>}
                {s.email && <p className="truncate">{s.email}</p>}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="font-display">{editing ? "Modifier le prestataire" : "Nouveau prestataire"}</DialogTitle></DialogHeader>
          <form onSubmit={save} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Nom</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div className="space-y-2"><Label>Catégorie</Label><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></div>
            </div>
            <div className="space-y-2"><Label>Personne de contact</Label><Input value={form.contact_person} onChange={(e) => setForm({ ...form, contact_person: e.target.value })} /></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Téléphone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            </div>
            <div className="space-y-2"><Label>Adresse</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div className="space-y-2"><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} /></div>
            <DialogFooter><Button type="submit" className="w-full">Enregistrer</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Supprimer ce prestataire ?</AlertDialogTitle><AlertDialogDescription>« {del?.name} » sera supprimé définitivement.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Annuler</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); remove(del); }}>Supprimer</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}