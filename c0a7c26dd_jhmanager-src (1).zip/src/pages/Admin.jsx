import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Users, Search, ShieldAlert, Wallet } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import KpiCard from "@/components/dashboard/KpiCard";
import SubscribersByCompanyChart from "@/components/admin/SubscribersByCompanyChart";
import SubscriberDetail from "@/components/admin/SubscriberDetail";
import AdminSuggestions from "@/components/admin/AdminSuggestions";
import AdminFaq from "@/components/admin/AdminFaq";
import AdminResubscription from "@/components/admin/AdminResubscription";
import AdminReports from "@/components/admin/AdminReports";
import { formatCurrency } from "@/lib/format";

// Restreint l'accès à toi et ton collaborateur.
// Ajoutez vos emails ici pour activer le filtre ; tant que la liste est vide,
// tous les utilisateurs ayant le rôle "admin" y ont accès.
// Exemple : ["moi@example.com", "associe@example.com"]
const ADMIN_EMAILS = [];

const PAGE_SIZE = 10;

export default function Admin() {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [subs, setSubs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("newest");
  const [onlySubs, setOnlySubs] = useState(true);
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState(null);

  const allowed =
    user?.role === "admin" &&
    (ADMIN_EMAILS.length === 0 || ADMIN_EMAILS.includes(user.email));

  useEffect(() => {
    if (!allowed) {
      setLoading(false);
      return;
    }
    (async () => {
      try {
        const [u, s] = await Promise.all([
          base44.entities.User.list("-created_date", 500),
          base44.entities.Subscription.list("-paid_at", 500),
        ]);
        setUsers(u || []);
        setSubs(s || []);
      } catch (e) {
        setUsers([]);
        setSubs([]);
      } finally {
        setLoading(false);
      }
    })();
  }, [allowed]);

  const enriched = useMemo(() => {
    return users.map((u) => {
      const mySubs = subs.filter((s) => s.created_by_id === u.id);
      const accountType =
        u.data?.account_type || u.account_type || mySubs[0]?.account_type || null;
      const totalPaid = mySubs.reduce((sum, s) => sum + (Number(s.amount) || 0), 0);
      const companies = mySubs.length
        ? Math.max(...mySubs.map((s) => Number(s.companies_count) || 1))
        : 0;
      return { ...u, accountType, totalPaid, companies, subsCount: mySubs.length };
    });
  }, [users, subs]);

  const subscribers = enriched.filter(
    (u) => u.accountType === "particulier" || u.accountType === "entreprise"
  );
  const jpm = subscribers.filter((u) => u.accountType === "particulier");
  const jbm = subscribers.filter((u) => u.accountType === "entreprise");
  const totalRevenue = subs.reduce((sum, s) => sum + (Number(s.amount) || 0), 0);
  const caJpm = subs.filter((s) => s.account_type === "particulier").reduce((sum, s) => sum + (Number(s.amount) || 0), 0);
  const caJbm = subs.filter((s) => s.account_type === "entreprise").reduce((sum, s) => sum + (Number(s.amount) || 0), 0);

  const byCompany = useMemo(() => {
    const map = {};
    jbm.forEach((u) => {
      const c = u.companies || 1;
      map[c] = (map[c] || 0) + 1;
    });
    return Object.entries(map)
      .map(([companies, count]) => ({ companies: `${companies} entr.`, count }))
      .sort((a, b) => parseInt(a.companies) - parseInt(b.companies));
  }, [jbm]);

  const filtered = useMemo(() => {
    let list = onlySubs ? subscribers : enriched;
    const q = query.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (u) =>
          (u.email || "").toLowerCase().includes(q) ||
          (u.full_name || "").toLowerCase().includes(q)
      );
    }
    const sorted = [...list];
    switch (sort) {
      case "oldest":
        sorted.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
        break;
      case "type":
        sorted.sort((a, b) => (a.accountType || "").localeCompare(b.accountType || ""));
        break;
      case "companies":
        sorted.sort((a, b) => (b.companies || 0) - (a.companies || 0));
        break;
      case "paid":
        sorted.sort((a, b) => (b.totalPaid || 0) - (a.totalPaid || 0));
        break;
      default:
        sorted.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }
    return sorted;
  }, [enriched, subscribers, onlySubs, query, sort]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount - 1);
  const pageItems = filtered.slice(safePage * PAGE_SIZE, safePage * PAGE_SIZE + PAGE_SIZE);

  if (!allowed) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <ShieldAlert className="w-10 h-10 text-destructive mb-3" />
        <h1 className="font-display text-xl">Accès restreint</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Cette section est réservée aux administrateurs autorisés.
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl">Tableau de bord administrateur</h1>
        <p className="text-muted-foreground mt-1">Vue d'ensemble des abonnés et des revenus.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard icon={Users} label="Abonnés" value={subscribers.length} tone="default" />
        <KpiCard icon={Wallet} label="CA JPM" value={formatCurrency(caJpm, "XAF")} tone="default" />
        <KpiCard icon={Wallet} label="CA JBM" value={formatCurrency(caJbm, "XAF")} tone="accent" />
        <KpiCard icon={Wallet} label="Revenus encaissés" value={formatCurrency(totalRevenue, "XAF")} tone="default" />
      </div>

      <AdminSuggestions />

      <AdminFaq />

      <AdminReports />

      <AdminResubscription />

      {byCompany.length > 0 && <SubscribersByCompanyChart data={byCompany} />}

      <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => { setQuery(e.target.value); setPage(0); }}
              placeholder="Rechercher par email ou nom…"
              className="pl-9"
            />
          </div>
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger className="sm:w-52"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Plus récents</SelectItem>
              <SelectItem value="oldest">Plus anciens</SelectItem>
              <SelectItem value="type">Par type de compte</SelectItem>
              <SelectItem value="companies">Par nb d'entreprises</SelectItem>
              <SelectItem value="paid">Par montant payé</SelectItem>
            </SelectContent>
          </Select>
          <button
            onClick={() => { setOnlySubs((v) => !v); setPage(0); }}
            className={`text-xs px-3 py-2 rounded-lg border no-select-tap ${onlySubs ? "bg-primary text-primary-foreground border-primary" : "bg-transparent"}`}
          >
            {onlySubs ? "Abonnés seulement" : "Tous les utilisateurs"}
          </button>
        </div>

        <div className="divide-y divide-border">
          {pageItems.length === 0 ? (
            <p className="text-sm text-muted-foreground py-6 text-center">Aucun résultat.</p>
          ) : (
            pageItems.map((u) => (
              <button
                key={u.id}
                onClick={() => setSelected(u)}
                className="w-full flex items-center justify-between gap-3 py-3 text-left hover:bg-secondary/40 rounded-lg px-2 no-select-tap"
              >
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{u.full_name || u.email}</p>
                  <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                </div>
                <div className="flex items-center gap-3 shrink-0 text-xs">
                  <span className={`px-2 py-1 rounded-full ${u.accountType === "entreprise" ? "bg-accent/15 text-accent-foreground" : u.accountType === "particulier" ? "bg-primary/10" : "bg-secondary"}`}>
                    {u.accountType === "entreprise" ? "JBM" : u.accountType === "particulier" ? "JPM" : "—"}
                  </span>
                  {u.accountType === "entreprise" && <span className="text-muted-foreground">{u.companies} entr.</span>}
                  <span className="text-muted-foreground">{formatCurrency(u.totalPaid, "XAF")}</span>
                </div>
              </button>
            ))
          )}
        </div>

        {pageCount > 1 && (
          <div className="flex items-center justify-between pt-2">
            <button
              disabled={safePage === 0}
              onClick={() => setPage((p) => p - 1)}
              className="text-sm px-3 py-2 rounded-lg border disabled:opacity-40 no-select-tap"
            >
              Précédent
            </button>
            <span className="text-xs text-muted-foreground">Page {safePage + 1} / {pageCount}</span>
            <button
              disabled={safePage >= pageCount - 1}
              onClick={() => setPage((p) => p + 1)}
              className="text-sm px-3 py-2 rounded-lg border disabled:opacity-40 no-select-tap"
            >
              Suivant
            </button>
          </div>
        )}
      </div>

      <SubscriberDetail
        user={selected}
        subscriptions={subs}
        open={!!selected}
        onOpenChange={(o) => !o && setSelected(null)}
      />
    </div>
  );
}