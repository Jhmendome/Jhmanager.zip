import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, ChevronRight, Plus, CalendarClock, CheckSquare } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { Link } from "react-router-dom";
import {
  format, startOfMonth, endOfMonth, eachDayOfInterval, getDay,
  isSameDay, addMonths, subMonths, parseISO,
} from "date-fns";
import { fr } from "date-fns/locale";
import { getHolidays } from "@/lib/holidays";
import EventForm from "@/components/events/EventForm";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const WEEKDAYS = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
const TASK_DOT = { haute: "bg-destructive", normale: "bg-primary", basse: "bg-muted-foreground" };
const EVENT_COLOR = {
  reunion: "bg-primary",
  rendez_vous: "bg-accent",
  formation: "bg-chart-3",
  ceremonie: "bg-sidebar-primary",
  autre: "bg-muted-foreground/50",
};

export default function CalendarPage() {
  const { t } = useI18n();
  const { space, activeCompanyId } = useSpace();
  const { toast } = useToast();
  const { register } = useRefresh();
  const [tasks, setTasks] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cursor, setCursor] = useState(new Date());
  const [formOpen, setFormOpen] = useState(false);
  const [fType, setFType] = useState("all");
  const [fCat, setFCat] = useState("all");
  const [fSpace, setFSpace] = useState("all");

  const load = async () => {
    try {
      const [taskList, eventList] = await Promise.all([
        base44.entities.Task.list("-start", 500),
        base44.entities.Event.list("start", 500),
      ]);
      setTasks(taskList || []);
      const scopedEvents = space === "jpm"
        ? (eventList || [])
        : (eventList || []).filter((e) => !activeCompanyId || e.company_id === activeCompanyId);
      setEvents(scopedEvents);
    } catch {
      setTasks([]);
      setEvents([]);
    }
    setLoading(false);
  };

  useEffect(() => { register(load); });
  useEffect(() => { setLoading(true); load(); }, [space, activeCompanyId]);

  const handleSaveEvent = async (data) => {
    try {
      const payload = space === "jpm" ? data : { ...data, company_id: activeCompanyId };
      await base44.entities.Event.create(payload);
      toast({ title: "Événement créé" });
      setFormOpen(false);
      load();
    } catch {
      toast({ title: "Erreur", description: "Création impossible.", variant: "destructive" });
    }
  };

  const monthStart = startOfMonth(cursor);
  const monthEnd = endOfMonth(cursor);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const firstDow = (getDay(monthStart) + 6) % 7;
  const cells = [...Array(firstDow).fill(null), ...days];

  const itemsByDay = useMemo(() => {
    const showTasks = fType !== "event";
    const showEvents = fType !== "task";
    const visibleEvents = events.filter((ev) => {
      if (fCat !== "all" && ev.category !== fCat) return false;
      if (fSpace === "perso" && ev.company_id) return false;
      if (fSpace === "pro" && !ev.company_id) return false;
      return true;
    });
    const map = {};
    if (showTasks) {
      tasks.forEach((task) => {
        const d = task.start ? parseISO(task.start) : null;
        if (!d) return;
        const key = format(d, "yyyy-MM-dd");
        (map[key] = map[key] || []).push({ kind: "task", item: task });
      });
    }
    if (showEvents) {
      visibleEvents.forEach((ev) => {
        const d = ev.start ? parseISO(ev.start) : null;
        if (!d) return;
        const key = format(d, "yyyy-MM-dd");
        (map[key] = map[key] || []).push({ kind: "event", item: ev });
      });
    }
    // Tri : événements d'abord, puis par heure de début.
    Object.values(map).forEach((arr) =>
      arr.sort((a, b) => {
        if (a.kind !== b.kind) return a.kind === "event" ? -1 : 1;
        return new Date(a.item.start) - new Date(b.item.start);
      })
    );
    return map;
  }, [tasks, events, fType, fCat, fSpace]);

  const holidays = useMemo(() => getHolidays(cursor.getFullYear()), [cursor]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-3xl">{t("calendar.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("calendar.subtitle")}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFormOpen(true)}
            className="inline-flex items-center gap-2 text-sm bg-primary text-primary-foreground px-3 py-2 rounded-lg no-select-tap min-touch"
          >
            <CalendarClock className="w-4 h-4" /> Événement
          </button>
          <Link
            to="/taches"
            className="inline-flex items-center gap-2 text-sm bg-secondary text-secondary-foreground px-3 py-2 rounded-lg no-select-tap min-touch"
          >
            <CheckSquare className="w-4 h-4" /> Tâche
          </Link>
        </div>
      </div>

      <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
        <span className="inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-primary" /> Tâche (priorité)</span>
        <span className="inline-flex items-center gap-1.5"><span className="w-2 h-2 rounded-sm bg-accent" /> Événement (catégorie)</span>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Select value={fType} onValueChange={setFType}>
          <SelectTrigger className="h-9 w-auto text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tout type</SelectItem>
            <SelectItem value="task">Tâches</SelectItem>
            <SelectItem value="event">Événements</SelectItem>
          </SelectContent>
        </Select>
        <Select value={fCat} onValueChange={setFCat}>
          <SelectTrigger className="h-9 w-auto text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toutes catégories</SelectItem>
            <SelectItem value="reunion">Réunion</SelectItem>
            <SelectItem value="rendez_vous">Rendez-vous</SelectItem>
            <SelectItem value="formation">Formation</SelectItem>
            <SelectItem value="ceremonie">Cérémonie</SelectItem>
            <SelectItem value="autre">Autre</SelectItem>
          </SelectContent>
        </Select>
        <Select value={fSpace} onValueChange={setFSpace}>
          <SelectTrigger className="h-9 w-auto text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous espaces</SelectItem>
            <SelectItem value="perso">Personnel</SelectItem>
            <SelectItem value="pro">Professionnel</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center justify-between bg-card border border-border rounded-2xl p-4">
        <button
          onClick={() => setCursor(subMonths(cursor, 1))}
          className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"
          aria-label={t("calendar.prev")}
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <p className="font-display text-lg capitalize">{format(cursor, "MMMM yyyy", { locale: fr })}</p>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setCursor(new Date())}
            className="text-xs px-2.5 py-1.5 rounded-lg bg-secondary hover:bg-secondary/70 no-select-tap"
          >
            {t("calendar.today")}
          </button>
          <button
            onClick={() => setCursor(addMonths(cursor, 1))}
            className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"
            aria-label={t("calendar.next")}
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="bg-card border border-border rounded-2xl p-3">
          <div className="grid grid-cols-7 gap-1 mb-1">
            {WEEKDAYS.map((d) => (
              <div key={d} className="text-center text-xs font-medium text-muted-foreground py-1">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((day, i) => {
              if (!day) return <div key={i} className="min-h-[80px] rounded-lg" />;
              const key = format(day, "yyyy-MM-dd");
              const dayItems = itemsByDay[key] || [];
              const isToday = isSameDay(day, new Date());
              const holiday = holidays[key];
              return (
                <div
                  key={i}
                  className={`min-h-[80px] rounded-lg border p-1.5 ${isToday ? "border-primary bg-primary/5" : holiday ? "border-accent/60 bg-accent/5" : "border-border"}`}
                >
                  <p className="text-xs text-muted-foreground mb-1">{format(day, "d")}</p>
                  {holiday && <p className="text-[9px] leading-tight text-accent-foreground bg-accent/20 rounded px-1 mb-1 truncate" title={holiday}>{holiday}</p>}
                  <div className="space-y-1">
                    {dayItems.slice(0, 3).map((entry) => (
                      <div key={entry.item.id} className="flex items-center gap-1 text-[11px] leading-tight">
                        <span className={`w-1.5 h-1.5 shrink-0 ${entry.kind === "event" ? "rounded-sm " + (EVENT_COLOR[entry.item.category] || EVENT_COLOR.autre) : "rounded-full " + (TASK_DOT[entry.item.priority] || TASK_DOT.normale)}`} />
                        <span className="truncate">{entry.item.title}</span>
                      </div>
                    ))}
                    {dayItems.length > 3 && (
                      <p className="text-[10px] text-muted-foreground">+{dayItems.length - 3}</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <EventForm open={formOpen} onOpenChange={setFormOpen} event={null} onSubmit={handleSaveEvent} />
    </div>
  );
}