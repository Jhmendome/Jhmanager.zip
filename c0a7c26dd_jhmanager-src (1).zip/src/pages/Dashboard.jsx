import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Wallet, TrendingDown, CheckCircle2, AlertTriangle, ListChecks, CalendarRange, CalendarDays, Bot, Settings, Users, Gift, Bell, Gauge, CalendarClock, Calculator, BarChart3, Tag, UsersRound, HelpCircle } from "lucide-react";
import KpiCard from "@/components/dashboard/KpiCard";
import QuickLinks from "@/components/dashboard/QuickLinks";
import ExpenseChart from "@/components/dashboard/ExpenseChart";
import RevenueCard from "@/components/dashboard/RevenueCard";
import SpaceNav from "@/components/dashboard/SpaceNav";
import GlobalSearch from "@/components/search/GlobalSearch";
import TipCard from "@/components/dashboard/TipCard";
import LifeTipCard from "@/components/dashboard/LifeTipCard";
import BusinessDashboard from "@/pages/BusinessDashboard";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/AuthContext";
import { useSpace } from "@/lib/SpaceContext";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const { t } = useI18n();
  const { user } = useAuth();
  const { space, activeCompanyId, companies } = useSpace();
  const [tasks, setTasks] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [taskList, expList, prefList] = await Promise.all([
          base44.entities.Task.list("-start", 200),
          base44.entities.Expense.list("-date", 200),
          base44.entities.Preferences.list(),
        ]);
        setTasks(taskList || []);
        setExpenses(expList || []);
        setPreferences(prefList?.[0] || null);
      } catch (err) {
        console.error("Dashboard load error:", err);
        setTasks([]);
        setExpenses([]);
        setPreferences(null);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Alerte automatique : vérifie les seuils une fois par jour et crée les notifications
  useEffect(() => {
    const today = new Date().toISOString().slice(0, 10);
    const key = `jm_alerts_${today}`;
    if (localStorage.getItem(key)) return;
    (async () => {
      try {
        await base44.functions.invoke('checkAlerts', {});
        localStorage.setItem(key, "1");
      } catch { /* ignore */ }
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const currency = preferences?.currency || "XAF";
  const budget = preferences?.initial_budget || 0;
  const totalExpense = expenses.reduce((sum, e) => sum + (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0), 0);
  const remaining = budget - totalExpense;

  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000);

  const activeTasks = tasks.filter((task) => task.status !== "terminee");
  const todayTasks = activeTasks.filter((task) => new Date(task.start) < endOfDay && new Date(task.end) >= startOfDay);
  const overdueTasks = activeTasks.filter((task) => new Date(task.end) < now);
  const reminderDays = preferences?.reminder_days || 7;
  const limit = new Date(now.getTime() + reminderDays * 24 * 60 * 60 * 1000);
  const upcoming = activeTasks
    .filter((task) => new Date(task.start) > now && new Date(task.start) < limit)
    .sort((a, b) => new Date(a.start) - new Date(b.start))
    .slice(0, 5);

  const contextCompany = companies.find((c) => c.id === activeCompanyId);
  const headerTitle =
    space === "jbm" ? (contextCompany?.name || t("jbm.dashboard"))
    : t("dashboard.greeting");
  const headerSubtitle =
    space === "jbm" ? t("jbm.dashboardSubtitle")
    : t("dashboard.subtitle");

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{headerTitle}</h1>
          <p className="text-muted-foreground mt-1">{headerSubtitle}</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <GlobalSearch />
          <SpaceNav />
        </div>
      </div>

      {space === "jbm" ? (
        <BusinessDashboard />
      ) : (
      <>
      <TipCard title="Astuces personnelles">
        {overdueTasks.length > 0
          ? `Vous avez ${overdueTasks.length} tâche(s) en retard. Anticipez-les pour garder votre planning sous contrôle.`
          : remaining < 0
          ? "Vos dépenses dépassent votre budget. Revoyez vos postes de dépense dans les finances."
          : "Suivez chaque jour vos dépenses et tâches pour rester maître de votre budget personnel."}
      </TipCard>
      <LifeTipCard space="jpm" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard icon={Wallet} label={t("kpi.remaining")} value={formatCurrency(remaining, currency)} tone="default" />
        <KpiCard icon={TrendingDown} label={t("kpi.totalExpenses")} value={formatCurrency(totalExpense, currency)} tone="accent" />
        <KpiCard icon={CheckCircle2} label={t("kpi.todayTasks")} value={todayTasks.length} tone="default" />
        <KpiCard icon={AlertTriangle} label={t("kpi.overdue")} value={overdueTasks.length} tone={overdueTasks.length ? "warn" : "default"} />
      </div>

      <ExpenseChart expenses={expenses} currency={currency} />

      {user?.role === "admin" && <RevenueCard />}

      <div>
        <h2 className="font-display text-lg mb-3">Accès rapide</h2>
        <QuickLinks
          items={[
            { to: "/finances", label: t("nav.finances"), icon: Wallet, desc: "Budget, dépenses, taxes & emprunts" },
            { to: "/taches", label: t("nav.tasks"), icon: ListChecks, desc: "Vos tâches" },
            { to: "/faq", label: "FAQ", icon: HelpCircle, desc: "Questions fréquentes & aide" },
            { to: "/planning", label: t("nav.planning"), icon: CalendarRange, desc: "Calendrier" },
            { to: "/calendrier", label: t("nav.calendar"), icon: CalendarDays, desc: "Vue mensuelle" },
            { to: "/evenements", label: t("nav.events"), icon: CalendarClock, desc: "Événements & RDV" },
            { to: "/calculateurs", label: t("nav.calculators"), icon: Calculator, desc: "Calculatrice & formules" },
            { to: "/reporting", label: "Reporting", icon: BarChart3, desc: "Rapports & graphiques" },
            { to: "/assistants", label: t("nav.agents"), icon: Bot, desc: "Assistant IA JPM" },
            { to: "/parametres", label: t("nav.settings"), icon: Settings, desc: "Préférences" },
            { to: "/notifications", label: t("nav.notifications"), icon: Bell, desc: "Rappels & alertes" },
            { to: "/collaborateurs", label: "Collaborateurs", icon: UsersRound, desc: "Échangez et travaillez ensemble" },
            { to: "/suggestions", label: t("nav.suggestions"), icon: Gift, desc: "Suggérez des améliorations" },
            { to: "/affiliation", label: "Affiliation", icon: Gift, desc: "Parrainez et gagnez" },
            ...(user?.role === "admin" ? [{ to: "/admin", label: "Abonnés", icon: Users, desc: "Tableau de bord admin" }] : []),
          ]}
        />
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 sm:p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-lg">{t("dashboard.upcoming")}</h2>
          <Link to="/planning" className="text-sm text-primary hover:underline">{t("dashboard.viewPlanning")}</Link>
        </div>
        {upcoming.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("dashboard.noUpcoming", { days: reminderDays })}</p>
        ) : (
          <div className="space-y-3">
            {upcoming.map((task) => (
              <div key={task.id} className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{task.title}</p>
                  <p className="text-xs text-muted-foreground">{formatDateFr(task.start, true)}</p>
                </div>
                <span className="text-xs px-2 py-1 rounded-full bg-secondary text-secondary-foreground shrink-0">
                  {t("priority." + (task.priority || "normale"))}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      </>
      )}
    </div>
  );
}