import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { FileDown, Loader2, FileText, Sheet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useSpace } from "@/lib/SpaceContext";
import { useToast } from "@/components/ui/use-toast";
import { formatCurrency } from "@/lib/format";
import { exportToPdf, exportToXls } from "@/lib/exportReport";
import {
  PERIOD_TYPES, yearOptions, monthOptions, quarterOptions, halfOptions, weekOptions, computeRange,
} from "@/lib/reportPeriods";

const money = (v) => Number(v) || 0;

// Définition des sections exportables : entité, champ de date, colonnes, mapping ligne, aspects (filtre) optionnels.
const SECTIONS = [
  {
    value: "taches", label: "Tâches", entity: "Task", dateField: "start", companyScoped: false,
    columns: [
      { key: "title", label: "Titre" },
      { key: "priority", label: "Priorité" },
      { key: "status", label: "Statut" },
      { key: "category", label: "Catégorie" },
      { key: "start", label: "Début", type: "date" },
      { key: "end", label: "Fin", type: "date" },
    ],
    toRow: (r) => ({ title: r.title, priority: r.priority, status: r.status, category: r.category, start: r.start, end: r.end }),
    aspects: { field: "status", options: [
      { value: "a_faire", label: "À faire" }, { value: "en_cours", label: "En cours" }, { value: "terminee", label: "Terminée" },
    ] },
  },
  {
    value: "evenements", label: "Évènements", entity: "Event", dateField: "start", companyScoped: false,
    columns: [
      { key: "title", label: "Titre" },
      { key: "category", label: "Catégorie" },
      { key: "location", label: "Lieu" },
      { key: "priority", label: "Priorité" },
      { key: "start", label: "Début", type: "date" },
      { key: "end", label: "Fin", type: "date" },
    ],
    toRow: (r) => ({ title: r.title, category: r.category, location: r.location, priority: r.priority, start: r.start, end: r.end }),
    aspects: { field: "category", options: [
      { value: "reunion", label: "Réunion" }, { value: "rendez_vous", label: "Rendez-vous" },
      { value: "formation", label: "Formation" }, { value: "ceremonie", label: "Cérémonie" }, { value: "autre", label: "Autre" },
    ] },
  },
  {
    value: "planning", label: "Planning (tâches + évènements)", entity: null, dateField: "start", companyScoped: false,
    columns: [
      { key: "type", label: "Type" },
      { key: "titre", label: "Titre" },
      { key: "start", label: "Début", type: "date" },
      { key: "end", label: "Fin", type: "date" },
      { key: "statut", label: "Statut / Priorité" },
    ],
    toRow: (r) => ({ type: r._type, titre: r.title, start: r.start, end: r.end, statut: r.status }),
  },
  {
    value: "finances", label: "Finances (dépenses)", entity: "Expense", dateField: "date", companyScoped: false,
    columns: [
      { key: "name", label: "Libellé" },
      { key: "category", label: "Catégorie" },
      { key: "quantity", label: "Quantité" },
      { key: "unit_cost", label: "Coût unitaire", type: "currency" },
      { key: "date", label: "Date", type: "date" },
      { key: "total", label: "Total", type: "currency" },
    ],
    toRow: (r) => ({ name: r.name, category: r.category, quantity: r.quantity, unit_cost: r.unit_cost, date: r.date, total: money(r.quantity) * money(r.unit_cost) }),
  },
  {
    value: "calculs", label: "Calculs (définitions)", entity: "CalcDefinition", dateField: "created_date", companyScoped: false,
    columns: [
      { key: "label", label: "Libellé" },
      { key: "name", label: "Identifiant" },
      { key: "kind", label: "Type" },
      { key: "expression", label: "Formule" },
      { key: "unit", label: "Unité" },
      { key: "value", label: "Valeur" },
      { key: "source_type", label: "Source" },
    ],
    toRow: (r) => ({ label: r.label, name: r.name, kind: r.kind, expression: r.expression, unit: r.unit, value: r.value, source_type: r.source_type }),
  },
  {
    value: "devis", label: "Devis", entity: "Quote", dateField: "issue_date", companyScoped: true,
    columns: [
      { key: "number", label: "Numéro" },
      { key: "client_name", label: "Client" },
      { key: "amount", label: "Montant", type: "currency" },
      { key: "issue_date", label: "Émission", type: "date" },
      { key: "validity_date", label: "Validité", type: "date" },
      { key: "status", label: "Statut" },
    ],
    toRow: (r) => ({ number: r.number, client_name: r.client_name, amount: r.amount, issue_date: r.issue_date, validity_date: r.validity_date, status: r.status }),
    aspects: { field: "status", options: [
      { value: "brouillon", label: "Brouillon" }, { value: "envoye", label: "Envoyé" },
      { value: "accepte", label: "Accepté" }, { value: "refuse", label: "Refusé" },
    ] },
  },
  {
    value: "ventes", label: "Ventes", entity: "Sale", dateField: "date", companyScoped: true,
    columns: [
      { key: "item_name", label: "Article" },
      { key: "customer_name", label: "Client" },
      { key: "quantity", label: "Quantité" },
      { key: "unit_price", label: "Prix unitaire", type: "currency" },
      { key: "date", label: "Date", type: "date" },
      { key: "status", label: "Statut" },
      { key: "total", label: "Total", type: "currency" },
    ],
    toRow: (r) => ({ item_name: r.item_name, customer_name: r.customer_name, quantity: r.quantity, unit_price: r.unit_price, date: r.date, status: r.status, total: money(r.quantity) * money(r.unit_price) }),
    aspects: { field: "status", options: [
      { value: "en_attente", label: "En attente" }, { value: "payee", label: "Payée" }, { value: "annulee", label: "Annulée" },
    ] },
  },
  {
    value: "salaries", label: "Salariés", entity: "Employee", dateField: "hire_date", companyScoped: true,
    columns: [
      { key: "full_name", label: "Nom" },
      { key: "role", label: "Poste" },
      { key: "salary", label: "Salaire", type: "currency" },
      { key: "phone", label: "Téléphone" },
      { key: "email", label: "Email" },
      { key: "hire_date", label: "Embauche", type: "date" },
      { key: "status", label: "Statut" },
    ],
    toRow: (r) => ({ full_name: r.full_name, role: r.role, salary: r.salary, phone: r.phone, email: r.email, hire_date: r.hire_date, status: r.status }),
    aspects: { field: "status", options: [
      { value: "actif", label: "Actif" }, { value: "inactif", label: "Inactif" },
    ] },
  },
  {
    value: "prestataires", label: "Prestataires", entity: "Supplier", dateField: "created_date", companyScoped: true,
    columns: [
      { key: "name", label: "Nom" },
      { key: "category", label: "Spécialité" },
      { key: "contact_person", label: "Contact" },
      { key: "phone", label: "Téléphone" },
      { key: "email", label: "Email" },
      { key: "address", label: "Adresse" },
    ],
    toRow: (r) => ({ name: r.name, category: r.category, contact_person: r.contact_person, phone: r.phone, email: r.email, address: r.address }),
  },
  {
    value: "partenariats", label: "Partenariats", entity: "Partnership", dateField: "start_date", companyScoped: true,
    columns: [
      { key: "partner_name", label: "Partenaire" },
      { key: "partner_type", label: "Type" },
      { key: "contact_name", label: "Contact" },
      { key: "email", label: "Email" },
      { key: "phone", label: "Téléphone" },
      { key: "status", label: "Statut" },
      { key: "start_date", label: "Début", type: "date" },
    ],
    toRow: (r) => ({ partner_name: r.partner_name, partner_type: r.partner_type, contact_name: r.contact_name, email: r.email, phone: r.phone, status: r.status, start_date: r.start_date }),
    aspects: { field: "status", options: [
      { value: "prospect", label: "Prospect" }, { value: "actif", label: "Actif" }, { value: "inactif", label: "Inactif" },
    ] },
  },
  {
    value: "factures", label: "Factures", entity: "Invoice", dateField: "issue_date", companyScoped: true,
    columns: [
      { key: "number", label: "Numéro" },
      { key: "customer_name", label: "Client" },
      { key: "amount", label: "Montant", type: "currency" },
      { key: "issue_date", label: "Émission", type: "date" },
      { key: "due_date", label: "Échéance", type: "date" },
      { key: "status", label: "Statut" },
    ],
    toRow: (r) => ({ number: r.number, customer_name: r.customer_name, amount: r.amount, issue_date: r.issue_date, due_date: r.due_date, status: r.status }),
    aspects: { field: "status", options: [
      { value: "brouillon", label: "Brouillon" }, { value: "envoyee", label: "Envoyée" },
      { value: "payee", label: "Payée" }, { value: "en_retard", label: "En retard" },
    ] },
  },
];

export default function Export() {
  const { space, activeCompanyId, companies } = useSpace();
  const { toast } = useToast();
  const [section, setSection] = useState(space === "jbm" ? "ventes" : "finances");
  const [periodType, setPeriodType] = useState("mois");
  const now = new Date();
  const [period, setPeriod] = useState({
    year: now.getFullYear(), month: now.getMonth(), quarter: 1, half: 1, week: 1, from: "", to: "",
  });
  const [aspect, setAspect] = useState("tous");
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [cur, setCur] = useState("XAF");

  const cfg = SECTIONS.find((s) => s.value === section) || SECTIONS[0];
  const activeCompany = companies?.find((c) => c.id === activeCompanyId);

  // Devise depuis les préférences
  useEffect(() => {
    (async () => {
      try {
        const pr = await base44.entities.Preferences.list();
        setCur(pr?.[0]?.currency || "XAF");
      } catch { /* ignore */ }
    })();
  }, []);

  const load = async () => {
    setLoading(true);
    setRecords([]);
    try {
      let raw = [];
      if (section === "planning") {
        const [t, e] = await Promise.all([
          base44.entities.Task.list("-start", 2000),
          base44.entities.Event.list("-start", 2000),
        ]);
        raw = [
          ...(t || []).map((r) => ({ _type: "Tâche", company_id: r.company_id, title: r.title, start: r.start, end: r.end, status: r.status })),
          ...(e || []).map((r) => ({ _type: "Évènement", company_id: r.company_id, title: r.title, start: r.start, end: r.end, status: r.priority })),
        ];
      } else {
        raw = await base44.entities[cfg.entity].list("-created_date", 2000);
      }
      if (cfg.companyScoped && space === "jbm" && activeCompanyId) {
        raw = (raw || []).filter((r) => r.company_id === activeCompanyId);
      }
      setRecords(raw || []);
    } catch {
      setRecords([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [section, space, activeCompanyId]);

  const range = useMemo(() => computeRange(periodType, period), [periodType, period]);

  const filtered = useMemo(() => {
    const { start, end } = range;
    let rows = records.filter((r) => {
      const v = r[cfg.dateField];
      if (!v) return false;
      const d = new Date(v);
      return d >= start && d <= end;
    });
    if (aspect !== "tous" && cfg.aspects) {
      rows = rows.filter((r) => r[cfg.aspects.field] === aspect);
    }
    return rows.map((r) => cfg.toRow(r));
  }, [records, range, aspect, cfg, section]);

  const summary = useMemo(() => {
    const s = [
      { label: "Période", value: range.label },
      { label: "Nombre", value: String(filtered.length) },
    ];
    cfg.columns.filter((c) => c.type === "currency").forEach((c) => {
      const total = filtered.reduce((acc, r) => acc + (Number(r[c.key]) || 0), 0);
      s.push({ label: `${c.label} (total)`, value: formatCurrency(total, cur) });
    });
    return s;
  }, [filtered, cfg, range, cur]);

  const subtitle = space === "jbm"
    ? `Espace entreprise${activeCompany ? " · " + activeCompany.name : ""}`
    : "Espace personnel";

  const generate = (format) => {
    if (!filtered.length) {
      toast({ title: "Aucune donnée sur cette période", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const title = `${cfg.label} — ${range.label}`;
      if (format === "pdf") exportToPdf(title, subtitle, cfg.columns, filtered, cur, summary);
      else exportToXls(`${cfg.label} ${range.label}`, subtitle, cfg.columns, filtered, cur, summary);
      toast({ title: `Export ${format.toUpperCase()} généré` });
    } catch (e) {
      toast({ title: "Erreur lors de l'export", description: e?.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl flex items-center gap-2"><FileDown className="w-6 h-6" /> Exportations</h1>
        <p className="text-muted-foreground mt-1">
          Générez un rapport Excel ou PDF sur n'importe quelle période pour les tâches, évènements, finances, planning, calculs, devis, ventes, salariés, prestataires, partenariats et factures.
        </p>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 space-y-5">
        {/* Section */}
        <div className="space-y-1.5">
          <Label>Section</Label>
          <Select value={section} onValueChange={(v) => { setSection(v); setAspect("tous"); }}>
            <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
            <SelectContent>
              {SECTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Période */}
        <div className="space-y-1.5">
          <Label>Type de période</Label>
          <Select value={periodType} onValueChange={setPeriodType}>
            <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
            <SelectContent>
              {PERIOD_TYPES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {(periodType === "annee" || periodType === "mois" || periodType === "trimestre" || periodType === "semestre" || periodType === "semaine") && (
            <div className="space-y-1.5">
              <Label>Année</Label>
              <Select value={String(period.year)} onValueChange={(v) => setPeriod((p) => ({ ...p, year: Number(v) }))}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {yearOptions().map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {periodType === "mois" && (
            <div className="space-y-1.5">
              <Label>Mois</Label>
              <Select value={String(period.month)} onValueChange={(v) => setPeriod((p) => ({ ...p, month: Number(v) }))}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {monthOptions.map((m) => <SelectItem key={m.value} value={String(m.value)}>{m.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {periodType === "trimestre" && (
            <div className="space-y-1.5">
              <Label>Trimestre</Label>
              <Select value={String(period.quarter)} onValueChange={(v) => setPeriod((p) => ({ ...p, quarter: Number(v) }))}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {quarterOptions.map((q) => <SelectItem key={q.value} value={String(q.value)}>{q.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {periodType === "semestre" && (
            <div className="space-y-1.5">
              <Label>Semestre</Label>
              <Select value={String(period.half)} onValueChange={(v) => setPeriod((p) => ({ ...p, half: Number(v) }))}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {halfOptions.map((h) => <SelectItem key={h.value} value={String(h.value)}>{h.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {periodType === "semaine" && (
            <div className="space-y-1.5">
              <Label>Semaine (n°)</Label>
              <Select value={String(period.week)} onValueChange={(v) => setPeriod((p) => ({ ...p, week: Number(v) }))}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {weekOptions.map((w) => <SelectItem key={w} value={String(w)}>{w}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {periodType === "personnalisee" && (
            <>
              <div className="space-y-1.5">
                <Label>Du</Label>
                <Input type="date" value={period.from} onChange={(e) => setPeriod((p) => ({ ...p, from: e.target.value }))} />
              </div>
              <div className="space-y-1.5">
                <Label>Au</Label>
                <Input type="date" value={period.to} onChange={(e) => setPeriod((p) => ({ ...p, to: e.target.value }))} />
              </div>
            </>
          )}
        </div>

        {/* Aspect (filtre optionnel) */}
        {cfg.aspects && (
          <div className="space-y-1.5">
            <Label>Aspect (filtre)</Label>
            <Select value={aspect} onValueChange={setAspect}>
              <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="tous">Tous</SelectItem>
                {cfg.aspects.options.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Résumé */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {summary.map((s) => (
            <div key={s.label} className="bg-secondary/40 rounded-xl px-3 py-2">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="text-sm font-medium truncate">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => generate("pdf")} disabled={busy || loading || !filtered.length}>
            {busy ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileText className="w-4 h-4 mr-2" />}
            Exporter PDF
          </Button>
          <Button onClick={() => generate("xls")} disabled={busy || loading || !filtered.length} variant="outline">
            <Sheet className="w-4 h-4 mr-2" />
            Exporter Excel
          </Button>
        </div>
      </div>

      {/* Aperçu */}
      <div className="bg-card border border-border rounded-2xl p-5">
        <h2 className="font-display text-lg mb-3">Aperçu ({filtered.length})</h2>
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
        ) : filtered.length === 0 ? (
          <p className="text-sm text-muted-foreground">Aucun enregistrement sur cette période.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-muted-foreground">
                  {cfg.columns.map((c) => <th key={c.key} className="py-2 pr-3 whitespace-nowrap">{c.label}</th>)}
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 8).map((r, i) => (
                  <tr key={i} className="border-t border-border">
                    {cfg.columns.map((c) => (
                      <td key={c.key} className="py-2 pr-3 whitespace-nowrap">
                        {c.type === "currency" ? formatCurrency(Number(r[c.key]) || 0, cur)
                          : c.type === "date" ? (r[c.key] ? new Date(r[c.key]).toLocaleDateString("fr-FR") : "")
                          : String(r[c.key] ?? "")}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length > 8 && <p className="text-xs text-muted-foreground mt-2">+ {filtered.length - 8} autres lignes dans le fichier exporté.</p>}
          </div>
        )}
      </div>
    </div>
  );
}