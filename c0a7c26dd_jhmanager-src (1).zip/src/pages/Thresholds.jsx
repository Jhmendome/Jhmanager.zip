import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Gauge, Save, RefreshCw, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { getLevel, LEVEL_STYLE, LEVEL_LABEL } from "@/lib/thresholds";
import { formatCurrency } from "@/lib/format";

const DOMAINS = [
  { value: "budget", label: "Budget restant (XAF)", direction: "low", measure: (d) => d.budget, money: true },
  { value: "stock", label: "Valeur du stock (XAF)", direction: "low", measure: (d) => d.stock, money: true },
  { value: "invoices", label: "Factures impayées (XAF)", direction: "high", measure: (d) => d.invoices, money: true },
  { value: "tasks", label: "Tâches en retard (nombre)", direction: "high", measure: (d) => d.tasks, money: false },
];

export default function Thresholds() {
  const { toast } = useToast();
  const [th, setTh] = useState([]);
  const [data, setData] = useState({ budget: 0, stock: 0, invoices: 0, tasks: 0 });
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);

  const load = async () => {
    try {
      const [list, prefs, exp, prod, inv, tsk] = await Promise.all([
        base44.entities.Threshold.list("-created_date", 50),
        base44.entities.Preferences.list(),
        base44.entities.Expense.list("-date", 500),
        base44.entities.Product.list("-created_date", 500),
        base44.entities.Invoice.list("-issue_date", 500),
        base44.entities.Task.list("-start", 500),
      ]);
      const map = {};
      (list || []).forEach((x) => { map[x.domain] = x; });
      setTh(Object.values(map));
      const budget = (prefs?.[0]?.initial_budget || 0) - (exp || []).reduce((s, e) => s + (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0), 0);
      const stock = (prod || []).reduce((s, p) => s + (Number(p.quantity) || 0) * (Number(p.unit_cost) || 0), 0);
      const invoices = (inv || []).filter((i) => i.status !== "payee").reduce((s, i) => s + (Number(i.amount) || 0), 0);
      const now = new Date();
      const tasks = (tsk || []).filter((x) => x.status !== "terminee" && new Date(x.end) < now).length;
      setData({ budget, stock, invoices, tasks });
      const init = {};
      DOMAINS.forEach((d) => {
        const r = map[d.value];
        init[d.value] = { medium: r?.medium_value ?? "", critical: r?.critical_value ?? "", id: r?.id || null };
      });
      setForm(init);
    } catch { /* ignore */ }
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const saveDomain = async (d) => {
    const f = form[d.value];
    if (f.medium === "" || f.critical === "") { toast({ title: "Renseignez les deux seuils", variant: "destructive" }); return; }
    const payload = { domain: d.value, medium_value: Number(f.medium) || 0, critical_value: Number(f.critical) || 0 };
    try {
      if (f.id) await base44.entities.Threshold.update(f.id, payload);
      else { const c = await base44.entities.Threshold.create(payload); setForm((cur) => ({ ...cur, [d.value]: { ...cur[d.value], id: c.id } })); }
      toast({ title: "Seuil enregistré" });
      load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="font-display text-3xl flex items-center gap-2"><Gauge className="w-7 h-7" /> Seuils & alertes</h1>
        <p className="text-muted-foreground mt-1">Définissez des seuils moyen et critique par domaine. L'état actuel est calculé automatiquement.</p>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h2 className="font-display text-lg">Alertes automatisées</h2>
          <p className="text-sm text-muted-foreground">Vérifie les seuils et crée des notifications (rappels) quand un seuil moyen ou critique est atteint. La vérification se lance aussi automatiquement une fois par jour à l'ouverture du tableau de bord.</p>
        </div>
        <Button onClick={async () => {
          setChecking(true);
          try {
      const res = await base44.functions.invoke('checkAlerts', {});
            toast({ title: res?.count ? `${res.count} alerte(s) générée(s)` : "Aucune alerte à générer" });
          } catch { toast({ title: "Erreur", variant: "destructive" }); }
          setChecking(false);
        }}>
          {checking ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <RefreshCw className="w-4 h-4 mr-2" />} Vérifier maintenant
        </Button>
      </div>
      {DOMAINS.map((d) => {
        const f = form[d.value] || { medium: "", critical: "" };
        const cur = d.measure(data);
        const level = getLevel(d.value, cur, th, d.direction);
        const disp = d.money ? formatCurrency(cur, "XAF") : cur;
        return (
          <div key={d.value} className="bg-card border border-border rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-display text-lg">{d.label}</h2>
              <span className={`text-xs px-2 py-0.5 rounded-full ${LEVEL_STYLE[level]}`}>{LEVEL_LABEL[level]}</span>
            </div>
            <p className="text-sm text-muted-foreground">Valeur actuelle : <span className="font-medium text-foreground">{disp}</span></p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Seuil moyen</Label><Input type="number" value={f.medium} onChange={(e) => setForm((c) => ({ ...c, [d.value]: { ...c[d.value], medium: e.target.value } }))} /></div>
              <div className="space-y-1"><Label>Seuil critique</Label><Input type="number" value={f.critical} onChange={(e) => setForm((c) => ({ ...c, [d.value]: { ...c[d.value], critical: e.target.value } }))} /></div>
            </div>
            <Button size="sm" onClick={() => saveDomain(d)}><Save className="w-4 h-4 mr-1" /> Enregistrer</Button>
          </div>
        );
      })}
    </div>
  );
}