import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Lightbulb, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { formatDateFr } from "@/lib/format";

const CAT = { amelioration: "Amélioration", correction: "Correction", autre: "Autre" };

export default function SuggestionsPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("amelioration");
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const load = async () => {
    const list = await base44.entities.Suggestion.list("-created_date", 200);
    setItems(list || []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    setSubmitting(true);
    try {
      await base44.entities.Suggestion.create({ content: content.trim(), category, status: "nouveau" });
      toast({ title: "Merci ! Votre suggestion a été envoyée." });
      setContent("");
      load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
    setSubmitting(false);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl">Suggestions</h1>
        <p className="text-muted-foreground mt-1">Proposez des améliorations ou signalez des corrections. Vos idées nous aident à améliorer JM.</p>
      </div>

      <form onSubmit={submit} className="bg-card border border-border rounded-2xl p-5 space-y-3">
        <div className="space-y-2"><Label>Catégorie</Label>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{Object.entries(CAT).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-2"><Label>Votre suggestion</Label><Textarea value={content} onChange={(e) => setContent(e.target.value)} rows={4} placeholder="Décrivez votre idée d'amélioration ou le problème rencontré…" /></div>
        <Button type="submit" disabled={submitting} className="w-full">
          {submitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Envoi…</> : <><Lightbulb className="w-4 h-4 mr-2" /> Envoyer</>}
        </Button>
      </form>

      <div>
        <h2 className="font-display text-lg mb-3">Vos suggestions</h2>
        {loading ? (
          <div className="flex items-center justify-center h-32"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>
        ) : items.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">Aucune suggestion pour l'instant.</p>
        ) : (
          <div className="space-y-2">
            {items.map((s) => (
              <div key={s.id} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-secondary">{CAT[s.category] || s.category}</span>
                  <span className="text-xs text-muted-foreground">{formatDateFr(s.created_date, true)}</span>
                </div>
                <p className="text-sm">{s.content}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-accent/5 border border-accent/30 rounded-2xl p-4 flex items-start gap-2">
        <Sparkles className="w-4 h-4 text-accent shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">Vos suggestions sont analysées par notre IA : les idées similaires sont regroupées pour ne garder que des propositions uniques sur le tableau de bord administrateur.</p>
      </div>
    </div>
  );
}