import React from "react";
import { useAuth } from "@/lib/AuthContext";
import Landing from "@/pages/Landing";
import Onboarding from "@/pages/Onboarding";
import Dashboard from "@/pages/Dashboard";
import BusinessDashboard from "@/pages/BusinessDashboard";

export default function Home() {
  const { user, isLoadingAuth } = useAuth();

  if (isLoadingAuth || (user === undefined)) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
      </div>
    );
  }

  // Visiteur non connecté → page d'accueil publique.
  if (!user) return <Landing />;

  const accountType = user?.data?.account_type || user?.account_type;

  // Utilisateur connecté sans abonnement (non admin) → onboarding.
  if (!accountType && user.role !== "admin") return <Onboarding />;

  // Admin → tableau de bord avec bascule JPM/JBM.
  if (user.role === "admin") return <Dashboard />;

  // Entreprise → espace JBM.
  if (accountType === "entreprise") return <BusinessDashboard />;

  // Particulier → espace JPM.
  return <Dashboard />;
}