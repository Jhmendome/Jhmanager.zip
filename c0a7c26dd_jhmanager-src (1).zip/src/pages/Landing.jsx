import React from "react";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import {
  Wallet, ListChecks, CalendarRange, Bot, Building2, Boxes, ShoppingCart, FileText,
  Users, Gift, User, Check, ArrowRight, Sparkles, ShieldCheck, Handshake, Star, Zap,
  ChevronDown, Calculator, Bell, BarChart3, CalendarDays, Tag, UsersRound, HelpCircle,
  TrendingDown, CalendarClock, Gauge,
} from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import FaqSection from "@/components/landing/FaqSection";

const BRAND = "JH Manager";
const SHORT = "JH Personal Manager";
const BIZ = "JH Business Manager";

function useCta() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const accountType = user?.data?.account_type || user?.account_type;
  const authed = !!user;
  const go = (path) => navigate(path);
  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  return {
    authed,
    hasAccount: !!accountType,
    isParticulier: accountType === "particulier",
    isEntreprise: accountType === "entreprise",
    scrollTo,
    subscribe: (type) => {
      if (authed && !accountType) go("/");
      else if (!authed) go("/register?returnTo=/");
      else go("/");
    },
    affiliation: () => (authed ? go("/affiliation") : go("/register?returnTo=/affiliation")),
  };
}

function GradientBlob({ className }) {
  return (
    <div className={`pointer-events-none absolute rounded-full blur-3xl opacity-40 ${className}`} />
  );
}

export default function Landing() {
  const cta = useCta();

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* HERO */}
      <header className="relative px-4 pt-12 pb-16 sm:pt-16">
        <GradientBlob className="bg-primary/30 w-72 h-72 -top-10 -left-10" />
        <GradientBlob className="bg-accent/30 w-80 h-80 top-10 right-0" />
        <div className="relative max-w-5xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-4"
          >
            <Sparkles className="w-3.5 h-3.5" /> {BRAND} · {SHORT} + {BIZ}
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
            className="font-display text-4xl sm:text-6xl leading-tight"
          >
            Reprenez le contrôle de votre{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">vie personnelle</span>{" "}
            et de votre{" "}
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">entreprise</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="text-muted-foreground mt-5 max-w-xl mx-auto text-base sm:text-lg"
          >
            {BRAND} centralise tout : finances, tâches, planning côté perso ({SHORT}), stock, ventes et partenariats
            côté entreprise ({BIZ}). Un seul compte, payé via Mobile Money.
          </motion.p>

          {/* Boutons d'accès rapide en haut */}
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.13 }}
            className="mt-6 inline-flex flex-wrap items-center justify-center gap-2 sm:gap-3"
          >
            <button
              onClick={() => cta.scrollTo("abonnements")}
              className="no-select-tap min-touch inline-flex items-center gap-2 rounded-full bg-primary text-primary-foreground px-4 py-2.5 text-sm font-medium hover:bg-primary/90 transition-colors shadow-sm"
            >
              <User className="w-4 h-4" /> Abonnement particulier <ChevronDown className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => cta.scrollTo("abonnements")}
              className="no-select-tap min-touch inline-flex items-center gap-2 rounded-full bg-accent text-accent-foreground px-4 py-2.5 text-sm font-medium hover:bg-accent/90 transition-colors shadow-sm"
            >
              <Building2 className="w-4 h-4" /> Abonnement entreprise <ChevronDown className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => cta.scrollTo("affiliation")}
              className="no-select-tap min-touch inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 text-accent-foreground px-4 py-2.5 text-sm font-medium hover:bg-accent/20 transition-colors shadow-sm"
            >
              <Gift className="w-4 h-4" /> Devenir affilié <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.16 }}
            className="mt-5 flex flex-col sm:flex-row gap-3 justify-center"
          >
            <Link to="#abonnements" className="no-select-tap min-touch inline-flex items-center justify-center gap-2 rounded-xl bg-primary text-primary-foreground px-6 py-3 font-medium hover:bg-primary/90 transition-colors">
              Voir les abonnements <ArrowRight className="w-4 h-4" />
            </Link>
            <button onClick={cta.affiliation} className="no-select-tap min-touch inline-flex items-center justify-center gap-2 rounded-xl border border-accent/40 bg-accent/10 text-accent-foreground px-6 py-3 font-medium hover:bg-accent/20 transition-colors">
              <Gift className="w-4 h-4" /> Programme d'affiliation
            </button>
          </motion.div>
          {cta.authed && cta.hasAccount && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6">
              <Link to="/" className="text-sm text-primary font-medium hover:underline inline-flex items-center gap-1">
                Accéder à mon espace {cta.isEntreprise ? BIZ : SHORT} <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </motion.div>
          )}
        </div>
      </header>

      {/* PRÉSENTATION PLATEFORME */}
      <section className="px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <SectionTitle eyebrow="La plateforme" title="Deux espaces, une seule application" />
          <p className="text-center text-muted-foreground mt-3 max-w-2xl mx-auto text-sm">
            {BRAND} sépare clairement votre vie personnelle ({SHORT}) de votre activité professionnelle ({BIZ}),
            tout en gardant tout au même endroit, accessible depuis votre téléphone.
          </p>
          <div className="grid sm:grid-cols-3 gap-4 mt-8">
            {[
              { icon: Zap, t: "Centralisé", d: "Finances, tâches, entreprise : un seul point d'entrée." },
              { icon: ShieldCheck, t: "Sécurisé", d: "Vos données restent privées, accessibles partout." },
              { icon: Bot, t: "Assisté par IA", d: "Des assistants intégrés pour vous guider au quotidien." },
            ].map((f, i) => (
              <motion.div key={f.t} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="rounded-2xl border border-border bg-card p-5">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                  <f.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display text-lg">{f.t}</h3>
                <p className="text-sm text-muted-foreground mt-1">{f.d}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FONCTIONNALITÉS — description claire et concise */}
      <section className="px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <SectionTitle eyebrow="Fonctionnalités" title="Tout ce dont vous avez besoin" />
          <p className="text-center text-muted-foreground mt-3 max-w-2xl mx-auto text-sm">
            Chaque section a un rôle précis. Voici un aperçu de ce que vous trouverez dans {BRAND}.
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
            {FEATURES.map((f, i) => (
              <motion.div key={f.t} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: (i % 3) * 0.05 }}
                className="rounded-2xl border border-border bg-card p-5 hover:shadow-md transition-shadow">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/15 to-accent/15 flex items-center justify-center mb-3">
                  <f.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display text-base">{f.t}</h3>
                <p className="text-sm text-muted-foreground mt-1">{f.d}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* SHORT */}
      <section className="px-4 py-12">
        <div className="max-w-4xl mx-auto rounded-3xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 p-6 sm:p-10 relative overflow-hidden">
          <GradientBlob className="bg-primary/20 w-60 h-60 -bottom-10 -right-10" />
          <div className="relative">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-medium mb-4">
              <User className="w-3.5 h-3.5" /> {SHORT} — Gestion personnelle
            </div>
            <h2 className="font-display text-2xl sm:text-3xl">Gérez votre quotidien en toute sérénité</h2>
            <p className="text-muted-foreground mt-2 max-w-xl">
              Budget, dépenses, taxes, emprunts, tâches, planning et événements réunis pour garder le fil de votre vie personnelle.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-6">
              {[
                { icon: Wallet, t: "Finances & budget" },
                { icon: ListChecks, t: "Tâches & to-do" },
                { icon: CalendarRange, t: "Planning & calendrier" },
                { icon: Bot, t: "Assistant IA" },
                { icon: Zap, t: "Calculatrice pro" },
                { icon: Users, t: "Collaboration" },
              ].map((f) => (
                <div key={f.t} className="flex items-center gap-2 rounded-xl bg-card/70 p-3 text-sm">
                  <f.icon className="w-4 h-4 text-primary shrink-0" /> {f.t}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* BIZ */}
      <section className="px-4 py-12">
        <div className="max-w-4xl mx-auto rounded-3xl bg-gradient-to-br from-accent/10 to-accent/5 border border-accent/20 p-6 sm:p-10 relative overflow-hidden">
          <GradientBlob className="bg-accent/20 w-60 h-60 -bottom-10 -left-10" />
          <div className="relative">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent text-accent-foreground text-xs font-medium mb-4">
              <Building2 className="w-3.5 h-3.5" /> {BIZ} — Gestion d'entreprise
            </div>
            <h2 className="font-display text-2xl sm:text-3xl">Pilotez votre activité comme un pro</h2>
            <p className="text-muted-foreground mt-2 max-w-xl">
              Stock, ventes, clients, devis, taxes et partenariats : tout l'outil métier, en mobilité.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-6">
              {[
                { icon: Boxes, t: "Stock & inventaire" },
                { icon: ShoppingCart, t: "Ventes & clients" },
                { icon: FileText, t: "Devis" },
                { icon: Handshake, t: "Partenariats" },
                { icon: Bot, t: "Assistant IA" },
                { icon: Star, t: "Reporting" },
              ].map((f) => (
                <div key={f.t} className="flex items-center gap-2 rounded-xl bg-card/70 p-3 text-sm">
                  <f.icon className="w-4 h-4 text-accent-foreground shrink-0" /> {f.t}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ABONNEMENTS */}
      <section id="abonnements" className="px-4 py-14 scroll-mt-4">
        <div className="max-w-4xl mx-auto">
          <SectionTitle eyebrow="Tarifs" title="Choisissez votre espace" />
          <p className="text-center text-muted-foreground mt-3 max-w-2xl mx-auto text-sm">
            Un seul abonnement via Mobile Money (Airtel Money ou Moov Money, Gabon). Aucune carte bancaire requise.
          </p>
          <div className="grid sm:grid-cols-2 gap-5 mt-8">
            <PricingCard
              tone="primary" icon={User} badge={SHORT} title="Abonnement Particulier"
              price="5 000" unit="XAF / mois"
              features={["Finances & budget personnel", "Tâches, planning, calendrier", "Assistant IA", "Collaboration & calculatrice"]}
              ctaLabel="Prendre un abonnement particulier"
              onCta={() => cta.subscribe("particulier")}
              authedDone={cta.authed && cta.hasAccount && cta.isParticulier}
            />
            <PricingCard
              tone="accent" icon={Building2} badge={BIZ} title="Abonnement Entreprise"
              price="20 000" unit="XAF / mois / entreprise"
              features={["Stock & inventaire", "Ventes, clients & devis", "Taxes & partenariats", "Assistant IA", "Multi-entreprises"]}
              ctaLabel="Prendre un abonnement entreprise"
              onCta={() => cta.subscribe("entreprise")}
              authedDone={cta.authed && cta.hasAccount && cta.isEntreprise}
            />
          </div>

          <div id="affiliation" className="scroll-mt-4 mt-5" />
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            className="mt-2 rounded-2xl border border-accent/30 bg-gradient-to-r from-accent/10 to-primary/5 p-5 flex flex-col sm:flex-row items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-accent text-accent-foreground flex items-center justify-center shrink-0">
              <Gift className="w-6 h-6" />
            </div>
            <div className="flex-1 text-center sm:text-left">
              <h3 className="font-display text-lg">Programme d'affiliation</h3>
              <p className="text-sm text-muted-foreground">
                Parrainez et gagnez 20 % de chaque abonnement (1 000 XAF/mois par particulier, 4 000 XAF/mois par entreprise). Le filleul profite de 20 % de réduction pendant 6 mois.
              </p>
            </div>
            <button onClick={cta.affiliation} className="no-select-tap min-touch rounded-xl bg-accent text-accent-foreground px-5 py-2.5 font-medium hover:bg-accent/90 transition-colors shrink-0">
              Devenir affilié
            </button>
          </motion.div>
        </div>
      </section>

      {/* FAQ */}
      <FaqSection />

      {/* FOOTER */}
      <footer className="border-t border-border px-4 py-10">
        <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <span className="font-display text-xl text-foreground">{BRAND}</span>
            <span>· Gestion tout-en-un</span>
          </div>
          <div className="flex gap-4">
            <Link to="/conditions" className="hover:text-foreground">Conditions</Link>
            <Link to="/confidentialite" className="hover:text-foreground">Confidentialité</Link>
            <Link to="/login" className="hover:text-foreground">Connexion</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}

const FEATURES = [
  { icon: Wallet, t: "Finances", d: "Budgets périodiques, dépenses, taxes (en % ou montant) et emprunts avec intérêts." },
  { icon: ListChecks, t: "Tâches", d: "Tâches ponctuelles ou périodiques, durée en minutes à mois, dates et heures." },
  { icon: CalendarClock, t: "Événements", d: "Activités, RDV et cérémonies avec rappels et catégories." },
  { icon: CalendarDays, t: "Calendrier", d: "Vue mensuelle des tâches et événements avec horaires." },
  { icon: CalendarRange, t: "Planning", d: "Planification claire de vos tâches et événements." },
  { icon: BarChart3, t: "Reporting", d: "Évolution des finances et activités + rapports PDF ou tableur." },
  { icon: Bot, t: "Assistants IA", d: "Conversation, upload et génération de fichiers multimédia par l'IA." },
  { icon: Calculator, t: "Calculateur", d: "Calculs, grandeurs, formules, opérations sur dates et historique." },
  { icon: UsersRound, t: "Collaborateurs", d: "Invitations, groupes administrés, chat, tâches et finances partagées." },
  { icon: Boxes, t: "Stock", d: "Articles, quantités, ajouts/retraits et ajouts périodiques automatiques." },
  { icon: ShoppingCart, t: "Ventes", d: "Import depuis le stock, services, tarification par formule, ventes périodiques." },
  { icon: Users, t: "Personnel", d: "Postes, salaires périodiques, primes, présences et discipline." },
  { icon: Handshake, t: "Partenariats", d: "Partenaires, modalités et notes traitées par l'IA." },
  { icon: Bell, t: "Notifications", d: "Rappels d'échéances, budget, messages, invitations et résumé matinal." },
  { icon: Gauge, t: "Seuils & alertes", d: "Alertes personnalisées sur budget, durée ou date." },
  { icon: Tag, t: "Catégories", d: "Rangez vos données par catégories prédéfinies dans chaque section." },
  { icon: Gift, t: "Affiliation", d: "Parrainez et gagnez 20 % sur chaque abonnement, à vie." },
];

function SectionTitle({ eyebrow, title }) {
  return (
    <div className="text-center">
      <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
        className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/15 text-accent-foreground text-xs font-medium mb-3">
        <Sparkles className="w-3.5 h-3.5" /> {eyebrow}
      </motion.div>
      <h2 className="font-display text-3xl sm:text-4xl">{title}</h2>
    </div>
  );
}

function PricingCard({ tone, icon: Icon, badge, title, price, unit, features, ctaLabel, onCta, authedDone }) {
  const isAccent = tone === "accent";
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
      className={`rounded-3xl border p-6 flex flex-col ${isAccent ? "border-accent/30 bg-accent/5" : "border-primary/30 bg-primary/5"}`}
    >
      <div className="flex items-center gap-3">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isAccent ? "bg-accent text-accent-foreground" : "bg-primary text-primary-foreground"}`}>
          <Icon className="w-6 h-6" />
        </div>
        <span className={`text-xs font-medium px-2 py-1 rounded-full ${isAccent ? "bg-accent/15 text-accent-foreground" : "bg-primary/10 text-primary"}`}>{badge}</span>
      </div>
      <h3 className="font-display text-xl mt-4">{title}</h3>
      <div className="mt-2 flex items-baseline gap-1">
        <span className="font-display text-4xl">{price}</span>
        <span className="text-sm text-muted-foreground">{unit}</span>
      </div>
      <ul className="mt-4 space-y-2 flex-1">
        {features.map((f) => (
          <li key={f} className="flex items-center gap-2 text-sm">
            <Check className={`w-4 h-4 shrink-0 ${isAccent ? "text-accent-foreground" : "text-primary"}`} /> {f}
          </li>
        ))}
      </ul>
      {authedDone ? (
        <div className="mt-5 rounded-xl bg-primary/10 text-primary text-sm font-medium py-2.5 text-center">
          Abonnement actif ✓
        </div>
      ) : (
        <button onClick={onCta} className={`no-select-tap mt-5 min-touch w-full rounded-xl font-medium py-3 transition-colors ${isAccent ? "bg-accent text-accent-foreground hover:bg-accent/90" : "bg-primary text-primary-foreground hover:bg-primary/90"}`}>
          {ctaLabel}
        </button>
      )}
    </motion.div>
  );
}