import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Users, MessageSquare, Inbox, Plus, Search, Check, X, Link2Off, Loader2, Crown, Flag } from "lucide-react";
import UserSearch from "@/components/collab/UserSearch";
import CompanySearch from "@/components/collab/CompanySearch";
import ChatView from "@/components/collab/ChatView";
import GroupAdmin from "@/components/collab/GroupAdmin";
import SharedPanel from "@/components/collab/SharedPanel";
import ReportDialog from "@/components/collab/ReportDialog";
import { useToast } from "@/components/ui/use-toast";

export default function Collaborateurs() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [nameMap, setNameMap] = useState({});
  const [tab, setTab] = useState("collab");
  const [collaborators, setCollaborators] = useState([]);
  const [requests, setRequests] = useState([]);       // reçues
  const [collaborations, setCollaborations] = useState([]);
  const [groups, setGroups] = useState([]);
  const [groupInvites, setGroupInvites] = useState([]); // reçues
  const [selected, setSelected] = useState(null);      // conversation courante
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState("");
  const [q, setQ] = useState("");
  const [pickResults, setPickResults] = useState([]);
  const [picked, setPicked] = useState([]);
  const [busy, setBusy] = useState(false);
  const [reportTarget, setReportTarget] = useState(null);
  const { toast } = useToast();

  const loadAll = async () => {
    if (!user) return;
    try {
      const [cols, reqs, colls, grps, ginv] = await Promise.all([
        base44.entities.Collaborator.list("-created_date", 500),
        base44.entities.CollaborationRequest.list("-created_date", 200),
        base44.entities.Collaboration.list("-created_date", 200),
        base44.entities.Group.list("-created_date", 200),
        base44.entities.GroupInvite.list("-created_date", 200),
      ]);
      setCollaborators(cols || []);
      const map = {};
      (cols || []).forEach((c) => { map[c.created_by_id] = c.display_name; });
      setNameMap(map);
      setRequests((reqs || []).filter((r) => r.to_user_id === user.id && r.status === "pending"));
      setCollaborations(colls || []);
      setGroups(grps || []);
      setGroupInvites((ginv || []).filter((i) => i.to_user_id === user.id && i.status === "pending"));
      const mine = (cols || []).find((c) => c.created_by_id === user.id);
      setProfile(mine || null);
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    }
  };

  // Crée automatiquement le profil collaborateur au premier accès
  const ensureProfile = async () => {
    if (!user) return;
    try {
      const existing = await base44.entities.Collaborator.filter({ created_by_id: user.id });
      if (existing && existing.length) { setProfile(existing[0]); return; }
      const created = await base44.entities.Collaborator.create({ display_name: user.full_name || user.email || "Utilisateur" });
      setProfile(created);
    } catch { /* ignore */ }
  };

  useEffect(() => { ensureProfile(); loadAll(); /* eslint-disable-next-line */ }, [user?.id]);

  const reload = () => { loadAll(); };

  const pendingInviteCount = requests.length + groupInvites.length;

  const acceptRequest = async (r) => {
    setBusy(true);
    try {
      await base44.entities.Collaboration.create({ members: [r.created_by_id, user.id], partner_name: nameMap[r.created_by_id] || "" });
      await base44.entities.CollaborationRequest.update(r.id, { status: "accepted" });
      reload();
    } catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const rejectRequest = async (r) => {
    setBusy(true);
    try { await base44.entities.CollaborationRequest.update(r.id, { status: "rejected" }); reload(); }
    catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const breakCollab = async (c) => {
    if (!confirm("Rompre cette collaboration ? L'autre membre sera retiré des groupes dont vous êtes créateur (et inversement).")) return;
    setBusy(true);
    try { await base44.functions.invoke('breakCollaboration', { collaboration_id: c.id }); setSelected(null); reload(); }
    catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const acceptGroupInvite = async (inv) => {
    setBusy(true);
    try { await base44.functions.invoke('manageGroup', { action: "accept_invite", invite_id: inv.id }); reload(); }
    catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const rejectGroupInvite = async (inv) => {
    setBusy(true);
    try { await base44.entities.GroupInvite.update(inv.id, { status: "rejected" }); reload(); }
    catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const searchPick = async () => {
    const term = q.trim();
    if (term.length < 2) { setPickResults([]); return; }
    const list = await base44.entities.Collaborator.list("-created_date", 200);
    const t = term.toLowerCase();
    setPickResults((list || []).filter((c) => (c.display_name || "").toLowerCase().includes(t) && c.created_by_id !== user.id));
  };

  const createGroup = async () => {
    if (!newName.trim()) { toast({ title: "Donnez un nom au groupe" }); return; }
    setBusy(true);
    try {
      const g = await base44.entities.Group.create({ name: newName.trim(), members: [user.id], admins: [] });
      for (const p of picked) {
        await base44.entities.GroupInvite.create({ group_id: g.id, group_name: g.name, to_user_id: p.created_by_id, to_name: p.display_name, status: "pending" });
      }
      setShowCreate(false); setNewName(""); setPicked([]); setPickResults([]); setQ("");
      setTab("groupes"); reload();
      toast({ title: "Groupe créé", description: `${picked.length} invitation(s) envoyée(s)` });
    } catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  if (!user) return <div className="p-6 flex justify-center"><Loader2 className="w-5 h-5 animate-spin" /></div>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl flex items-center gap-2"><Users className="w-6 h-6 text-accent" /> Collaborateurs</h1>
        <p className="text-muted-foreground mt-1">Échangez en 1-à-1, créez des groupes et travaillez ensemble.</p>
      </div>

      <div className="flex gap-2 border-b border-border">
        <TabBtn active={tab === "collab"} onClick={() => setTab("collab")} icon={<MessageSquare className="w-4 h-4" />} label="Collaborations" />
        <TabBtn active={tab === "groupes"} onClick={() => setTab("groupes")} icon={<Users className="w-4 h-4" />} label="Groupes" />
        <TabBtn active={tab === "invites"} onClick={() => setTab("invites")} icon={<Inbox className="w-4 h-4" />} label="Invitations" badge={pendingInviteCount} />
      </div>

      {tab === "collab" && (
        <div className="space-y-4">
          <div className="bg-card border border-border rounded-2xl p-3">
            <p className="text-xs font-medium text-muted-foreground mb-2">Trouver un collaborateur</p>
            <UserSearch currentUserId={user.id} excludeIds={collaborations.flatMap((c) => c.members || [])} onSent={reload} />
          </div>
          <div className="bg-card border border-border rounded-2xl p-3">
            <p className="text-xs font-medium text-muted-foreground mb-2">Trouver une entreprise (par type et/ou lieu)</p>
            <CompanySearch currentUserId={user.id} excludeIds={collaborations.flatMap((c) => c.members || [])} onSent={reload} />
          </div>

          {collaborations.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">Aucune collaboration active.</p>
          ) : (
            <div className="space-y-2">
              {collaborations.map((c) => {
                const other = (c.members || []).find((m) => m !== user.id);
                return (
                  <div key={c.id} className="bg-card border border-border rounded-2xl p-3">
                    <div className="flex items-center justify-between">
                      <button onClick={() => setSelected({ type: "direct", id: c.id, participants: c.members, group: null, label: nameMap[other] || other })} className="flex items-center gap-2 min-w-0">
                        <div className="w-9 h-9 rounded-full bg-primary/15 text-primary flex items-center justify-center text-sm font-medium">{(nameMap[other] || "?").charAt(0).toUpperCase()}</div>
                        <span className="text-sm font-medium truncate">{nameMap[other] || other}</span>
                      </button>
                      <div className="flex items-center gap-1">
                        <Button size="sm" variant="ghost" onClick={() => breakCollab(c)} className="flex items-center gap-1 text-destructive"><Link2Off className="w-4 h-4" /> Rompre</Button>
                        <Button size="sm" variant="ghost" onClick={() => setReportTarget({ type: "user", id: other, name: nameMap[other] || other })} title="Signaler"><Flag className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {selected && selected.type === "direct" && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">Conversation avec {selected.label}</p>
                <Button size="sm" variant="ghost" onClick={() => setSelected(null)}>Fermer</Button>
              </div>
              <ChatView conversationType="direct" conversationId={selected.id} participants={selected.participants} group={null} currentUserId={user.id} />
              <SharedPanel conversation={selected} currentUserId={user.id} nameMap={nameMap} />
            </div>
          )}
        </div>
      )}

      {tab === "groupes" && (
        <div className="space-y-4">
          <Button onClick={() => setShowCreate(true)} className="flex items-center gap-1"><Plus className="w-4 h-4" /> Créer un groupe</Button>

          {groups.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">Aucun groupe. Créez-en un.</p>
          ) : (
            <div className="space-y-2">
              {groups.map((g) => (
                <div key={g.id} className="bg-card border border-border rounded-2xl p-3">
                  <button onClick={() => setSelected({ type: "group", id: g.id, participants: g.members, group: g, label: g.name })} className="w-full text-left">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium flex items-center gap-1.5">{g.name} {g.created_by_id === user.id && <Crown className="w-3.5 h-3.5 text-accent" />}</span>
                      <span className="text-xs text-muted-foreground">{(g.members || []).length} membre(s)</span>
                    </div>
                  </button>
                  <div className="flex justify-end mt-2">
                    <Button size="sm" variant="ghost" onClick={() => setReportTarget({ type: "group", id: g.id, name: g.name })} className="flex items-center gap-1 text-muted-foreground"><Flag className="w-4 h-4" /> Signaler</Button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {selected && selected.type === "group" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">{selected.label}</p>
                <Button size="sm" variant="ghost" onClick={() => setSelected(null)}>Fermer</Button>
              </div>
              <ChatView conversationType="group" conversationId={selected.id} participants={selected.participants} group={groups.find((g) => g.id === selected.id)} currentUserId={user.id} />
              <GroupAdmin group={groups.find((g) => g.id === selected.id)} currentUserId={user.id} nameMap={nameMap} onChanged={reload} />
              <SharedPanel conversation={selected} currentUserId={user.id} nameMap={nameMap} />
            </div>
          )}
        </div>
      )}

      {tab === "invites" && (
        <div className="space-y-4">
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Demandes de collaboration</p>
            {requests.length === 0 ? <p className="text-sm text-muted-foreground">Aucune demande.</p> : requests.map((r) => (
              <div key={r.id} className="bg-card border border-border rounded-2xl p-3 flex items-center justify-between">
                <span className="text-sm font-medium truncate">{nameMap[r.created_by_id] || r.created_by}</span>
                <div className="flex gap-1">
                  <Button size="sm" onClick={() => acceptRequest(r)} disabled={busy} className="flex items-center gap-1"><Check className="w-4 h-4" /> Accepter</Button>
                  <Button size="sm" variant="outline" onClick={() => rejectRequest(r)} disabled={busy}><X className="w-4 h-4" /></Button>
                </div>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Invitations à des groupes</p>
            {groupInvites.length === 0 ? <p className="text-sm text-muted-foreground">Aucune invitation.</p> : groupInvites.map((inv) => (
              <div key={inv.id} className="bg-card border border-border rounded-2xl p-3 flex items-center justify-between">
                <span className="text-sm font-medium truncate">{inv.group_name}</span>
                <div className="flex gap-1">
                  <Button size="sm" onClick={() => acceptGroupInvite(inv)} disabled={busy} className="flex items-center gap-1"><Check className="w-4 h-4" /> Rejoindre</Button>
                  <Button size="sm" variant="outline" onClick={() => rejectGroupInvite(inv)} disabled={busy}><X className="w-4 h-4" /></Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Créer un groupe</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nom du groupe" />
            <div className="space-y-2">
              <p className="text-xs font-medium text-muted-foreground">Inviter des collaborateurs</p>
              <div className="flex items-center gap-2">
                <Input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); searchPick(); } }} placeholder="Rechercher…" />
                <Button size="icon" variant="outline" onClick={searchPick}><Search className="w-4 h-4" /></Button>
              </div>
              {pickResults.map((c) => {
                const sel = picked.find((p) => p.created_by_id === c.created_by_id);
                return (
                  <div key={c.id} className="flex items-center justify-between bg-muted/40 rounded-xl p-2.5">
                    <span className="text-sm truncate">{c.display_name}</span>
                    <Button size="sm" variant={sel ? "default" : "outline"} onClick={() => setPicked((prev) => sel ? prev.filter((p) => p.created_by_id !== c.created_by_id) : [...prev, c])}>
                      {sel ? "Retirer" : "Ajouter"}
                    </Button>
                  </div>
                );
              })}
              {picked.length > 0 && <p className="text-xs text-muted-foreground">{picked.length} sélectionné(s)</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Annuler</Button>
            <Button onClick={createGroup} disabled={busy}>{busy ? <Loader2 className="w-4 h-4 animate-spin" /> : "Créer"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ReportDialog open={!!reportTarget} onOpenChange={(o) => !o && setReportTarget(null)} target={reportTarget} />
    </div>
  );
}

function TabBtn({ active, onClick, icon, label, badge }) {
  return (
    <button onClick={onClick} className={`no-select-tap relative flex items-center gap-1.5 px-3 py-2 text-sm border-b-2 transition-colors ${active ? "border-primary text-primary" : "border-transparent text-muted-foreground"}`}>
      {icon} {label}
      {badge > 0 && <span className="ml-1 bg-accent text-accent-foreground text-[10px] font-medium rounded-full px-1.5 py-0.5">{badge}</span>}
    </button>
  );
}