import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { ShoppingCart, Boxes, Users, FileText, AlertTriangle, Bot, Settings, Building2, CalendarClock, ScrollText, Truck, Link as LinkIcon, Calculator, BarChart3, Lightbulb, Tag, UsersRound, Wallet, CalendarRange, CalendarDays } from "lucide-react";
import KpiCard from "@/components/dashboard/KpiCard";
import DashboardWindow from "@/components/dashboard/DashboardWindow";
import TasksWindow from "@/components/dashboard/TasksWindow";
import EventsWindow from "@/components/dashboard/EventsWindow";
import QuickLinks from "@/components/dashboard/QuickLinks";
import { formatCurrency } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import TipCard from "@/components/dashboard/TipCard";
import LifeTipCard from "@/components/dashboard/LifeTipCard";
import SpaceNav from "@/components/dashboard/SpaceNav";
import { Link } from "react-router-dom";

export default function BusinessDashboard() {
  const { t } = useI18n();
  const { activeCompanyId, companies } = useSpace();
  const [products, setProducts] = useState([]);
  const [sales, setSales] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [p, s, i, e, prefs] = await Promise.all([
        base44.entities.Product.list("-created_date", 500),
        base44.entities.Sale.list("-date", 500),
        base44.entities.Invoice.list("-issue_date", 500),
        base44.entities.Employee.list("-created_date", 500),
        base44.entities.Preferences.list(),
      ]);
      setProducts(p); setSales(s); setInvoices(i); setEmployees(e);
      setPreferences(prefs?.[0] || null);
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const cid = activeCompanyId;
  const company = companies.find((c) => c.id === cid);
  const currency = preferences?.currency || "XAF";

  const myProducts = cid ? products.filter((x) => x.company_id === cid) : products;
  const mySales = cid ? sales.filter((x) => x.company_id === cid) : sales;
  const myInvoices = cid ? invoices.filter((x) => x.company_id === cid) : invoices;
  const myEmployees = cid ? employees.filter((x) => x.company_id === cid) : employees;

  const salesTotal = mySales
    .filter((s) => s.status !== "annulee")
    .reduce((sum, s) => sum + (Number(s.quantity) || 0) * (Number(s.unit_price) || 0), 0);
  const stockValue = myProducts.reduce((sum, p) => sum + (Number(p.quantity) || 0) * (Number(p.unit_cost) || 0), 0);
  const payroll = myEmployees.filter((e) => e.status === "actif").reduce((sum, e) => sum + (Number(e.salary) || 0), 0);
  const unpaid = myInvoices.filter((i) => i.status !== "payee").reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  const lowStock = myProducts.filter((p) => (Number(p.reorder_level) || 0) > 0 && (Number(p.quantity) || 0) <= (Number(p.reorder_level) || 0));

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{company?.name || t("jbm.dashboard")}</h1>
          <p className="text-muted-foreground mt-1">{t("jbm.dashboardSubtitle")}</p>
        </div>
        <SpaceNav />
      </div>
      <TipCard title="Astuces entreprise">
        {myProducts.length === 0
          ? "Commencez par enregistrer vos produits et stocks, puis saisissez vos ventes et factures pour piloter votre entreprise."
          : lowStock.length
          ? `Vous avez ${lowStock.length} produit(s) en stock bas. Passez commande pour éviter les ruptures.`
          : unpaid > 0
          ? `Vous avez ${formatCurrency(unpaid, currency)} de factures impayées. Relancez vos clients pour sécuriser votre trésorerie.`
          : "Suivez vos ventes et votre trésorerie chaque semaine pour anticiper les besoins de votre entreprise."}
      </TipCard>
      <LifeTipCard space="jbm" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KpiCard icon={ShoppingCart} label={t("jbm.kpi.sales")} value={formatCurrency(salesTotal, currency)} tone="default" />
        <KpiCard icon={Boxes} label={t("jbm.kpi.stock")} value={formatCurrency(stockValue, currency)} tone="accent" />
        <KpiCard icon={Users} label={t("jbm.kpi.payroll")} value={formatCurrency(payroll, currency)} tone="default" />
        <KpiCard icon={FileText} label={t("jbm.kpi.unpaid")} value={formatCurrency(unpaid, currency)} tone={unpaid > 0 ? "warn" : "default"} />
      </div>

      <div>
        <h2 className="font-display text-lg mb-3">Accès rapide</h2>
        <QuickLinks
          items={[
            { to: "/jbm/stock", label: t("jbm.nav.stock"), icon: Boxes, desc: "Inventaire" },
            { to: "/jbm/ventes", label: t("jbm.nav.sales"), icon: ShoppingCart, desc: "Ventes" },
            { to: "/jbm/personnel", label: t("jbm.nav.personnel"), icon: Users, desc: "Employés & paie" },
            { to: "/jbm/entreprises", label: t("jbm.nav.companies"), icon: Building2, desc: "Mes entreprises" },
            { to: "/evenements", label: t("nav.events"), icon: CalendarClock, desc: "Événements & RDV" },
            { to: "/jbm/clients", label: t("nav.clients"), icon: Users, desc: "Clients" },
            { to: "/jbm/devis", label: t("nav.quotes"), icon: ScrollText, desc: "Devis" },
            { to: "/jbm/prestataires", label: t("nav.suppliers"), icon: Truck, desc: "Prestataires" },
            { to: "/jbm/partenariats", label: t("nav.partnerships"), icon: LinkIcon, desc: "Partenariats" },
            { to: "/calculateurs", label: t("nav.calculators"), icon: Calculator, desc: "Calculatrice" },
            { to: "/reporting", label: "Reporting", icon: BarChart3, desc: "Rapports" },
            { to: "/collaborateurs", label: "Collaborateurs", icon: UsersRound, desc: "Échangez et travaillez ensemble" },
            { to: "/suggestions", label: t("nav.suggestions"), icon: Lightbulb, desc: "Suggestions" },
            { to: "/assistants", label: t("nav.agents"), icon: Bot, desc: "Assistant IA Rolly" },
            { to: "/parametres", label: t("nav.settings"), icon: Settings, desc: "Préférences" },
          ]}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-2">
            <Link to="/jbm/stock" className="font-display text-lg hover:underline flex items-center gap-2">
              <Boxes className="w-4 h-4" /> {t("jbm.nav.stock")}
            </Link>
            {lowStock.length > 0 && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-destructive/10 text-destructive flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> {lowStock.length}
              </span>
            )}
          </div>
          <p className="text-sm text-muted-foreground">{t("jbm.dashboard.stockHint", { n: myProducts.length })}</p>
        </div>
        <div className="bg-card border border-border rounded-2xl p-5">
          <Link to="/jbm/devis" className="font-display text-lg hover:underline flex items-center gap-2">
            <ScrollText className="w-4 h-4" /> {t("nav.quotes")}
          </Link>
          <p className="text-sm text-muted-foreground mt-2">Créez et suivez vos devis clients.</p>
        </div>
      </div>

      <div>
        <h2 className="font-display text-lg mb-3">Pilotage quotidien</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <TasksWindow />
          <EventsWindow />
          <DashboardWindow to="/finances" icon={Wallet} title={t("nav.finances")} hint="Dépenses, épargne, emprunts et gains." />
          <DashboardWindow to="/planning" icon={CalendarRange} title={t("nav.planning")} hint="Agenda combiné tâches & événements." />
          <DashboardWindow to="/calendrier" icon={CalendarDays} title={t("nav.calendar")} hint="Vue mensuelle de toutes vos activités." />
        </div>
      </div>

    </div>
  );
}