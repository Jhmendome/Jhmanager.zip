import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Percent, Pencil, Trash2, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useSpace } from "@/lib/SpaceContext";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { expandRecurrence } from "@/lib/recurrence";
import PeriodPicker from "@/components/common/PeriodPicker";
import { periodLabel, customOf } from "@/lib/periods";

const TYPE = { tva: "TVA", charge: "Charge", impot: "Impôt", autre: "Autre" };
const MODE = { montant: "Montant fixe", pourcentage: "Pourcentage" };
const empty = { name: "", value_mode: "montant", rate: "0", type: "charge", base_amount: "0", amount: "0", recurring: false, frequency: "mois", customCount: "", customUnit: "jour", start_date: new Date().toISOString().slice(0, 10), count: "1", period: "", description: "" };

export default function Taxes({ scope = "jpm" }) {
  const { activeCompanyId } = useSpace();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [del, setDel] = useState(null);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => { const list = await base44.entities.Tax.list("-created_date", 500); setItems(list || []); setLoading(false); };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const mine = scope === "jbm"
    ? items.filter((t) => (t.scope === "jbm" || !t.scope) && t.company_id === activeCompanyId)
    : items.filter((t) => t.scope === "jpm");
  const total = mine.reduce((s, t) => s + (Number(t.amount) || 0), 0);
  const isJbm = scope === "jbm";

  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (t) => {
    setEditing(t);
    setForm({
      name: t.name || "", value_mode: t.value_mode || "montant", rate: String(t.rate ?? 0), type: t.type || "charge",
      base_amount: String(t.base_amount ?? 0), amount: String(t.amount ?? 0),
      recurring: !!t.recurring, frequency: t.frequency || "mois", customCount: t.custom_count ? String(t.custom_count) : "", customUnit: t.custom_unit || "jour", start_date: t.start_date || new Date().toISOString().slice(0, 10),
      count: "1", period: t.period || "", description: t.description || "",
    });
    setOpen(true);
  };

  // Montant calculé automatiquement en mode pourcentage.
  const computedAmount = form.value_mode === "pourcentage"
    ? ((parseFloat(form.base_amount) || 0) * (parseFloat(form.rate) || 0)) / 100
    : parseFloat(form.amount) || 0;

  const save = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    const amount = Math.round(computedAmount);
    const base = {
      name: form.name.trim(),
      scope,
      value_mode: form.value_mode,
      type: form.type,
      rate: parseFloat(form.rate) || 0,
      base_amount: parseFloat(form.base_amount) || 0,
      amount,
      recurring: form.recurring,
      frequency: form.recurring ? form.frequency : null,
      custom_count: form.recurring && form.frequency === "personnalise" ? (parseInt(form.customCount, 10) || 0) : null,
      custom_unit: form.recurring && form.frequency === "personnalise" ? form.customUnit : null,
      start_date: form.start_date,
      period: form.period.trim(),
      description: form.description.trim(),
      company_id: isJbm ? activeCompanyId : null,
    };
    try {
      if (editing) {
        await base44.entities.Tax.update(editing.id, base);
        toast({ title: "Taxe mise à jour" });
      } else {
        const count = form.recurring && parseInt(form.count, 10) > 1 ? parseInt(form.count, 10) : 1;
        const custom = form.frequency === "personnalise" ? { count: parseInt(form.customCount, 10) || 0, unit: form.customUnit } : null;
        const records = count > 1 ? expandRecurrence({ ...base }, form.frequency, count, ["start_date"], custom) : [base];
        await base44.entities.Tax.bulkCreate(records);
        toast({ title: count > 1 ? `${count} échéances ajoutées` : "Taxe ajoutée" });
      }
      setOpen(false); load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const remove = async (t) => { try { await base44.entities.Tax.delete(t.id); toast({ title: "Taxe supprimée" }); load(); } catch { toast({ title: "Erreur", variant: "destructive" }); } setDel(null); };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">Taxes & charges</h1>
          <p className="text-muted-foreground mt-1">{isJbm ? "Taxes et charges de l'entreprise." : "Vos taxes et charges personnelles, ponctuelles ou récurrentes."}</p>
        </div>
        <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" /> Ajouter</Button>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5">
        <p className="text-sm text-muted-foreground">Total des taxes/charges</p>
        <p className="font-display text-xl mt-1">{formatCurrency(total, "XAF")}</p>
      </div>

      {mine.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><Percent className="w-8 h-8 mx-auto mb-3 opacity-50" /><p className="text-sm">Aucune taxe enregistrée.</p></div>
      ) : (
        <div className="space-y-2">
          {mine.map((t) => (
            <div key={t.id} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{t.name}</p>
                <p className="text-xs text-muted-foreground">
                  {TYPE[t.type] || t.type}
                  {t.value_mode === "pourcentage" ? ` · ${t.rate}% de ${formatCurrency(t.base_amount, "XAF")}` : ""}
                  {t.recurring && t.frequency ? ` · ${periodLabel(t.frequency, customOf(t))} · dès ${formatDateFr(t.start_date)}` : (t.period ? ` · ${t.period}` : "")}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-sm font-medium">{formatCurrency(t.amount, "XAF")}</span>
                <button onClick={() => openEdit(t)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDel(t)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="font-display">{editing ? "Modifier la taxe" : "Nouvelle taxe / charge"}</DialogTitle></DialogHeader>
          <form onSubmit={save} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Nom</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
              <div className="space-y-2"><Label>Type</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(TYPE).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2"><Label>Mode de calcul</Label>
              <Select value={form.value_mode} onValueChange={(v) => setForm({ ...form, value_mode: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(MODE).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            {form.value_mode === "pourcentage" ? (
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Taux (%)</Label><Input type="number" min="0" step="0.01" value={form.rate} onChange={(e) => setForm({ ...form, rate: e.target.value })} /></div>
                <div className="space-y-2"><Label>Base (assiette)</Label><Input type="number" min="0" value={form.base_amount} onChange={(e) => setForm({ ...form, base_amount: e.target.value })} /></div>
                <div className="col-span-2 rounded-lg bg-secondary p-2 text-sm">Montant calculé : <span className="font-medium">{formatCurrency(computedAmount, "XAF")}</span></div>
              </div>
            ) : (
              <div className="space-y-2"><Label>Montant (valeur précise)</Label><Input type="number" min="0" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
            )}

            {!editing && (
              <div className="rounded-xl border border-border p-3 space-y-3">
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={form.recurring} onChange={(e) => setForm({ ...form, recurring: e.target.checked })} className="w-4 h-4" />
                  <RotateCw className="w-4 h-4" /> Taxe récurrente
                </label>
                {form.recurring && (
                  <div className="space-y-3">
                    <PeriodPicker
                      period={form.frequency}
                      customCount={form.customCount}
                      customUnit={form.customUnit}
                      onChange={({ period, customCount, customUnit }) => setForm({ ...form, frequency: period, customCount, customUnit })}
                      label="Périodicité"
                    />
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2"><Label>1ʳᵉ échéance</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></div>
                      <div className="space-y-2"><Label>Nb d'échéances</Label><Input type="number" min="1" value={form.count} onChange={(e) => setForm({ ...form, count: e.target.value })} /></div>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div className="space-y-2"><Label>Période (libre)</Label><Input value={form.period} onChange={(e) => setForm({ ...form, period: e.target.value })} placeholder="2026 / T1 2026" /></div>
            <div className="space-y-2"><Label>Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} /></div>
            <DialogFooter><Button type="submit" className="w-full">Enregistrer</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Supprimer cette taxe ?</AlertDialogTitle><AlertDialogDescription>« {del?.name} » sera supprimé définitivement.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Annuler</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); remove(del); }}>Supprimer</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}