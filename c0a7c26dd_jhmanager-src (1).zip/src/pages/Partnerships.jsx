import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Link, Pencil, Trash2, Sparkles, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useSpace } from "@/lib/SpaceContext";
import { formatDateFr } from "@/lib/format";

const PT = { individu: "Individu", personne_morale: "Personne morale" };
const ST = { prospect: "Prospect", actif: "Actif", inactif: "Inactif" };
const empty = { partner_name: "", partner_type: "individu", contact_name: "", email: "", phone: "", modalities: "", status: "prospect", start_date: "" };

export default function Partnerships() {
  const { activeCompanyId } = useSpace();
  const scope = "entreprise";
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [del, setDel] = useState(null);
  const [processingId, setProcessingId] = useState(null);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => { const list = await base44.entities.Partnership.list("-created_date", 500); setItems(list || []); setLoading(false); };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const mine = items.filter((p) => (activeCompanyId ? p.company_id === activeCompanyId : true) && p.scope === scope);

  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (p) => { setEditing(p); setForm({ partner_name: p.partner_name || "", partner_type: p.partner_type || "individu", contact_name: p.contact_name || "", email: p.email || "", phone: p.phone || "", modalities: p.modalities || "", status: p.status || "prospect", start_date: p.start_date || "" }); setOpen(true); };

  const save = async (e) => {
    e.preventDefault();
    if (!form.partner_name.trim()) return;
    const payload = { ...form, scope, company_id: activeCompanyId };
    try {
      if (editing) { await base44.entities.Partnership.update(editing.id, payload); toast({ title: "Partenariat mis à jour" }); }
      else { await base44.entities.Partnership.create(payload); toast({ title: "Partenariat créé" }); }
      setOpen(false); load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const remove = async (p) => { try { await base44.entities.Partnership.delete(p.id); toast({ title: "Partenariat supprimé" }); load(); } catch { toast({ title: "Erreur", variant: "destructive" }); } setDel(null); };

  const processAI = async (p) => {
    const text = [p.modalities, p.contact_name && `Contact: ${p.contact_name}`].filter(Boolean).join("\n");
    if (!text.trim()) { toast({ title: "Aucune note à traiter", variant: "destructive" }); return; }
    setProcessingId(p.id);
    try {
      const res = await base44.functions.invoke('processNotes', { note: text, scope: "jbm", company_id: activeCompanyId });
      const c = res?.created || {};
      toast({ title: "Note traitée par l'IA", description: `Ajouté : ${c.expenses || 0} dépense(s), ${c.tasks || 0} tâche(s), ${c.events || 0} événement(s).` });
    } catch (e) { toast({ title: "Échec du traitement IA", description: e?.message || "Erreur", variant: "destructive" }); }
    setProcessingId(null);
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div><h1 className="font-display text-2xl sm:text-3xl">Partenariats</h1><p className="text-muted-foreground mt-1">Gérez vos partenariats (individus ou personnes morales) et leurs modalités.</p></div>
        <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" /> Ajouter</Button>
      </div>

      {mine.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><Link className="w-8 h-8 mx-auto mb-3 opacity-50" /><p className="text-sm">Aucun partenariat enregistré.</p></div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {mine.map((p) => (
            <div key={p.id} className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{p.partner_name}</p>
                  <div className="flex items-center gap-2 flex-wrap mt-0.5">
                    <span className="text-xs px-2 py-0.5 rounded-full bg-secondary">{PT[p.partner_type] || p.partner_type}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${p.status === "actif" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>{ST[p.status] || p.status}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button onClick={() => processAI(p)} disabled={processingId === p.id} title="Traiter la note par l'IA" className="no-select-tap min-touch p-2 rounded-lg hover:bg-accent/10 text-accent-foreground disabled:opacity-50">
                    {processingId === p.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  </button>
                  <button onClick={() => openEdit(p)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                  <button onClick={() => setDel(p)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
              <div className="mt-2 text-xs text-muted-foreground space-y-0.5">
                {p.contact_name && <p>{p.contact_name}</p>}
                {(p.phone || p.email) && <p>{[p.phone, p.email].filter(Boolean).join(" · ")}</p>}
                {p.start_date && <p>Début : {formatDateFr(p.start_date)}</p>}
                {p.modalities && <p className="mt-1 text-foreground/80 line-clamp-3">{p.modalities}</p>}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="font-display">{editing ? "Modifier le partenariat" : "Nouveau partenariat"}</DialogTitle></DialogHeader>
          <form onSubmit={save} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Nom du partenaire</Label><Input value={form.partner_name} onChange={(e) => setForm({ ...form, partner_name: e.target.value })} /></div>
              <div className="space-y-2"><Label>Type</Label>
                <Select value={form.partner_type} onValueChange={(v) => setForm({ ...form, partner_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="individu">Individu</SelectItem><SelectItem value="personne_morale">Personne morale</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2"><Label>Personne de contact</Label><Input value={form.contact_name} onChange={(e) => setForm({ ...form, contact_name: e.target.value })} /></div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Téléphone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
              <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Statut</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(ST).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>Date de début</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></div>
            </div>
            <div className="space-y-2"><Label>Modalités du partenariat</Label><Textarea value={form.modalities} onChange={(e) => setForm({ ...form, modalities: e.target.value })} rows={4} placeholder="Décrivez les engagements, durée, contreparties, conditions…" /></div>
            <DialogFooter><Button type="submit" className="w-full">Enregistrer</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Supprimer ce partenariat ?</AlertDialogTitle><AlertDialogDescription>« {del?.partner_name} » sera supprimé définitivement.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Annuler</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); remove(del); }}>Supprimer</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}