import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { CalendarClock, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useSpace } from "@/lib/SpaceContext";
import { formatDateFr } from "@/lib/format";
import EventItem from "@/components/events/EventItem";
import EventForm from "@/components/events/EventForm";
import { expandRecurrence } from "@/lib/recurrence";

function overlaps(a, b) {
  return new Date(a.start) < new Date(b.end) && new Date(b.start) < new Date(a.end);
}

const PAGE_SIZE = 100;

export default function Events() {
  const { space, activeCompanyId } = useSpace();
  const { toast } = useToast();
  const { register } = useRefresh();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);

  const load = async () => {
    try {
      const list = await base44.entities.Event.list("start", 300);
      const scoped = space === "jpm"
        ? (list || [])
        : (list || []).filter((e) => !activeCompanyId || e.company_id === activeCompanyId);
      setEvents(scoped);
    } catch {
      setEvents([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { register(load); });
  useEffect(() => { setLoading(true); setVisibleCount(PAGE_SIZE); load(); }, [space, activeCompanyId]);

  const handleSave = async (data, recurrence) => {
    if (editing) {
      const prev = events;
      setEvents((cur) => cur.map((i) => (i.id === editing.id ? { ...i, ...data } : i)));
      try {
        await base44.entities.Event.update(editing.id, data);
        toast({ title: "Événement mis à jour" });
        load();
      } catch {
        setEvents(prev);
        toast({ title: "Erreur", description: "Modification impossible.", variant: "destructive" });
      }
    } else {
      const basePayload = space === "jpm" ? data : { ...data, company_id: activeCompanyId };
      const items = expandRecurrence(basePayload, recurrence?.frequency, recurrence?.count, ["start", "end"]);
      const tempIds = items.map(() => `tmp_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
      setEvents((cur) => [...items.map((it, i) => ({ ...it, id: tempIds[i] })), ...cur]);
      try {
        await base44.entities.Event.bulkCreate(items);
        toast({ title: recurrence && recurrence.count > 1 ? `${items.length} événements récurrents créés` : "Événement créé" });
        load();
      } catch {
        setEvents((cur) => cur.filter((e) => !tempIds.includes(e.id)));
        toast({ title: "Erreur", description: "Création impossible.", variant: "destructive" });
      }
    }
    setFormOpen(false);
    setEditing(null);
  };

  const handleDelete = async (ev) => {
    const prev = events;
    setEvents((cur) => cur.filter((i) => i.id !== ev.id));
    try {
      await base44.entities.Event.delete(ev.id);
      toast({ title: "Événement supprimé" });
    } catch {
      setEvents(prev);
      toast({ title: "Erreur", description: "Suppression impossible.", variant: "destructive" });
    }
  };

  const sorted = useMemo(() => [...events].sort((a, b) => new Date(a.start) - new Date(b.start)), [events]);
  const conflictIds = useMemo(() => {
    const ids = new Set();
    for (let i = 0; i < sorted.length; i++) {
      for (let j = i + 1; j < sorted.length; j++) {
        if (overlaps(sorted[i], sorted[j])) {
          ids.add(sorted[i].id);
          ids.add(sorted[j].id);
        }
      }
    }
    return ids;
  }, [sorted]);

  const groups = useMemo(() => {
    const visible = sorted.slice(0, visibleCount);
    return visible.reduce((acc, ev) => {
      const key = new Date(ev.start).toDateString();
      acc[key] = acc[key] || [];
      acc[key].push(ev);
      return acc;
    }, {});
  }, [sorted, visibleCount]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-3xl flex items-center gap-2"><CalendarClock className="w-7 h-7" /> Événements</h1>
          <p className="text-muted-foreground mt-1">Planifiez vos événements et rendez-vous{space === "jpm" ? "" : space === "jbm" ? " de votre entreprise" : " de votre établissement"}.</p>
          {conflictIds.size > 0 && (
            <p className="text-sm text-destructive mt-2">⚠ {conflictIds.size} événement(s) en conflit horaire.</p>
          )}
        </div>
        <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="no-select-tap">
          <Plus className="w-4 h-4 mr-2" /> Nouvel événement
        </Button>
      </div>

      {sorted.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <CalendarClock className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">Aucun événement planifié pour le moment.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {Object.entries(groups).map(([day, dayEvents]) => (
            <div key={day}>
              <h2 className="text-sm font-medium text-muted-foreground mb-2">{formatDateFr(dayEvents[0].start)}</h2>
              <div className="space-y-2">
                {dayEvents.map((ev) => (
                  <EventItem
                    key={ev.id}
                    event={ev}
                    onEdit={(item) => { setEditing(item); setFormOpen(true); }}
                    onDelete={handleDelete}
                    conflict={conflictIds.has(ev.id)}
                  />
                ))}
              </div>
            </div>
          ))}
          {visibleCount < sorted.length && (
            <Button variant="outline" className="w-full" onClick={() => setVisibleCount((c) => c + PAGE_SIZE)}>
              Charger plus ({sorted.length - visibleCount} restants)
            </Button>
          )}
        </div>
      )}

      <EventForm open={formOpen} onOpenChange={setFormOpen} event={editing} onSubmit={handleSave} />
    </div>
  );
}