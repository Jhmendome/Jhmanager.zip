import React, { useState } from "react";
import { Wallet, ListChecks, Sparkles, Building2, Boxes, Users, Bell, FileDown } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import AgentChat from "@/components/agents/AgentChat";

export default function Agents() {
  const { t } = useI18n();
  const { space } = useSpace();

  const JPM_AGENTS = [
    { name: "finances", icon: Wallet, titleKey: "agents.finances.title", descKey: "agents.finances.desc" },
    { name: "taches", icon: ListChecks, titleKey: "agents.tasks.title", descKey: "agents.tasks.desc" },
    { name: "briefing", icon: Sparkles, titleKey: "agents.briefing.title", descKey: "agents.briefing.desc" },
    { name: "notifications", icon: Bell, titleKey: "agents.notifications.title", descKey: "agents.notifications.desc" },
    { name: "rapports", icon: FileDown, titleKey: "agents.rapports.title", descKey: "agents.rapports.desc" },
  ];

  const JBM_AGENTS = [
    { name: "jbm", icon: Building2, titleKey: "agents.jbm.title", descKey: "agents.jbm.desc" },
    { name: "inventaire", icon: Boxes, titleKey: "agents.inventaire.title", descKey: "agents.inventaire.desc" },
    { name: "rh", icon: Users, titleKey: "agents.rh.title", descKey: "agents.rh.desc" },
    { name: "notifications", icon: Bell, titleKey: "agents.notifications.title", descKey: "agents.notifications.desc" },
    { name: "rapports", icon: FileDown, titleKey: "agents.rapports.title", descKey: "agents.rapports.desc" },
  ];

  const AGENTS = space === "jbm" ? JBM_AGENTS : JPM_AGENTS;
  const [active, setActive] = useState(AGENTS[0].name);
  const current = AGENTS.find((a) => a.name === active) || AGENTS[0];
  const title = current.title || (current.titleKey ? t(current.titleKey) : active);
  const desc = current.desc || (current.descKey ? t(current.descKey) : "");

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl">{t("agents.title")}</h1>
        <p className="text-muted-foreground mt-1">{t("agents.subtitle")}</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {AGENTS.map((a) => {
          const Icon = a.icon;
          const isActive = active === a.name;
          const label = a.title || (a.titleKey ? t(a.titleKey) : a.name);
          return (
            <button
              key={a.name}
              type="button"
              onClick={() => setActive(a.name)}
              className={`no-select-tap flex items-center gap-2 px-4 py-2 rounded-xl border text-sm whitespace-nowrap transition-colors ${
                isActive
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card border-border text-foreground hover:bg-secondary"
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {label}
            </button>
          );
        })}
      </div>

      {current && <p className="text-sm text-muted-foreground -mt-2">{desc}</p>}

      <div className="bg-card border border-border rounded-2xl p-4">
        <AgentChat key={active} agentName={active} />
      </div>
    </div>
  );
}