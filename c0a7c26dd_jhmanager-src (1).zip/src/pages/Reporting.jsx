import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { BarChart3, Wallet, TrendingDown, TrendingUp, FileText, Download, Loader2, PieChart as PieIcon, LineChart, CalendarClock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ExportMenu from "@/components/ExportMenu";
import KpiCard from "@/components/dashboard/KpiCard";
import { useSpace } from "@/lib/SpaceContext";
import { useToast } from "@/components/ui/use-toast";
import { formatCurrency, formatDateFr } from "@/lib/format";
import {
  ResponsiveContainer, ComposedChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  Legend, PieChart, Pie, Cell,
} from "recharts";

const REPORT_DOMAINS = [
  { value: "finances", label: "Dépenses" },
  { value: "ventes", label: "Ventes" },
  { value: "stock", label: "Stock" },
  { value: "taches", label: "Tâches" },
];

const PALETTE = [
  "hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))",
  "hsl(var(--chart-4))", "hsl(var(--chart-5))", "hsl(var(--accent))",
];

const MONTH_LABELS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];

function shortAmount(v) {
  const n = Number(v) || 0;
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace(".0", "")}M`;
  if (abs >= 1_000) return `${(n / 1_000).toFixed(0)}k`;
  return `${Math.round(n)}`;
}

function ChartTooltip({ active, payload, label, currency }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-popover border border-border rounded-lg shadow-md px-3 py-2 text-xs space-y-1">
      {label != null && <p className="font-medium text-foreground">{label}</p>}
      {payload.map((p, i) => (
        <p key={i} className="flex items-center gap-1.5" style={{ color: p.color || p.payload?.fill }}>
          <span className="inline-block w-2 h-2 rounded-full" style={{ background: p.color || p.payload?.fill }} />
          {p.name} : {formatCurrency(Number(p.value) || 0, currency)}
        </p>
      ))}
    </div>
  );
}

export default function Reporting() {
  const { space, activeCompanyId } = useSpace();
  const { toast } = useToast();
  const [expenses, setExpenses] = useState([]);
  const [sales, setSales] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [events, setEvents] = useState([]);
  const [prefs, setPrefs] = useState(null);
  const [loading, setLoading] = useState(true);
  const [domain, setDomain] = useState(space === "jpm" ? "finances" : "ventes");
  const [genLoading, setGenLoading] = useState(false);
  const [genLink, setGenLink] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const [e, s, inv, pr, tk, ev] = await Promise.all([
          base44.entities.Expense.list("-date", 1000),
          base44.entities.Sale.list("-date", 1000),
          base44.entities.Invoice.list("-issue_date", 1000),
          base44.entities.Preferences.list(),
          base44.entities.Task.list("-start", 500),
          base44.entities.Event.list("start", 500),
        ]);
        setExpenses(e || []); setSales(s || []); setInvoices(inv || []);
        setPrefs(pr?.[0] || null); setTasks(tk || []); setEvents(ev || []);
      } catch { /* ignore */ }
      setLoading(false);
    })();
  }, []);

  const scope = (list) => activeCompanyId ? (list || []).filter((x) => x.company_id === activeCompanyId) : (list || []);
  const cur = prefs?.currency || "XAF";

  const myExp = space === "jpm" ? (expenses || []) : scope(expenses);
  const mySales = space === "jpm" ? [] : scope(sales);
  const myInv = space === "jpm" ? [] : scope(invoices);

  const myEvents = space === "jpm" ? (events || []) : scope(events);
  const now = new Date();
  const upcomingEvents = myEvents
    .filter((e) => new Date(e.start) >= now)
    .sort((a, b) => new Date(a.start) - new Date(b.start))
    .slice(0, 10);
  const upcomingTasks = (tasks || [])
    .filter((t) => t.status !== "terminee" && t.start && new Date(t.start) >= now)
    .sort((a, b) => new Date(a.start) - new Date(b.start))
    .slice(0, 10);

  const activityColumns = [
    { key: "label", label: "Libellé" },
    { key: "kind", label: "Type" },
    { key: "start", label: "Début", type: "date" },
    { key: "end", label: "Fin", type: "date" },
    { key: "meta", label: "Catégorie/Priorité" },
  ];
  const activityRows = [
    ...upcomingEvents.map((e) => ({ label: e.title, kind: "Événement", start: e.start, end: e.end, meta: e.category || "—" })),
    ...upcomingTasks.map((t) => ({ label: t.title, kind: "Tâche", start: t.start, end: t.end, meta: t.priority || "—" })),
  ];

  const totalExp = myExp.reduce((s, e) => s + (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0), 0);
  const totalRev = mySales.reduce((s, x) => s + (Number(x.quantity) || 0) * (Number(x.unit_price) || 0), 0);
  const unpaid = myInv.filter((i) => i.status !== "payee").reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const result = totalRev - totalExp;
  const budget = prefs?.initial_budget || 0;
  const remaining = budget - totalExp;

  const rows = [
    ...mySales.map((x) => ({ label: x.item_name || "Vente", type: "Revenu", tier: x.customer_name || "", date: x.date, amount: (Number(x.quantity) || 0) * (Number(x.unit_price) || 0) })),
    ...myExp.map((e) => ({ label: e.name || "Dépense", type: "Dépense", tier: e.category || "", date: e.date, amount: -((Number(e.quantity) || 0) * (Number(e.unit_cost) || 0)) })),
  ].sort((a, b) => (b.date || "").localeCompare(a.date || ""));

  const columns = [
    { key: "label", label: "Libellé" },
    { key: "type", label: "Type" },
    { key: "tier", label: space === "jpm" ? "Catégorie" : "Client / Catégorie" },
    { key: "date", label: "Date", type: "date" },
    { key: "amount", label: "Montant", type: "currency" },
  ];

  const summary = space === "jpm"
    ? [
        { label: "Budget", value: formatCurrency(budget, cur) },
        { label: "Total dépenses", value: formatCurrency(totalExp, cur) },
        { label: "Reste", value: formatCurrency(remaining, cur) },
      ]
    : [
        { label: "Revenus", value: formatCurrency(totalRev, cur) },
        { label: "Dépenses", value: formatCurrency(totalExp, cur) },
        { label: "Résultat", value: formatCurrency(result, cur) },
        { label: "Factures impayées", value: formatCurrency(unpaid, cur) },
      ];

  // Répartition par catégorie de dépenses
  const byCategory = {};
  myExp.forEach((e) => {
    const cat = e.category || "Autre";
    byCategory[cat] = (byCategory[cat] || 0) + (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0);
  });
  const pieData = Object.entries(byCategory)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([name, value]) => ({ name, value }));

  // Évolution mensuelle (12 derniers mois)
  const monthly = useMemo(() => {
    const now = new Date();
    const map = {};
    for (let i = 11; i >= 0; i--) {
      const dt = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const k = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}`;
      map[k] = { key: k, label: MONTH_LABELS[dt.getMonth()], revenus: 0, depenses: 0 };
    }
    mySales.forEach((s) => {
      const k = (s.date || "").slice(0, 7);
      if (map[k]) map[k].revenus += (Number(s.quantity) || 0) * (Number(s.unit_price) || 0);
    });
    myExp.forEach((e) => {
      const k = (e.date || "").slice(0, 7);
      if (map[k]) map[k].depenses += (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0);
    });
    return Object.values(map);
  }, [mySales, myExp]);

  const hasMonthly = monthly.some((m) => m.revenus > 0 || m.depenses > 0);

  const generate = async () => {
    setGenLoading(true); setGenLink(null);
    try {
      const res = await base44.functions.invoke('generateReport', { domain });
      if (res?.file_url) { setGenLink(res); toast({ title: "Rapport généré" }); }
      else toast({ title: "Aucune donnée disponible", variant: "destructive" });
    } catch { toast({ title: "Erreur lors de la génération", variant: "destructive" }); }
    setGenLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl flex items-center gap-2"><BarChart3 className="w-6 h-6" /> Reporting financier</h1>
          <p className="text-muted-foreground mt-1">Synthèse financière, graphiques, export PDF/Excel et rapport serveur.</p>
        </div>
        <ExportMenu title="Reporting financier" subtitle={space === "jpm" ? "Espace personnel" : `Espace ${space === "jbm" ? "entreprise" : "école"}`} currency={cur} rows={rows} columns={columns} summary={summary} />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {space === "jpm" ? (
          <>
            <KpiCard icon={Wallet} label="Budget" value={formatCurrency(budget, cur)} tone="default" />
            <KpiCard icon={TrendingDown} label="Dépenses" value={formatCurrency(totalExp, cur)} tone="accent" />
            <KpiCard icon={TrendingUp} label="Reste" value={formatCurrency(remaining, cur)} tone={remaining < 0 ? "warn" : "default"} />
            <KpiCard icon={FileText} label="Mouvements" value={rows.length} tone="default" />
          </>
        ) : (
          <>
            <KpiCard icon={TrendingUp} label="Revenus" value={formatCurrency(totalRev, cur)} tone="default" />
            <KpiCard icon={TrendingDown} label="Dépenses" value={formatCurrency(totalExp, cur)} tone="accent" />
            <KpiCard icon={Wallet} label="Résultat" value={formatCurrency(result, cur)} tone={result < 0 ? "warn" : "default"} />
            <KpiCard icon={FileText} label="Factures impayées" value={formatCurrency(unpaid, cur)} tone={unpaid > 0 ? "warn" : "default"} />
          </>
        )}
      </div>

      <div className="bg-card border border-border rounded-2xl p-5">
        <h2 className="font-display text-lg flex items-center gap-2 mb-4"><LineChart className="w-4 h-4 text-accent" /> Évolution sur 12 mois</h2>
        {hasMonthly ? (
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={monthly} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} tickLine={false} axisLine={{ stroke: "hsl(var(--border))" }} />
              <YAxis tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} tickFormatter={shortAmount} tickLine={false} axisLine={false} width={44} />
              <Tooltip content={<ChartTooltip currency={cur} />} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              {space !== "jpm" && <Bar dataKey="revenus" name="Revenus" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} maxBarSize={28} />}
              <Bar dataKey="depenses" name="Dépenses" fill="hsl(var(--chart-4))" radius={[4, 4, 0, 0]} maxBarSize={28} />
            </ComposedChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-sm text-muted-foreground">Aucune donnée à afficher sur la période.</p>
        )}
      </div>

      <div className="bg-card border border-border rounded-2xl p-5">
        <h2 className="font-display text-lg flex items-center gap-2 mb-4"><PieIcon className="w-4 h-4 text-accent" /> Répartition par catégorie</h2>
        {pieData.length === 0 ? (
          <p className="text-sm text-muted-foreground">Aucune dépense à afficher.</p>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} innerRadius={45} paddingAngle={2}>
                {pieData.map((_, i) => (
                  <Cell key={i} fill={PALETTE[i % PALETTE.length]} stroke="hsl(var(--card))" strokeWidth={2} />
                ))}
              </Pie>
              <Tooltip content={<ChartTooltip currency={cur} />} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <h2 className="font-display text-lg flex items-center gap-2"><CalendarClock className="w-4 h-4 text-accent" /> Activités à venir</h2>
          <ExportMenu
            title="Activités à venir"
            subtitle={space === "jpm" ? "Espace personnel" : "Espace entreprise"}
            currency={cur}
            rows={activityRows}
            columns={activityColumns}
            summary={[
              { label: "Événements", value: String(upcomingEvents.length) },
              { label: "Tâches", value: String(upcomingTasks.length) },
            ]}
          />
        </div>
        {activityRows.length === 0 ? (
          <p className="text-sm text-muted-foreground">Aucune activité à venir.</p>
        ) : (
          <div className="space-y-2">
            {activityRows.map((r, i) => (
              <div key={i} className="flex items-center gap-3 text-sm">
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs ${r.kind === "Événement" ? "bg-accent/20 text-accent-foreground" : "bg-primary/15 text-primary"}`}>{r.kind}</span>
                <span className="flex-1 truncate">{r.label}</span>
                <span className="text-xs text-muted-foreground whitespace-nowrap">{formatDateFr(r.start)}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <h2 className="font-display text-lg flex items-center gap-2"><Download className="w-4 h-4 text-accent" /> Rapport serveur (CSV)</h2>
        <p className="text-sm text-muted-foreground">Générez un fichier CSV détaillé à partir de vos données (déposé sur un lien de téléchargement).</p>
        <div className="flex items-center gap-2 flex-wrap">
          <Select value={domain} onValueChange={setDomain}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>{REPORT_DOMAINS.map((d) => <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>)}</SelectContent>
          </Select>
          <Button onClick={generate} disabled={genLoading}>
            {genLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
            Générer
          </Button>
        </div>
        {genLink && (
          <a href={genLink.file_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm text-primary hover:underline break-all">
            <FileText className="w-4 h-4 shrink-0" /> {genLink.filename || "Télécharger le rapport"}
          </a>
        )}
      </div>
    </div>
  );
}