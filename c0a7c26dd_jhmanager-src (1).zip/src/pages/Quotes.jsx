import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, ScrollText, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useSpace } from "@/lib/SpaceContext";
import { formatCurrency, formatDateFr } from "@/lib/format";

const STATUS = { brouillon: "Brouillon", envoye: "Envoyé", accepte: "Accepté", refuse: "Refusé" };
const empty = { number: "", client_name: "", amount: "0", issue_date: new Date().toISOString().slice(0, 10), validity_date: "", status: "brouillon", notes: "" };

export default function Quotes() {
  const { activeCompanyId } = useSpace();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [del, setDel] = useState(null);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => {
    const list = await base44.entities.Quote.list("-issue_date", 500);
    setItems(list || []);
    setLoading(false);
  };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const mine = activeCompanyId ? items.filter((q) => q.company_id === activeCompanyId) : items;
  const nextNumber = `D-${new Date().getFullYear()}-${String(mine.length + 1).padStart(4, "0")}`;

  const openNew = () => { setEditing(null); setForm({ ...empty, number: nextNumber }); setOpen(true); };
  const openEdit = (q) => { setEditing(q); setForm({ number: q.number || "", client_name: q.client_name || "", amount: String(q.amount ?? 0), issue_date: q.issue_date || "", validity_date: q.validity_date || "", status: q.status || "brouillon", notes: q.notes || "" }); setOpen(true); };

  const save = async (e) => {
    e.preventDefault();
    if (!form.number.trim() || !form.client_name.trim() || !form.issue_date) return;
    const payload = { ...form, amount: parseFloat(form.amount) || 0, company_id: activeCompanyId };
    try {
      if (editing) { await base44.entities.Quote.update(editing.id, payload); toast({ title: "Devis mis à jour" }); }
      else { await base44.entities.Quote.create(payload); toast({ title: "Devis créé" }); }
      setOpen(false); load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const remove = async (q) => {
    try { await base44.entities.Quote.delete(q.id); toast({ title: "Devis supprimé" }); load(); }
    catch { toast({ title: "Erreur", variant: "destructive" }); }
    setDel(null);
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div><h1 className="font-display text-2xl sm:text-3xl">Devis</h1><p className="text-muted-foreground mt-1">Créez et suivez vos devis.</p></div>
        <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" /> Ajouter</Button>
      </div>

      {mine.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><ScrollText className="w-8 h-8 mx-auto mb-3 opacity-50" /><p className="text-sm">Aucun devis créé.</p></div>
      ) : (
        <div className="space-y-2">
          {mine.map((q) => (
            <div key={q.id} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{q.number} · {q.client_name}</p>
                <p className="text-xs text-muted-foreground">{formatDateFr(q.issue_date)}{q.validity_date ? ` · valable jusqu'au ${formatDateFr(q.validity_date)}` : ""}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs px-2 py-1 rounded-full bg-secondary">{STATUS[q.status] || q.status}</span>
                <span className="text-sm font-medium">{formatCurrency(q.amount, "XAF")}</span>
                <button onClick={() => openEdit(q)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => setDel(q)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="font-display">{editing ? "Modifier le devis" : "Nouveau devis"}</DialogTitle></DialogHeader>
          <form onSubmit={save} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Numéro</Label><Input value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} /></div>
              <div className="space-y-2"><Label>Client</Label><Input value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Montant (XAF)</Label><Input type="number" min="0" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
              <div className="space-y-2"><Label>Statut</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{Object.entries(STATUS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Date d'émission</Label><Input type="date" value={form.issue_date} onChange={(e) => setForm({ ...form, issue_date: e.target.value })} /></div>
              <div className="space-y-2"><Label>Valide jusqu'au</Label><Input type="date" value={form.validity_date} onChange={(e) => setForm({ ...form, validity_date: e.target.value })} /></div>
            </div>
            <div className="space-y-2"><Label>Description / modalités</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={3} /></div>
            <DialogFooter><Button type="submit" className="w-full">Enregistrer</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Supprimer ce devis ?</AlertDialogTitle><AlertDialogDescription>Le devis « {del?.number} » sera supprimé définitivement.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Annuler</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); remove(del); }}>Supprimer</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}