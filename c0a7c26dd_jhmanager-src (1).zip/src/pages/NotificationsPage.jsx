import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Bell, BellOff, Check, Trash2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { formatDateFr } from "@/lib/format";

const TYPE_LABEL = { rappel: "Rappel", conseil: "Conseil", personnalisee: "Personnalisée", systeme: "Système" };

export default function NotificationsPage() {
  const [items, setItems] = useState([]);
  const [prefs, setPrefs] = useState(null);
  const [loading, setLoading] = useState(true);
  const [allEnabled, setAllEnabled] = useState(true);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [type, setType] = useState("personnalisee");
  const { toast } = useToast();

  const load = async () => {
    try {
      const [list, p] = await Promise.all([
        base44.entities.Notification.list("-created_date", 200),
        base44.entities.Preferences.list(),
      ]);
      setItems(list || []);
      const pr = p?.[0] || null;
      setPrefs(pr);
      setAllEnabled(pr?.notifications_enabled !== false);
    } catch {
      setItems([]);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const toggleAll = async (val) => {
    setAllEnabled(val);
    try {
      if (prefs) await base44.entities.Preferences.update(prefs.id, { notifications_enabled: val });
      else { const c = await base44.entities.Preferences.create({ notifications_enabled: val }); setPrefs(c); }
      toast({ title: val ? "Notifications activées" : "Notifications désactivées" });
    } catch {
      setAllEnabled(!val);
      toast({ title: "Erreur", variant: "destructive" });
    }
  };

  const create = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    try {
      await base44.entities.Notification.create({ title, message, type, source: "manuel", read: false, enabled: true });
      setTitle(""); setMessage("");
      toast({ title: "Notification créée" });
      load();
    } catch {
      toast({ title: "Erreur", variant: "destructive" });
    }
  };

  const markRead = async (n) => {
    try { await base44.entities.Notification.update(n.id, { read: true }); load(); } catch { /* ignore */ }
  };
  const markAllRead = async () => {
    try { await base44.entities.Notification.updateMany({ read: false }, { $set: { read: true } }); load(); } catch { /* ignore */ }
  };
  const toggleEnabled = async (n) => {
    try { await base44.entities.Notification.update(n.id, { enabled: !n.enabled }); load(); } catch { /* ignore */ }
  };
  const remove = async (n) => {
    try { await base44.entities.Notification.delete(n.id); load(); } catch { /* ignore */ }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">Notifications</h1>
          <p className="text-muted-foreground mt-1">Vos rappels et notifications personnalisées.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">{allEnabled ? "Activées" : "Désactivées"}</span>
          <Switch checked={allEnabled} onCheckedChange={toggleAll} />
        </div>
      </div>

      <form onSubmit={create} className="bg-card border border-border rounded-2xl p-5 space-y-3">
        <h2 className="font-display text-lg">Créer une notification</h2>
        <div className="space-y-2"><Label>Titre</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Rappel facture" /></div>
        <div className="space-y-2"><Label>Message</Label><Input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Penser à…" /></div>
        <div className="flex gap-2 flex-wrap">
          <Select value={type} onValueChange={setType}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="rappel">Rappel</SelectItem>
              <SelectItem value="conseil">Conseil</SelectItem>
              <SelectItem value="personnalisee">Personnalisée</SelectItem>
              <SelectItem value="systeme">Système</SelectItem>
            </SelectContent>
          </Select>
          <Button type="submit"><Plus className="w-4 h-4 mr-1" /> Ajouter</Button>
        </div>
        <p className="text-xs text-muted-foreground">Pour des notifications plus élaborées, demandez à l'assistant Notifications (page Assistants).</p>
      </form>

      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg">Historique</h2>
        <Button variant="outline" size="sm" onClick={markAllRead}><Check className="w-4 h-4 mr-1" /> Tout marquer lu</Button>
      </div>

      {items.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-8">Aucune notification.</p>
      ) : (
        <div className="space-y-2">
          {items.map((n) => (
            <div key={n.id} className={`bg-card border rounded-xl p-4 flex items-start justify-between gap-3 ${n.read ? "border-border" : "border-primary/40 bg-primary/5"} ${!n.enabled ? "opacity-50" : ""}`}>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-medium">{n.title}</p>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-secondary">{TYPE_LABEL[n.type] || n.type}</span>
                  {!n.enabled && <span className="text-xs text-muted-foreground">désactivée</span>}
                </div>
                {n.message && <p className="text-sm text-muted-foreground mt-1">{n.message}</p>}
                <p className="text-xs text-muted-foreground mt-1">{n.created_date ? formatDateFr(n.created_date, true) : ""}</p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {!n.read && <button onClick={() => markRead(n)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary" title="Marquer lu"><Check className="w-4 h-4" /></button>}
                <button onClick={() => toggleEnabled(n)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary" title="Activer/Désactiver">{n.enabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}</button>
                <button onClick={() => remove(n)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive" title="Supprimer"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}