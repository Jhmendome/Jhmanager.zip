import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Landmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { formatCurrency } from "@/lib/format";
import LoanForm from "@/components/loans/LoanForm";
import LoanItem from "@/components/loans/LoanItem";
import { buildSchedule } from "@/lib/loanMath";
import { shiftDateBy } from "@/lib/recurrence";
import { customOf } from "@/lib/periods";

export default function Loans() {
  const [loans, setLoans] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [payingId, setPayingId] = useState(null);
  const [del, setDel] = useState(null);
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => {
    const [l, p] = await Promise.all([
      base44.entities.Loan.list("-created_date", 200).catch(() => []),
      base44.entities.LoanPayment.list("-date", 500).catch(() => []),
    ]);
    setLoans(l || []);
    setPayments(p || []);
    setLoading(false);
  };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const active = loans.filter((x) => x.status !== "archive");
  const totalRemaining = active.reduce((s, l) => s + (Number(l.remaining_balance) || 0), 0);
  const totalMonthly = active.reduce((s, l) => s + (l.status === "rembourse" ? 0 : (Number(l.monthly_payment) || 0)), 0);

  const create = async (data) => {
    try {
      await base44.entities.Loan.create(data);
      toast({ title: "Emprunt créé" });
      setOpen(false);
      load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const pay = async (loan) => {
    setPayingId(loan.id);
    try {
      const schedule = buildSchedule(loan.principal, loan.interest_rate, loan.term_periods, loan.interest_type);
      const idx = loan.payments_made || 0;
      if (idx >= schedule.length) return;
      const row = schedule[idx];
      const newMade = idx + 1;
      const remaining = schedule[newMade - 1].balance;
      const today = new Date().toISOString().slice(0, 10);
      await base44.entities.LoanPayment.create({
        loan_id: loan.id,
        loan_name: loan.name,
        payment_number: newMade,
        amount: row.payment,
        interest_portion: row.interest,
        principal_portion: row.principal,
        remaining_balance: remaining,
        date: today,
      });
      const nextDate = newMade >= schedule.length ? loan.next_payment_date : shiftDateBy(loan.start_date, loan.frequency || "mois", newMade, customOf(loan));
      await base44.entities.Loan.update(loan.id, {
        payments_made: newMade,
        remaining_balance: remaining,
        next_payment_date: nextDate,
        status: newMade >= schedule.length ? "rembourse" : "en_cours",
      });
      toast({ title: `Échéance n°${newMade} enregistrée` });
      load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
    setPayingId(null);
  };

  const remove = async (loan) => {
    try {
      await base44.entities.LoanPayment.deleteMany({ loan_id: loan.id }).catch(() => {});
      await base44.entities.Loan.delete(loan.id);
      toast({ title: "Emprunt supprimé" });
      setDel(null);
      load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  if (loading) return <div className="flex items-center justify-center h-64"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div><h1 className="font-display text-2xl sm:text-3xl">Emprunts & dettes</h1><p className="text-muted-foreground mt-1">Suivez vos dettes avec intérêts et période, liées à vos finances.</p></div>
        <Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-2" /> Nouvel emprunt</Button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-card border border-border rounded-2xl p-4"><p className="text-sm text-muted-foreground">Dette restante totale</p><p className="font-display text-xl mt-1">{formatCurrency(totalRemaining, "XAF")}</p></div>
        <div className="bg-card border border-border rounded-2xl p-4"><p className="text-sm text-muted-foreground">Engagement / échéance</p><p className="font-display text-xl mt-1">{formatCurrency(totalMonthly, "XAF")}</p></div>
      </div>

      {active.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground"><Landmark className="w-8 h-8 mx-auto mb-3 opacity-50" /><p className="text-sm">Aucun emprunt en cours.</p></div>
      ) : (
        <div className="space-y-3">
          {active.map((loan) => (
            <LoanItem key={loan.id} loan={loan} payments={payments} onPay={pay} onDelete={remove} payingId={payingId} delId={del} setDelId={setDel} />
          ))}
        </div>
      )}

      <LoanForm open={open} onOpenChange={setOpen} onSubmit={create} loading={false} />
    </div>
  );
}