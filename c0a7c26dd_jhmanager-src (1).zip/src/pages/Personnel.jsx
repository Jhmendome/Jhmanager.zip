import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { useRefresh } from "@/lib/RefreshContext";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";
import { formatCurrency } from "@/lib/format";
import ExportMenu from "@/components/ExportMenu";
import EmployeeForm from "@/components/business/EmployeeForm";
import EmployeeItem from "@/components/business/EmployeeItem";
import AttendancePanel from "@/components/business/AttendancePanel";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

// Conversion d'un montant périodique en équivalent mensuel.
const MONTH_FACTOR = { jour: 30, semaine: 4.345, mois: 1, trimestre: 1 / 3, semestre: 1 / 6, annee: 1 / 12 };
const toMonthly = (amount, periodicity) => (Number(amount) || 0) * (MONTH_FACTOR[periodicity] || 1);

export default function Personnel() {
  const { t } = useI18n();
  const { activeCompanyId } = useSpace();
  const [employees, setEmployees] = useState([]);
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [tab, setTab] = useState("employes");
  const { toast } = useToast();
  const { register } = useRefresh();

  const load = async () => {
    const [e, prefs] = await Promise.all([
      base44.entities.Employee.list("-created_date", 500),
      base44.entities.Preferences.list(),
    ]);
    setEmployees(e);
    setPreferences(prefs?.[0] || null);
    setLoading(false);
  };
  useEffect(() => { register(load); }, []);
  useEffect(() => { load(); }, []);

  const currency = preferences?.currency || "XAF";
  const myEmployees = activeCompanyId ? employees.filter((e) => e.company_id === activeCompanyId) : employees;
  const payroll = myEmployees
    .filter((e) => e.status === "actif")
    .reduce((sum, e) => sum + toMonthly(e.salary, e.salary_periodicity) * (Number(e.headcount) || 1), 0);
  const monthlyBonus = myEmployees
    .filter((e) => e.status === "actif" && e.bonus_type === "periodique")
    .reduce((sum, e) => sum + toMonthly(e.bonus, e.bonus_periodicity), 0);

  const save = async (data) => {
    const payload = { ...data, company_id: activeCompanyId };
    if (editing) {
      const prev = employees;
      setEmployees((cur) => cur.map((e) => (e.id === editing.id ? { ...e, ...payload } : e)));
      try {
        await base44.entities.Employee.update(editing.id, payload);
        toast({ title: t("toast.taskUpdated") });
        load();
      } catch (e) {
        setEmployees(prev);
        toast({ title: t("toast.error"), description: t("err.modify"), variant: "destructive" });
      }
    } else {
      const tmpId = `tmp_${Date.now()}`;
      setEmployees((cur) => [{ ...payload, id: tmpId }, ...cur]);
      try {
        await base44.entities.Employee.create(payload);
        toast({ title: t("toast.expenseAdded") });
        load();
      } catch (e) {
        setEmployees((cur) => cur.filter((x) => x.id !== tmpId));
        toast({ title: t("toast.error"), description: t("err.create"), variant: "destructive" });
      }
    }
    setFormOpen(false);
    setEditing(null);
  };

  const remove = async (emp) => {
    const prev = employees;
    setEmployees((cur) => cur.filter((e) => e.id !== emp.id));
    try {
      await base44.entities.Employee.delete(emp.id);
      toast({ title: t("toast.taskDeleted") });
      load();
    } catch (e) {
      setEmployees(prev);
      toast({ title: t("toast.error"), description: t("err.delete"), variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl">{t("jbm.personnel.title")}</h1>
          <p className="text-muted-foreground mt-1">{t("jbm.personnel.subtitle")}</p>
        </div>
        {tab === "employes" && (
          <div className="flex items-center gap-2">
            <ExportMenu
              title={t("report.personnel")}
              subtitle={t("report.personnelSub")}
              currency={currency}
              rows={myEmployees}
              columns={[
                { key: "full_name", label: t("jbm.employee.name") },
                { key: "role", label: t("jbm.employee.role") },
                { key: "headcount", label: "Effectif" },
                { key: "salary", label: t("jbm.employee.salary"), type: "currency" },
                { key: "salary_periodicity", label: "Périodicité" },
                { key: "bonus", label: "Prime", type: "currency" },
                { key: "hire_date", label: t("jbm.employee.hireDate"), type: "date" },
                { key: "status", label: t("jbm.employee.status") },
              ]}
              summary={[
                { label: "Masse salariale (mois)", value: formatCurrency(payroll, currency) },
                { label: "Primes périodiques (mois)", value: formatCurrency(monthlyBonus, currency) },
              ]}
            />
            <Button onClick={() => { setEditing(null); setFormOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" /> {t("jbm.add")}
            </Button>
          </div>
        )}
      </div>

      {tab === "employes" && (
        <div className="bg-card border border-border rounded-2xl p-5">
          <p className="text-sm text-muted-foreground">Masse salariale (équivalent mensuel)</p>
          <p className="font-display text-xl mt-1">{formatCurrency(payroll + monthlyBonus, currency)}</p>
          {monthlyBonus > 0 && (
            <p className="text-xs text-muted-foreground mt-1">Dont primes périodiques : {formatCurrency(monthlyBonus, currency)}</p>
          )}
        </div>
      )}

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="employes">Employés & paie</TabsTrigger>
          <TabsTrigger value="presence">Absence & discipline</TabsTrigger>
        </TabsList>
        <TabsContent value="employes" className="space-y-2 mt-4">
          {myEmployees.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Users className="w-8 h-8 mx-auto mb-3 opacity-50" />
              <p className="text-sm">{t("jbm.personnel.empty")}</p>
            </div>
          ) : (
            myEmployees.map((e) => (
              <EmployeeItem key={e.id} employee={e} currency={currency} onEdit={(x) => { setEditing(x); setFormOpen(true); }} onDelete={remove} />
            ))
          )}
        </TabsContent>
        <TabsContent value="presence" className="mt-4">
          <AttendancePanel companyId={activeCompanyId} employees={myEmployees} />
        </TabsContent>
      </Tabs>

      <EmployeeForm open={formOpen} onOpenChange={setFormOpen} employee={editing} onSubmit={save} />
    </div>
  );
}