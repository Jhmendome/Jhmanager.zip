import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Sunrise, Loader2, FileText, Sheet, ImageIcon, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { exportToXls } from "@/lib/exportReport";
import html2canvas from "html2canvas";
import { jsPDF } from "jspdf";

const PRIO_LABEL = { basse: "Basse", normale: "Normale", haute: "Haute" };

export default function MorningBriefing() {
  const { toast } = useToast();
  const cardRef = useRef(null);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('morningBriefing', {});
      setData(res);
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  const cur = data?.kpis?.currency || "XAF";

  const exportImage = async () => {
    if (!cardRef.current) return;
    setBusy(true);
    try {
      const canvas = await html2canvas(cardRef.current, { backgroundColor: "#ffffff", scale: 2 });
      const url = canvas.toDataURL("image/png");
      const a = document.createElement("a");
      a.href = url;
      a.download = `resume_matinal_${data?.date || ""}.png`;
      a.click();
      toast({ title: "Image générée" });
    } catch (e) { toast({ title: "Erreur export image", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const exportPdf = async () => {
    if (!cardRef.current) return;
    setBusy(true);
    try {
      const canvas = await html2canvas(cardRef.current, { backgroundColor: "#ffffff", scale: 2 });
      const img = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "portrait", unit: "pt", format: "a4" });
      const pw = pdf.internal.pageSize.getWidth();
      const ph = pdf.internal.pageSize.getHeight();
      const imgW = pw - 60;
      const imgH = (canvas.height * imgW) / canvas.width;
      let y = 30;
      if (imgH < ph - 60) {
        pdf.addImage(img, "PNG", 30, y, imgW, imgH);
      } else {
        // paginated
        let remaining = canvas.height;
        let srcY = 0;
        const pageImgH = (ph - 60) * (canvas.width / imgW);
        while (remaining > 0) {
          const sliceCanvas = document.createElement("canvas");
          sliceCanvas.width = canvas.width;
          sliceCanvas.height = Math.min(pageImgH, remaining);
          const ctx = sliceCanvas.getContext("2d");
          ctx.drawImage(canvas, 0, srcY, canvas.width, sliceCanvas.height, 0, 0, canvas.width, sliceCanvas.height);
          pdf.addImage(sliceCanvas.toDataURL("image/png"), "PNG", 30, 30, imgW, (sliceCanvas.height * imgW) / canvas.width);
          srcY += sliceCanvas.height;
          remaining -= sliceCanvas.height;
          if (remaining > 0) pdf.addPage();
        }
      }
      pdf.save(`resume_matinal_${data?.date || ""}.pdf`);
      toast({ title: "PDF généré" });
    } catch (e) { toast({ title: "Erreur export PDF", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  const exportExcel = () => {
    if (!data) return;
    setBusy(true);
    try {
      const rows = [
        ...(data.tasksToday || []).map((t) => ({ section: "Tâches du jour", titre: t.title, detail: PRIO_LABEL[t.priority] || "", date: t.start ? formatDateFr(t.start) : "" })),
        ...(data.eventsToday || []).map((ev) => ({ section: "Événements du jour", titre: ev.title, detail: ev.location || "", date: ev.start ? formatDateFr(ev.start) : "" })),
        ...(data.tasksUpcoming || []).map((t) => ({ section: "Tâches à venir", titre: t.title, detail: PRIO_LABEL[t.priority] || "", date: t.start ? formatDateFr(t.start) : "" })),
        ...(data.recentExpenses || []).map((e) => ({ section: "Dépenses récentes", titre: e.name, detail: formatCurrency(e.amount, cur), date: e.date ? formatDateFr(e.date) : "" })),
      ];
      const columns = [
        { key: "section", label: "Section" },
        { key: "titre", label: "Titre" },
        { key: "detail", label: "Détail" },
        { key: "date", label: "Date" },
      ];
      const summary = [
        { label: "Date", value: data.date || "" },
        { label: "Budget", value: formatCurrency(data.kpis.budget, cur) },
        { label: "Dépenses du jour", value: formatCurrency(data.kpis.depensesJour, cur) },
        { label: "Reste", value: formatCurrency(data.kpis.reste, cur) },
      ];
      exportToXls("Résumé matinal", data.date || "", columns, rows, cur, summary);
      toast({ title: "Excel généré" });
    } catch (e) { toast({ title: "Erreur export Excel", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl flex items-center gap-2"><Sunrise className="w-6 h-6 text-accent" /> Résumé matinal</h1>
          <p className="text-muted-foreground mt-1">Votre synthèse du jour, générée puis exportable en image, PDF ou Excel.</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}><RefreshCw className={`w-4 h-4 mr-1 ${loading ? "animate-spin" : ""}`} /> Actualiser</Button>
          <Button size="sm" onClick={exportImage} disabled={busy || !data}><ImageIcon className="w-4 h-4 mr-1" /> Image</Button>
          <Button size="sm" onClick={exportPdf} disabled={busy || !data}><FileText className="w-4 h-4 mr-1" /> PDF</Button>
          <Button size="sm" variant="outline" onClick={exportExcel} disabled={busy || !data}><Sheet className="w-4 h-4 mr-1" /> Excel</Button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : data ? (
        <div ref={cardRef} className="bg-card border border-border rounded-2xl p-5 space-y-5">
          <div>
            <p className="text-sm text-muted-foreground">{data.greeting} · {formatDateFr(data.date)}</p>
            {data.message && <p className="text-sm mt-3 whitespace-pre-wrap leading-relaxed">{data.message}</p>}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Kpi label="Budget" value={formatCurrency(data.kpis.budget, cur)} />
            <Kpi label="Dépenses du jour" value={formatCurrency(data.kpis.depensesJour, cur)} />
            <Kpi label="Total dépenses" value={formatCurrency(data.kpis.totalExpense, cur)} />
            <Kpi label="Reste" value={formatCurrency(data.kpis.reste, cur)} tone={data.kpis.reste < 0 ? "danger" : "ok"} />
            <Kpi label="Tâches du jour" value={String(data.kpis.tasksToday)} />
            <Kpi label="Tâches à venir" value={String(data.kpis.tasksUpcoming)} />
            <Kpi label="Événements du jour" value={String(data.kpis.eventsToday)} />
            <Kpi label="Plans d'épargne actifs" value={String(data.kpis.activePlans)} />
          </div>

          <Section title="Tâches du jour" items={(data.tasksToday || []).map((t) => `${t.title}${t.priority ? ` · ${PRIO_LABEL[t.priority] || ""}` : ""}`)} />
          <Section title="Événements du jour" items={(data.eventsToday || []).map((ev) => `${ev.title}${ev.location ? ` · ${ev.location}` : ""}`)} />
          <Section title="Tâches à venir" items={(data.tasksUpcoming || []).map((t) => `${t.title}${t.start ? ` · ${formatDateFr(t.start)}` : ""}`)} />
          <Section title="Dépenses récentes" items={(data.recentExpenses || []).map((e) => `${e.name} · ${formatCurrency(e.amount, cur)}${e.date ? ` · ${formatDateFr(e.date)}` : ""}`)} />
        </div>
      ) : null}
    </div>
  );
}

function Kpi({ label, value, tone }) {
  const cls = tone === "danger" ? "text-destructive" : tone === "ok" ? "text-primary" : "";
  return (
    <div className="bg-secondary/40 rounded-xl px-3 py-2">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`text-sm font-medium truncate ${cls}`}>{value}</p>
    </div>
  );
}

function Section({ title, items }) {
  if (!items || items.length === 0) return null;
  return (
    <div>
      <p className="text-sm font-medium mb-1.5">{title}</p>
      <ul className="space-y-1">
        {items.map((it, i) => <li key={i} className="text-sm text-muted-foreground flex gap-2"><span className="text-accent">•</span><span>{it}</span></li>)}
      </ul>
    </div>
  );
}