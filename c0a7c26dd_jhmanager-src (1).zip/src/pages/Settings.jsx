import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { useTheme } from "@/lib/ThemeProvider";
import { useI18n } from "@/lib/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import LegalLinks from "@/components/settings/LegalLinks";
import PaymentCard from "@/components/settings/PaymentCard";

export default function Settings() {
  const { t, setLang } = useI18n();
  const [preferences, setPreferences] = useState(null);
  const [currency, setCurrency] = useState("XAF");
  const [language, setLanguage] = useState("fr");
  const [initialBudget, setInitialBudget] = useState("0");
  const [reminderDays, setReminderDays] = useState("7");
  const [theme, setThemeState] = useState("system");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [canceling, setCanceling] = useState(false);
  const { toast } = useToast();
  const { setTheme } = useTheme();

  useEffect(() => {
    (async () => {
      const list = await base44.entities.Preferences.list();
      const p = list?.[0] || null;
      setPreferences(p);
      setCurrency(p?.currency || "XAF");
      setLanguage(p?.language || "fr");
      setInitialBudget(String(p?.initial_budget ?? 0));
      setReminderDays(String(p?.reminder_days ?? 7));
      setThemeState(p?.theme || "system");
      if (p?.language) setLang(p.language);
      setLoading(false);
    })();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    const data = {
      currency,
      initial_budget: parseFloat(initialBudget) || 0,
      reminder_days: parseInt(reminderDays, 10) || 7,
      theme,
      language,
    };
    setTheme(theme);
    setLang(language);
    try {
      if (preferences) {
        await base44.entities.Preferences.update(preferences.id, data);
      } else {
        const created = await base44.entities.Preferences.create(data);
        setPreferences(created);
      }
      toast({ title: t("toast.prefsSaved") });
    } catch (err) {
      toast({ title: t("toast.error"), description: t("err.save"), variant: "destructive" });
    }
    setSaving(false);
  };

  const handleDeleteAccount = async () => {
    setDeleting(true);
    try {
      const res = await base44.functions.invoke('deleteAccount', {});
      if (res?.dataDeleted) {
        toast({ title: t("toast.accountDeleted"), description: t("toast.accountDeletedDesc") });
        await base44.auth.logout();
        window.location.href = "/login";
      } else {
        toast({ title: t("toast.partial"), description: res?.warning || t("toast.partialDesc"), variant: "destructive" });
      }
    } catch (err) {
      toast({ title: t("toast.error"), description: err?.message || t("err.deleteAccount"), variant: "destructive" });
    }
    setDeleting(false);
    setDeleteOpen(false);
  };

  const handleCancelSubscription = async () => {
    setCanceling(true);
    try {
      const res = await base44.functions.invoke('cancelSubscription', {});
      if (res?.success) {
        try { await base44.auth.updateMe({ account_type: "" }); } catch { /* non-fatal */ }
        toast({ title: "Abonnement résilié", description: "Votre abonnement a été résilié." });
        window.location.href = "/";
      } else {
        toast({ title: "Erreur", description: res?.error || "Résiliation impossible", variant: "destructive" });
      }
    } catch (err) {
      toast({ title: "Erreur", description: err?.message || "Résiliation impossible", variant: "destructive" });
    }
    setCanceling(false);
    setCancelOpen(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-lg space-y-6">
      <div>
        <h1 className="font-display text-3xl">{t("settings.title")}</h1>
        <p className="text-muted-foreground mt-1">{t("settings.subtitle")}</p>
      </div>

      <form onSubmit={handleSave} className="bg-card border border-border rounded-2xl p-6 space-y-5">
        <div className="space-y-2">
          <Label>{t("settings.language")}</Label>
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="fr">{t("lang.fr")}</SelectItem>
              <SelectItem value="en">{t("lang.en")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>{t("settings.currency")}</Label>
          <Select value={currency} onValueChange={setCurrency}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="XAF">{t("currency.XAF")}</SelectItem>
              <SelectItem value="EUR">{t("currency.EUR")}</SelectItem>
              <SelectItem value="USD">{t("currency.USD")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>{t("settings.theme")}</Label>
          <Select value={theme} onValueChange={setThemeState}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="system">{t("theme.system")}</SelectItem>
              <SelectItem value="light">{t("theme.light")}</SelectItem>
              <SelectItem value="dark">{t("theme.dark")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="budget">{t("settings.budget")}</Label>
          <Input id="budget" type="number" min="0" step="any" value={initialBudget} onChange={(e) => setInitialBudget(e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="reminder">{t("settings.reminder")}</Label>
          <Input id="reminder" type="number" min="1" step="1" value={reminderDays} onChange={(e) => setReminderDays(e.target.value)} />
        </div>
        <Button type="submit" className="w-full" disabled={saving}>
          {saving ? t("settings.saving") : t("settings.save")}
        </Button>
      </form>

      <PaymentCard />

      <div className="bg-card border border-border rounded-2xl p-6 space-y-3">
        <div>
          <h2 className="font-display text-lg">Abonnement</h2>
          <p className="text-sm text-muted-foreground mt-1">Résiliez votre abonnement à tout moment. Vous pourrez vous réabonner ultérieurement.</p>
        </div>
        <Button variant="outline" className="text-destructive border-destructive/40 hover:bg-destructive/10" onClick={() => setCancelOpen(true)}>Résilier mon abonnement</Button>
      </div>

      <LegalLinks />

      <div className="bg-card border border-destructive/30 rounded-2xl p-6 space-y-3">
        <div>
          <h2 className="font-display text-lg text-destructive">{t("settings.dangerZone")}</h2>
          <p className="text-sm text-muted-foreground mt-1">{t("settings.dangerDesc")}</p>
        </div>
        <Button variant="destructive" onClick={() => setDeleteOpen(true)}>{t("settings.deleteAccount")}</Button>
      </div>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("settings.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("settings.deleteDesc")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={(e) => { e.preventDefault(); handleDeleteAccount(); }}
              disabled={deleting}
            >
              {deleting ? t("settings.deleting") : t("settings.confirmDelete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={cancelOpen} onOpenChange={setCancelOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Résilier votre abonnement ?</AlertDialogTitle>
            <AlertDialogDescription>Votre abonnement sera désactivé. Vous reviendrez à l'étape de choix d'abonnement et pourrez vous réabonner à tout moment.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={canceling}>Annuler</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); handleCancelSubscription(); }} disabled={canceling}>{canceling ? "Résiliation..." : "Résilier"}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}