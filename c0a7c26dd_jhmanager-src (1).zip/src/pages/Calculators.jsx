import React, { useEffect, useState } from "react";
import { Calculator as CalcIcon, Sigma, FunctionSquare, Wrench } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useSpace } from "@/lib/SpaceContext";
import { loadMetrics } from "@/lib/calcSources";
import { computeGrandeurs } from "@/lib/mathEval";
import ScientificCalculator from "@/components/calculator/ScientificCalculator";
import GrandeursPanel from "@/components/calculator/GrandeursPanel";
import FonctionsPanel from "@/components/calculator/FonctionsPanel";
import QuickTools from "@/components/calculator/QuickTools";

export default function Calculators() {
  const { activeCompanyId } = useSpace();
  const [items, setItems] = useState([]);
  const [metrics, setMetrics] = useState({});
  const [loading, setLoading] = useState(true);

  const scope = computeGrandeurs(items.filter((i) => i.kind === "grandeur"), metrics);

  const reload = async () => {
    const list = await base44.entities.CalcDefinition.list("-created_date", 500);
    setItems(list || []);
  };

  useEffect(() => {
    (async () => {
      await reload();
      try { const m = await loadMetrics(activeCompanyId); setMetrics(m); } catch { /* ignore */ }
      setLoading(false);
    })();
  }, [activeCompanyId]);

  if (loading)
    return <div className="flex items-center justify-center h-64"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl flex items-center gap-2"><CalcIcon className="w-7 h-7" /> Calculateur</h1>
        <p className="text-muted-foreground mt-1">Calculatrice scientifique, grandeurs et fonctions personnalisées — réutilisez vos données Finances, Stock, Ventes et Factures.</p>
      </div>

      <Tabs defaultValue="calc" className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto no-scrollbar">
          <TabsTrigger value="calc" className="gap-1.5"><CalcIcon className="w-4 h-4" /> Calculatrice</TabsTrigger>
          <TabsTrigger value="grandeurs" className="gap-1.5"><Sigma className="w-4 h-4" /> Grandeurs</TabsTrigger>
          <TabsTrigger value="fonctions" className="gap-1.5"><FunctionSquare className="w-4 h-4" /> Fonctions</TabsTrigger>
          <TabsTrigger value="outils" className="gap-1.5"><Wrench className="w-4 h-4" /> Outils rapides</TabsTrigger>
        </TabsList>
        <TabsContent value="calc" className="mt-4"><ScientificCalculator scope={scope} /></TabsContent>
        <TabsContent value="grandeurs" className="mt-4"><GrandeursPanel items={items} metrics={metrics} reload={reload} /></TabsContent>
        <TabsContent value="fonctions" className="mt-4"><FonctionsPanel items={items} metrics={metrics} reload={reload} /></TabsContent>
        <TabsContent value="outils" className="mt-4"><QuickTools /></TabsContent>
      </Tabs>
    </div>
  );
}