import React from "react";
import { Link } from "react-router-dom";
import { useI18n } from "@/lib/i18n";

export default function Terms() {
  const { t } = useI18n();
  return (
    <div className="min-h-screen bg-background font-body px-5 py-10 max-w-2xl mx-auto">
      <h1 className="font-display text-3xl mb-4">{t("legal.termsTitle")}</h1>
      <div className="prose prose-sm text-muted-foreground space-y-3">
        <p>{t("legal.termsIntro")}</p>
        <h2 className="font-display text-base text-foreground">{t("legal.termsUseTitle")}</h2>
        <p>{t("legal.termsUse")}</p>
        <h2 className="font-display text-base text-foreground">{t("legal.termsAccountsTitle")}</h2>
        <p>{t("legal.termsAccounts")}</p>
        <h2 className="font-display text-base text-foreground">{t("legal.termsLiabilityTitle")}</h2>
        <p>{t("legal.termsLiability")}</p>
        <h2 className="font-display text-base text-foreground">{t("legal.termsContactTitle")}</h2>
        <p>{t("legal.termsContact")}</p>
      </div>
      <Link to="/login" className="text-sm text-primary hover:underline mt-6 inline-block">{t("legal.back")}</Link>
    </div>
  );
}