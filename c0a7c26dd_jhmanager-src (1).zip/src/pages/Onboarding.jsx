import React, { useState } from "react";
import { User, Building2, Check, ShieldCheck, Gift } from "lucide-react";
import { Link } from "react-router-dom";
import SubscribeDialog from "@/components/onboarding/SubscribeDialog";

const PLANS = [
  {
    type: "particulier",
    amount: 5000,
    label: "Compte Particulier",
    icon: User,
    tagline: "JH Personal Manager — Gestion personnelle",
    features: ["Finances & budget personnel", "Tâches et planning", "Assistant IA", "Import de fichiers pour l'analyse"],
    styles: {
      card: "border-primary/40 bg-primary/5",
      badge: "bg-primary text-primary-foreground",
      check: "text-primary",
      btn: "bg-primary text-primary-foreground hover:bg-primary/90",
    },
  },
  {
    type: "entreprise",
    amount: 20000,
    label: "Compte Entreprise",
    icon: Building2,
    tagline: "JH Business Manager — Gestion d'entreprise",
    features: ["Stock & inventaire", "Ventes, clients & devis", "Taxes & prestataires", "Partenariats", "Assistant IA"],
    styles: {
      card: "border-accent/40 bg-accent/5",
      badge: "bg-accent text-accent-foreground",
      check: "text-accent",
      btn: "bg-accent text-accent-foreground hover:bg-accent/90",
    },
  },
];

export default function Onboarding() {
  const [plan, setPlan] = useState(null);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="px-6 pt-10 pb-6 text-center">
        <p className="font-display text-3xl">JH Manager</p>
        <h1 className="font-display text-2xl mt-2">Choisissez votre type de compte</h1>
        <p className="text-muted-foreground mt-1 text-sm max-w-md mx-auto">
          Un compte est soit Particulier (JH Personal Manager) ou Entreprise (JH Business Manager). L'abonnement est unique et
          débité directement sur votre Mobile Money.
        </p>
      </header>

      <div className="flex-1 px-4 sm:px-6 pb-10 max-w-3xl mx-auto w-full space-y-4">
        {PLANS.map((p) => (
          <div key={p.type} className={`rounded-3xl border p-6 ${p.styles.card}`}>
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${p.styles.badge}`}>
                <p.icon className="w-6 h-6" />
              </div>
              <div className="min-w-0">
                <h2 className="font-display text-xl">{p.label}</h2>
                <p className="text-xs text-muted-foreground">{p.tagline}</p>
              </div>
              <div className="ml-auto text-right shrink-0">
                <p className="font-display text-2xl">
                  {p.type !== "particulier" ? "dès " : ""}{p.amount.toLocaleString("fr-FR")}{" "}
                  <span className="text-sm font-body">XAF</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  {p.type === "entreprise" ? "/ entreprise" : "par abonnement"}
                </p>
              </div>
            </div>

            <ul className="mt-4 space-y-1.5">
              {p.features.map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm">
                  <Check className={`w-4 h-4 shrink-0 ${p.styles.check}`} /> {f}
                </li>
              ))}
            </ul>

            <button onClick={() => setPlan(p)} className={`no-select-tap mt-5 w-full min-touch rounded-xl font-medium transition-colors ${p.styles.btn}`}>
              S'abonner — {p.label}
            </button>
          </div>
        ))}

        <Link
          to="/affiliation"
          className="no-select-tap w-full max-w-md mx-auto flex items-center justify-center gap-2 rounded-xl border border-accent/40 bg-accent/5 text-accent-foreground px-4 py-3 font-medium hover:bg-accent/10 transition-colors"
        >
          <Gift className="w-4 h-4" /> Devenir affilié — parrainez et gagnez 20 %
        </Link>

        <p className="text-xs text-muted-foreground text-center flex items-center justify-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5" /> Paiement sécurisé via Airtel Money / Moov Money (Gabon).
        </p>
      </div>

      <SubscribeDialog
        plan={plan}
        open={!!plan}
        onOpenChange={(o) => !o && setPlan(null)}
        onSuccess={() => { window.location.href = "/"; }}
      />
    </div>
  );
}