import React from "react";
import FaqSection from "@/components/landing/FaqSection";

export default function Faq() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl">FAQ</h1>
        <p className="text-muted-foreground mt-1">
          Questions fréquentes et aide. Posez une question à notre équipe si besoin.
        </p>
      </div>
      <FaqSection />
    </div>
  );
}