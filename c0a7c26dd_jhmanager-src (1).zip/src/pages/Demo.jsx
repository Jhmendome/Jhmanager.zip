import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Sparkles, FlaskConical, ArrowRight, CheckCircle2, User, Building2, Wallet, ListChecks, Boxes, FileText, Bot } from "lucide-react";
import Landing from "@/pages/Landing";
import DashboardPreview from "@/components/demo/DashboardPreview";

export default function Demo() {
  const [step, setStep] = useState("accueil"); // accueil | abonne

  return (
    <div className="min-h-screen bg-background">
      {/* Bannière Mode démo */}
      <div className="sticky top-0 z-50 bg-primary text-primary-foreground px-4 py-2.5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs sm:text-sm font-medium">
          <FlaskConical className="w-4 h-4 shrink-0" />
          <span className="truncate">Mode démo — aperçu du parcours utilisateur (sans transaction réelle)</span>
        </div>
        <Link to="/" className="no-select-tap shrink-0 text-xs sm:text-sm underline underline-offset-2 hover:opacity-80">
          Quitter la démo
        </Link>
      </div>

      {/* Étape 1 : Accueil public */}
      {step === "accueil" && (
        <div className="relative">
          <Landing />
          {/* CTA flottant pour simuler l'abonnement */}
          <motion.div
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="fixed bottom-4 inset-x-4 z-40 mx-auto max-w-md"
          >
            <button
              onClick={() => setStep("abonne")}
              className="no-select-tap min-touch w-full rounded-2xl bg-accent text-accent-foreground shadow-lg px-5 py-3.5 font-medium inline-flex items-center justify-center gap-2 hover:bg-accent/90 transition-colors"
            >
              Simuler un abonnement validé <ArrowRight className="w-4 h-4" />
            </button>
            <p className="text-center text-xs text-muted-foreground mt-1.5">
              Le bouton d'abonnement réel enverrait vers le paiement Mobile Money.
            </p>
          </motion.div>
        </div>
      )}

      {/* Étape 2 : Utilisateur abonné (validé par défaut) */}
      {step === "abonne" && (
        <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl border border-border bg-card p-5 flex flex-col sm:flex-row items-center gap-4 justify-between">
            <div className="flex items-center gap-3 text-center sm:text-left">
              <div className="w-11 h-11 rounded-2xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <p className="font-display text-lg">Paiement simulé réussi ✓</p>
                <p className="text-sm text-muted-foreground">Abonnement activé automatiquement — aucune transaction financière.</p>
              </div>
            </div>
            <button
              onClick={() => setStep("accueil")}
              className="no-select-tap min-touch rounded-xl border border-border px-4 py-2 text-sm font-medium hover:bg-accent/10 transition-colors"
            >
              ← Revenir à l'accueil public
            </button>
          </motion.div>

          <DashboardPreview />

          {/* Rappel des deux espaces */}
          <div className="grid sm:grid-cols-2 gap-4">
            <SpaceRecap
              icon={User} tone="primary" badge="JH Personal Manager" title="Particulier"
              features={["Finances & budget", "Tâches & planning", "Assistant IA", "Collaboration"]}
              price="5 000 XAF / mois"
            />
            <SpaceRecap
              icon={Building2} tone="accent" badge="JH Business Manager" title="Entreprise"
              features={["Stock & ventes", "Devis", "Assistant IA", "Multi-entreprises"]}
              price="20 000 XAF / mois / entreprise"
            />
          </div>
        </div>
      )}
    </div>
  );
}

function SpaceRecap({ icon: Icon, tone, badge, title, features, price }) {
  const isAccent = tone === "accent";
  return (
    <div className={`rounded-2xl border p-5 ${isAccent ? "border-accent/30 bg-accent/5" : "border-primary/30 bg-primary/5"}`}>
      <div className="flex items-center gap-3 mb-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isAccent ? "bg-accent text-accent-foreground" : "bg-primary text-primary-foreground"}`}>
          <Icon className="w-5 h-5" />
        </div>
        <span className={`text-xs font-medium px-2 py-1 rounded-full ${isAccent ? "bg-accent/15 text-accent-foreground" : "bg-primary/10 text-primary"}`}>{badge}</span>
        <span className="font-display text-lg ml-auto">{price}</span>
      </div>
      <ul className="space-y-1.5">
        {features.map((f) => (
          <li key={f} className="flex items-center gap-2 text-sm">
            <CheckCircle2 className={`w-4 h-4 shrink-0 ${isAccent ? "text-accent-foreground" : "text-primary"}`} /> {f}
          </li>
        ))}
      </ul>
    </div>
  );
}