import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ShieldAlert, Clock, XCircle, Send, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function ResubscriptionGate({ status, onSubmitted }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    try {
      await base44.entities.ReSubscriptionRequest.create({
        email: (user?.email || "").toLowerCase().trim(),
        message: message.trim(),
      });
      toast({ title: "Demande envoyée", description: "Les administrateurs ont été notifiés." });
      setMessage("");
      onSubmitted?.();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const canSubmit = status !== "pending";

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-card border border-border rounded-3xl p-6 space-y-4 text-center">
        <ShieldAlert className="w-10 h-10 text-accent mx-auto" />
        <h1 className="font-display text-xl">Compte désactivé</h1>

        {status === "pending" ? (
          <>
            <Clock className="w-6 h-6 text-muted-foreground mx-auto" />
            <p className="text-sm text-muted-foreground">
              Votre demande de réabonnement est en cours de traitement. Un administrateur vous répondra bientôt.
            </p>
          </>
        ) : (
          <>
            {status === "rejected" && (
              <>
                <XCircle className="w-6 h-6 text-destructive mx-auto" />
                <p className="text-sm text-muted-foreground">
                  Votre précédente demande a été refusée. Vous pouvez en soumettre une nouvelle.
                </p>
              </>
            )}
            {status === "none" && (
              <p className="text-sm text-muted-foreground">
                Votre compte a été supprimé par un administrateur. Pour recréer un compte avec cette adresse,
                vous devez d'abord demander un réabonnement.
              </p>
            )}
            <div className="text-left space-y-2">
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Expliquez pourquoi vous souhaitez réactiver votre compte…"
                rows={4}
              />
            </div>
            <Button onClick={submit} disabled={busy || !canSubmit} className="w-full">
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Send className="w-4 h-4 mr-2" /> Demander un réabonnement</>}
            </Button>
          </>
        )}
      </div>
    </div>
  );
}