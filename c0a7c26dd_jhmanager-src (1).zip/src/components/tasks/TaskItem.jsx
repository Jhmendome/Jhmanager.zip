import React, { useState } from "react";
import { Pencil, Trash2, CheckCircle2, Circle } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { formatDateFr } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const PRIORITY_DOT = {
  basse: "bg-muted-foreground/40",
  normale: "bg-accent",
  haute: "bg-destructive",
};

export default function TaskItem({ task, onEdit, onDelete, onToggleDone, conflict, selectable, selected, onToggleSelect }) {
  const { t } = useI18n();
  const done = task.status === "terminee";
  const [confirmOpen, setConfirmOpen] = useState(false);

  return (
    <>
      <div className={`flex items-center gap-3 p-4 rounded-2xl border border-border bg-card ${done ? "opacity-60" : ""}`}>
        {selectable && (
          <Checkbox
            checked={!!selected}
            onCheckedChange={() => onToggleSelect(task.id)}
            aria-label="Sélectionner"
            className="shrink-0"
          />
        )}
        <button
          onClick={() => onToggleDone(task)}
          aria-label={t("taskitem.toggleAria")}
          className="no-select-tap min-touch shrink-0 flex items-center justify-center rounded-full text-muted-foreground hover:text-primary transition-colors"
        >
          {done ? <CheckCircle2 className="w-5 h-5 text-primary" /> : <Circle className="w-5 h-5" />}
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className={`text-sm font-medium truncate ${done ? "line-through" : ""}`}>{task.title}</p>
            <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${PRIORITY_DOT[task.priority] || PRIORITY_DOT.normale}`} title={t("priority." + (task.priority || "normale"))} />
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">
            {formatDateFr(task.start, true)} → {formatDateFr(task.end, true)}
            {conflict && <span className="text-destructive ml-2">{t("taskitem.conflict")}</span>}
          </p>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => onEdit(task)}
            aria-label={t("taskitem.editAria")}
            className="no-select-tap min-touch p-2.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
          >
            <Pencil className="w-4 h-4" />
          </button>
          <button
            onClick={() => setConfirmOpen(true)}
            aria-label={t("taskitem.deleteAria")}
            className="no-select-tap min-touch p-2.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-destructive transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("taskitem.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("taskitem.deleteDesc", { title: task.title })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => onDelete(task)}
            >
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}