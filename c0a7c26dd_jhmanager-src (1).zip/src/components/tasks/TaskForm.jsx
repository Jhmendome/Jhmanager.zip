import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useI18n } from "@/lib/i18n";
import CategorySelect from "@/components/categories/CategorySelect";
import { useSpace } from "@/lib/SpaceContext";

function toLocalInput(value) {
  if (!value) return "";
  const d = new Date(value);
  if (isNaN(d.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function TaskForm({ open, onOpenChange, task, onSubmit }) {
  const { t } = useI18n();
  const { space } = useSpace();
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [priority, setPriority] = useState("normale");
  const [status, setStatus] = useState("a_faire");
  const [repeat, setRepeat] = useState(false);
  const [frequency, setFrequency] = useState("mois");
  const [repeatCount, setRepeatCount] = useState("1");
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setTitle(task?.title || "");
      setStart(toLocalInput(task?.start) || toLocalInput(new Date().toISOString()));
      setEnd(toLocalInput(task?.end) || toLocalInput(new Date(Date.now() + 60 * 60 * 1000).toISOString()));
      setPriority(task?.priority || "normale");
      setStatus(task?.status || "a_faire");
      setCategory(task?.category || "");
      setRepeat(false);
      setFrequency("mois");
      setRepeatCount("1");
      setError("");
    }
  }, [open, task]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError(t("taskform.err.title"));
      return;
    }
    const startDate = new Date(start);
    const endDate = new Date(end);
    if (endDate.isNaN || isNaN(endDate.getTime()) || isNaN(startDate.getTime())) {
      setError(t("taskform.err.dates"));
      return;
    }
    if (endDate < startDate) {
      setError(t("taskform.err.endBeforeStart"));
      return;
    }
    const duration_minutes = Math.round((endDate.getTime() - startDate.getTime()) / 60000);
    onSubmit({
      title: title.trim(),
      start: startDate.toISOString(),
      end: endDate.toISOString(),
      duration_minutes,
      priority,
      status,
      category: category.trim(),
    }, repeat && !task && parseInt(repeatCount, 10) > 1 ? { frequency, count: parseInt(repeatCount, 10) } : null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">{task ? t("taskform.edit") : t("taskform.new")}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="space-y-2">
            <Label htmlFor="title">{t("taskform.name")}</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t("taskform.namePlaceholder")} autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="start">{t("taskform.start")}</Label>
              <Input id="start" type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end">{t("taskform.end")}</Label>
              <Input id="end" type="datetime-local" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("taskform.priority")}</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="basse">{t("priority.basse")}</SelectItem>
                  <SelectItem value="normale">{t("priority.normale")}</SelectItem>
                  <SelectItem value="haute">{t("priority.haute")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t("taskform.status")}</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="a_faire">{t("tasks.filter.todo")}</SelectItem>
                  <SelectItem value="en_cours">{t("tasks.filter.progress")}</SelectItem>
                  <SelectItem value="terminee">{t("tasks.filter.done")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Catégorie</Label>
            <CategorySelect scope={space} domain="tache" value={category} onChange={setCategory} placeholder="Catégorie" />
          </div>
          {!task && (
            <div className="space-y-3 rounded-xl border border-border p-3">
              <div className="flex items-center gap-2">
                <Checkbox checked={repeat} onCheckedChange={setRepeat} id="task-repeat" />
                <Label htmlFor="task-repeat">Répéter périodiquement</Label>
              </div>
              {repeat && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="task-freq" className="text-xs">Fréquence</Label>
                    <Select value={frequency} onValueChange={setFrequency}>
                      <SelectTrigger id="task-freq"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="jour">Jour</SelectItem>
                        <SelectItem value="semaine">Semaine</SelectItem>
                        <SelectItem value="trimestre">Trimestre</SelectItem>
                        <SelectItem value="mois">Mois</SelectItem>
                        <SelectItem value="annee">Année</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="task-count" className="text-xs">Nombre d'occurrences</Label>
                    <Input id="task-count" type="number" min="1" max="120" value={repeatCount} onChange={(e) => setRepeatCount(e.target.value)} />
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button type="submit" className="w-full">{task ? t("common.save") : t("taskform.add")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}