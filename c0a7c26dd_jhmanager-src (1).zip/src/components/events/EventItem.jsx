import React, { useState } from "react";
import { Pencil, Trash2, MapPin } from "lucide-react";
import { formatDateFr } from "@/lib/format";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const CATEGORY_BADGE = {
  reunion: "bg-primary/10 text-primary",
  rendez_vous: "bg-accent/20 text-accent-foreground",
  formation: "bg-chart-3/15 text-chart-3",
  ceremonie: "bg-sidebar-primary/20 text-sidebar-primary",
  autre: "bg-secondary text-secondary-foreground",
};

const CATEGORY_LABEL = {
  reunion: "Réunion",
  rendez_vous: "Rendez-vous",
  formation: "Formation",
  ceremonie: "Cérémonie",
  autre: "Autre",
};

const PRIORITY_DOT = {
  basse: "bg-muted-foreground/40",
  normale: "bg-accent",
  haute: "bg-destructive",
};

export default function EventItem({ event, onEdit, onDelete, conflict }) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  return (
    <>
      <div className="flex items-center gap-3 p-4 rounded-2xl border border-border bg-card">
        <span className={`w-1.5 h-10 rounded-full shrink-0 ${PRIORITY_DOT[event.priority] || PRIORITY_DOT.normale}`} title={event.priority || "normale"} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-sm font-medium truncate">{event.title}</p>
            <span className={`text-[11px] px-2 py-0.5 rounded-full ${CATEGORY_BADGE[event.category] || CATEGORY_BADGE.autre}`}>
              {CATEGORY_LABEL[event.category] || "Autre"}
            </span>
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">
            {formatDateFr(event.start, true)} → {formatDateFr(event.end, true)}
            {conflict && <span className="text-destructive ml-2">⚠ Conflit détecté</span>}
          </p>
          {event.location && (
            <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1 truncate">
              <MapPin className="w-3 h-3 shrink-0" /> {event.location}
            </p>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => onEdit(event)}
            aria-label="Modifier"
            className="no-select-tap min-touch p-2.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
          >
            <Pencil className="w-4 h-4" />
          </button>
          <button
            onClick={() => setConfirmOpen(true)}
            aria-label="Supprimer"
            className="no-select-tap min-touch p-2.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-destructive transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Supprimer cet événement ?</AlertDialogTitle>
            <AlertDialogDescription>
              Cette action est définitive. L'événement « {event.title} » sera supprimé pour toujours.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => onDelete(event)}
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}