import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

function toLocalInput(value) {
  if (!value) return "";
  const d = new Date(value);
  if (isNaN(d.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const CATEGORIES = [
  { value: "reunion", label: "Réunion" },
  { value: "rendez_vous", label: "Rendez-vous" },
  { value: "formation", label: "Formation" },
  { value: "ceremonie", label: "Cérémonie" },
  { value: "autre", label: "Autre" },
];

const PRIORITIES = [
  { value: "basse", label: "Basse" },
  { value: "normale", label: "Normale" },
  { value: "haute", label: "Haute" },
];

export default function EventForm({ open, onOpenChange, event, onSubmit }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [location, setLocation] = useState("");
  const [category, setCategory] = useState("autre");
  const [priority, setPriority] = useState("normale");
  const [repeat, setRepeat] = useState(false);
  const [frequency, setFrequency] = useState("mois");
  const [repeatCount, setRepeatCount] = useState("1");
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setTitle(event?.title || "");
      setDescription(event?.description || "");
      setStart(toLocalInput(event?.start) || toLocalInput(new Date().toISOString()));
      setEnd(toLocalInput(event?.end) || toLocalInput(new Date(Date.now() + 60 * 60 * 1000).toISOString()));
      setLocation(event?.location || "");
      setCategory(event?.category || "autre");
      setPriority(event?.priority || "normale");
      setRepeat(false);
      setFrequency("mois");
      setRepeatCount("1");
      setError("");
    }
  }, [open, event]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError("Le nom de l'événement est obligatoire.");
      return;
    }
    const startDate = new Date(start);
    const endDate = new Date(end);
    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      setError("Dates invalides.");
      return;
    }
    if (endDate < startDate) {
      setError("La date de fin doit être après la date de début.");
      return;
    }
    onSubmit({
      title: title.trim(),
      description: description.trim(),
      start: startDate.toISOString(),
      end: endDate.toISOString(),
      location: location.trim(),
      category,
      priority,
    }, repeat && !event && parseInt(repeatCount, 10) > 1 ? { frequency, count: parseInt(repeatCount, 10) } : null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">{event ? "Modifier l'événement" : "Nouvel événement"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="space-y-2">
            <Label htmlFor="ev-title">Nom de l'événement</Label>
            <Input id="ev-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Réunion équipe, rendez-vous client…" autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="ev-start">Début</Label>
              <Input id="ev-start" type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ev-end">Fin</Label>
              <Input id="ev-end" type="datetime-local" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="ev-location">Lieu</Label>
            <Input id="ev-location" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Bureau, salle, adresse…" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Catégorie</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Priorité</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="ev-desc">Description</Label>
            <Textarea id="ev-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Détails, ordre du jour…" />
          </div>
          {!event && (
            <div className="space-y-3 rounded-xl border border-border p-3">
              <div className="flex items-center gap-2">
                <Checkbox checked={repeat} onCheckedChange={setRepeat} id="ev-repeat" />
                <Label htmlFor="ev-repeat">Répéter périodiquement</Label>
              </div>
              {repeat && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="ev-freq" className="text-xs">Fréquence</Label>
                    <Select value={frequency} onValueChange={setFrequency}>
                      <SelectTrigger id="ev-freq"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="jour">Jour</SelectItem>
                        <SelectItem value="semaine">Semaine</SelectItem>
                        <SelectItem value="trimestre">Trimestre</SelectItem>
                        <SelectItem value="mois">Mois</SelectItem>
                        <SelectItem value="annee">Année</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="ev-count" className="text-xs">Nombre d'occurrences</Label>
                    <Input id="ev-count" type="number" min="1" max="120" value={repeatCount} onChange={(e) => setRepeatCount(e.target.value)} />
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button type="submit" className="w-full">{event ? "Enregistrer" : "Ajouter l'événement"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}