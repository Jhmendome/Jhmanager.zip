import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

const NEW_VALUE = "__new__";

// Sélecteur de catégorie réutilisable : liste les catégories existantes pour
// (scope, domain, company_id) et permet d'en créer une nouvelle à la volée.
export default function CategorySelect({ scope, domain, companyId = null, value, onChange, placeholder = "Catégorie" }) {
  const [options, setOptions] = useState([]);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.Category.list("-created_date", 500);
      const filtered = (list || []).filter(
        (c) => c.scope === scope && c.domain === domain && (!c.company_id || c.company_id === companyId)
      );
      setOptions(filtered);
    } catch {
      setOptions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); /* recharge au changement de contexte */ }, [scope, domain, companyId]);

  const handleValueChange = (v) => {
    if (v === NEW_VALUE) {
      setCreating(true);
      return;
    }
    const found = options.find((o) => o.id === v);
    onChange(found ? found.name : v);
  };

  const handleCreate = async () => {
    const name = newName.trim();
    if (!name) { setCreating(false); return; }
    try {
      const created = await base44.entities.Category.create({ name, scope, domain, company_id: companyId || undefined });
      setOptions((prev) => [created, ...prev]);
      onChange(name);
    } catch {
      onChange(name); // fallback : on conserve le texte même si la persistance échoue
    } finally {
      setNewName("");
      setCreating(false);
    }
  };

  const selectedId = options.find((o) => o.name === value)?.id || "";

  return (
    <div className="space-y-2">
      {creating ? (
        <div className="flex items-center gap-2">
          <Input
            autoFocus
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Nom de la nouvelle catégorie"
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); handleCreate(); } }}
          />
          <Button type="button" size="sm" onClick={handleCreate}>Ajouter</Button>
          <Button type="button" size="sm" variant="ghost" onClick={() => setCreating(false)}>Annuler</Button>
        </div>
      ) : (
        <Select value={selectedId || (value && !options.find((o) => o.name === value) ? value : "")} onValueChange={handleValueChange} disabled={loading}>
          <SelectTrigger>
            <SelectValue placeholder={placeholder} />
          </SelectTrigger>
          <SelectContent>
            {options.map((o) => (
              <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>
            ))}
            {value && !options.find((o) => o.name === value) && (
              <SelectItem value={value}>{value} (hors liste)</SelectItem>
            )}
            <SelectItem value={NEW_VALUE}>
              <span className="flex items-center gap-1 text-accent"><Plus className="w-3.5 h-3.5" /> Nouvelle catégorie</span>
            </SelectItem>
          </SelectContent>
        </Select>
      )}
    </div>
  );
}