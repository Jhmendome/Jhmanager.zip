import React from "react";
import { Download, FileText, Sheet } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { exportToPdf, exportToXls } from "@/lib/exportReport";

// columns: [{ key, label, type? }]; rows, currency, summary: [{label,value}]
export default function ExportMenu({ title, subtitle, columns, rows, currency, summary }) {
  const { t } = useI18n();
  const disabled = !rows || rows.length === 0;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" disabled={disabled}>
          <Download className="w-4 h-4 mr-2" /> {t("export.title")}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => exportToPdf(title, subtitle, columns, rows, currency, summary)}>
          <FileText className="w-4 h-4 mr-2" /> {t("export.pdf")}
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => exportToXls(title, subtitle, columns, rows, currency, summary)}>
          <Sheet className="w-4 h-4 mr-2" /> {t("export.excel")}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}