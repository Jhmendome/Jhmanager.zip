import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown, HelpCircle, Loader2, Send, MessageCircleQuestion } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Link } from "react-router-dom";

// Questions fréquentes statiques (présentation claire de la plateforme).
const SHORT = "JH Personal Manager";
const BIZ = "JH Business Manager";
const BRAND = "JH Manager";

const STATIC_FAQ = [
  {
    q: "Qu'est-ce que JH Manager ?",
    a: `${BRAND} est une plateforme tout-en-un : ${SHORT} pour gérer votre vie personnelle (finances, tâches, planning) et ${BIZ} pour gérer votre entreprise (stock, ventes, devis, partenariats). Un seul abonnement, un seul compte.`,
  },
  {
    q: `Quelle est la différence entre ${SHORT} et ${BIZ} ?`,
    a: `${SHORT} (Particulier, 5 000 XAF/mois) couvre la gestion personnelle. ${BIZ} (Entreprise, 20 000 XAF/mois par entreprise gérée) couvre la gestion d'activité. Vous choisissez l'espace qui correspond à votre besoin.`,
  },
  {
    q: "Comment fonctionne l'affiliation ?",
    a: "Devenez affilié, partagez votre lien. Toute personne qui s'abonne via votre lien vous rapporte 20 % du prix normal (1 000 XAF/mois par particulier, 4 000 XAF/mois par entreprise) — à vie. Le filleul bénéficie de 20 % de réduction pendant 6 mois.",
  },
  {
    q: "Comment payer l'abonnement ?",
    a: "Le paiement se fait directement via Airtel Money ou Moov Money (Gabon). Aucune carte bancaire requise.",
  },
  {
    q: `Puis-je avoir plusieurs entreprises en ${BIZ} ?`,
    a: `Oui. Le tarif ${BIZ} est de 20 000 XAF/mois par entreprise gérée. Vous ajoutez autant d'entreprises que nécessaire.`,
  },
];

export default function FaqSection() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(0);
  const [published, setPublished] = useState([]);
  const [question, setQuestion] = useState("");
  const [category, setCategory] = useState("general");
  const [busy, setBusy] = useState(false);
  const [mine, setMine] = useState([]);

  const load = async () => {
    if (!user) return;
    try {
      const list = await base44.entities.FaqQuestion.list("-created_date", 50);
      setMine((list || []).filter((q) => q.is_published || q.created_by_id === user.id || user.role === "admin"));
      setPublished((list || []).filter((q) => q.is_published && q.answer));
    } catch { /* ignore */ }
  };

  useEffect(() => { load(); /* eslint-disable-line */ }, [user]);

  const submit = async (e) => {
    e.preventDefault();
    if (!question.trim()) return;
    setBusy(true);
    try {
      await base44.entities.FaqQuestion.create({ question: question.trim(), category });
      toast({ title: "Question envoyée", description: "Notre équipe vous répondra bientôt." });
      setQuestion("");
      setCategory("general");
      load();
    } catch (err) {
      toast({ title: "Erreur", description: err?.message || "Échec de l'envoi", variant: "destructive" });
    } finally { setBusy(false); }
  };

  const allFaq = [...STATIC_FAQ, ...published.map((p) => ({ q: p.question, a: p.answer }))];

  return (
    <section className="py-14 px-4">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/15 text-accent-foreground text-xs font-medium mb-3">
            <MessageCircleQuestion className="w-4 h-4" /> FAQ
          </div>
          <h2 className="font-display text-3xl sm:text-4xl">Questions fréquentes</h2>
          <p className="text-muted-foreground mt-2">Tout ce que vous devez savoir avant de commencer.</p>
        </motion.div>

        <div className="space-y-2">
          {allFaq.map((f, i) => (
            <div key={i} className="rounded-2xl border border-border bg-card overflow-hidden">
              <button
                onClick={() => setOpen(open === i ? -1 : i)}
                className="no-select-tap w-full flex items-center justify-between gap-3 p-4 text-left"
              >
                <span className="font-medium text-sm sm:text-base">{f.q}</span>
                <ChevronDown className={`w-4 h-4 shrink-0 transition-transform ${open === i ? "rotate-180" : ""}`} />
              </button>
              <motion.div
                initial={false}
                animate={{ height: open === i ? "auto" : 0, opacity: open === i ? 1 : 0 }}
                className="overflow-hidden"
              >
                <p className="px-4 pb-4 text-sm text-muted-foreground">{f.a}</p>
              </motion.div>
            </div>
          ))}
        </div>

        <div className="mt-8 rounded-3xl border border-accent/30 bg-gradient-to-br from-accent/10 to-primary/5 p-6">
          <div className="flex items-center gap-2 mb-3">
            <HelpCircle className="w-5 h-5 text-accent" />
            <h3 className="font-display text-lg">Posez votre question</h3>
          </div>
          {user ? (
            <form onSubmit={submit} className="space-y-3">
              <Textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Décrivez votre question…"
                rows={3}
                className="bg-background"
              />
              <div className="flex flex-col sm:flex-row gap-2">
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="h-9 rounded-md border border-input bg-transparent px-3 text-sm"
                >
                  <option value="general">Général</option>
                  <option value="jpm">JH Personal Manager</option>
                  <option value="jbm">JH Business Manager</option>
                  <option value="paiement">Paiement</option>
                  <option value="affiliation">Affiliation</option>
                  <option value="compte">Compte</option>
                </select>
                <Button type="submit" disabled={busy} className="flex-1">
                  {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  Envoyer
                </Button>
              </div>
            </form>
          ) : (
            <div className="text-center py-2">
              <p className="text-sm text-muted-foreground mb-3">Connectez-vous pour poser une question à notre équipe.</p>
              <Button asChild variant="outline">
                <Link to="/register?returnTo=/">Se connecter pour poser une question</Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}