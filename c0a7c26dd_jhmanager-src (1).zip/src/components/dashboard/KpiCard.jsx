import React from "react";

export default function KpiCard({ icon: Icon, label, value, hint, tone = "default" }) {
  const toneClasses = {
    default: "bg-primary/10 text-primary",
    accent: "bg-accent/15 text-accent",
    warn: "bg-destructive/10 text-destructive",
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5 flex items-start gap-4 shadow-sm">
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${toneClasses[tone]}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="font-display text-xl mt-0.5 truncate">{value}</p>
        {hint && <p className="text-sm text-muted-foreground mt-1">{hint}</p>}
      </div>
    </div>
  );
}