import React, { useMemo } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { useI18n } from "@/lib/i18n";
import { formatCurrency } from "@/lib/format";

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
];

export default function ExpenseChart({ expenses = [], currency = "XAF" }) {
  const { t } = useI18n();

  const data = useMemo(() => {
    const map = {};
    expenses.forEach((e) => {
      const cat = (e.category || "").trim() || "Autre";
      const val = (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0);
      map[cat] = (map[cat] || 0) + val;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  if (!data.length) {
    return (
      <div className="bg-card border border-border rounded-2xl p-5 sm:p-6">
        <h2 className="font-display text-lg mb-3">{t("dashboard.expenseChart")}</h2>
        <p className="text-sm text-muted-foreground">{t("dashboard.expenseChartEmpty")}</p>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-5 sm:p-6">
      <h2 className="font-display text-lg mb-4">{t("dashboard.expenseChart")}</h2>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              cx="50%"
              cy="50%"
              outerRadius={80}
              innerRadius={40}
              paddingAngle={2}
            >
              {data.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip formatter={(v) => formatCurrency(v, currency)} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}