import React, { useMemo } from "react";
import { Heart } from "lucide-react";
import { getDailyLifeAdvice } from "@/lib/lifeAdvice";

export default function LifeTipCard({ space = "jpm" }) {
  const advice = useMemo(() => getDailyLifeAdvice(space), [space]);
  return (
    <div className="bg-card border border-border rounded-2xl p-5 sm:p-6 flex items-start gap-3">
      <Heart className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
      <div>
        <p className="text-sm font-medium">Conseil de vie</p>
        <p className="text-sm text-muted-foreground mt-1">{advice}</p>
      </div>
    </div>
  );
}