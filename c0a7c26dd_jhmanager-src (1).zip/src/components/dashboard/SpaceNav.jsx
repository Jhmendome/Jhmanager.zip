import React from "react";
import { useNavigate } from "react-router-dom";
import { User, Building2 } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { useSpace } from "@/lib/SpaceContext";
import { useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

// Bascule fluide JPM/JBM : un clic navigue directement vers l'espace choisi
// (et positionne l'espace actif). Réservé à l'admin, qui voit les deux.
export default function SpaceNav() {
  const { user } = useAuth();
  const { space, setSpace } = useSpace();
  const navigate = useNavigate();
  const location = useLocation();
  if (user?.role !== "admin") return null;

  const go = (next) => {
    setSpace(next);
    navigate(next === "jbm" ? "/jbm" : "/");
  };
  const here = location.pathname;

  const Btn = ({ value, icon: Icon, label }) => {
    const active = space === value;
    return (
      <button
        onClick={() => go(value)}
        aria-pressed={active}
        className={cn(
          "no-select-tap min-touch flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-medium transition-colors",
          active ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"
        )}
      >
        <Icon className="w-4 h-4" /> {label}
      </button>
    );
  };

  return (
    <div className="inline-flex p-1 rounded-2xl bg-secondary/60 border border-border gap-1">
      <Btn value="jpm" icon={User} label="Espace personnel" />
      <Btn value="jbm" icon={Building2} label="Espace entreprise" />
      {here !== "/" && here !== "/jbm" && (
        <span className="hidden sm:inline text-xs text-muted-foreground self-center pl-1">Aller à l'espace souhaité</span>
      )}
    </div>
  );
}