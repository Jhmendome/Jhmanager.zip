import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

export default function DashboardWindow({ to, icon: Icon, title, badge, children, hint }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-5 flex flex-col">
      <div className="flex items-center gap-2 mb-2">
        <Link to={to} className="font-display text-lg hover:underline flex items-center gap-2">
          {Icon && <Icon className="w-4 h-4" />} {title}
        </Link>
        {badge != null && (
          <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">{badge}</span>
        )}
      </div>
      {children}
      {hint && <p className="text-sm text-muted-foreground mt-2">{hint}</p>}
      <Link to={to} className="text-sm text-primary hover:underline mt-3 inline-flex items-center gap-1 self-start">
        Voir tout <ChevronRight className="w-3 h-3" />
      </Link>
    </div>
  );
}