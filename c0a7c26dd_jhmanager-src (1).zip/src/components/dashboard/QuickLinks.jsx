import React from "react";
import { Link } from "react-router-dom";

export default function QuickLinks({ items }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {items.map(({ to, label, icon: Icon, desc }) => (
        <Link
          key={to}
          to={to}
          className="bg-card border border-border rounded-2xl p-4 flex flex-col gap-2 hover:border-primary/40 transition-colors"
        >
          <Icon className="w-5 h-5 text-primary" />
          <span className="text-sm font-medium">{label}</span>
          {desc && <span className="text-xs text-muted-foreground">{desc}</span>}
        </Link>
      ))}
    </div>
  );
}