import React, { useEffect, useState } from "react";
import { Banknote } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { formatCurrency } from "@/lib/format";

const PERIODS = [
  { key: "7d", label: "7 jours", days: 7 },
  { key: "30d", label: "30 jours", days: 30 },
  { key: "12m", label: "12 mois", days: 365 },
  { key: "all", label: "Tout", days: null },
];

export default function RevenueCard() {
  const [subs, setSubs] = useState([]);
  const [period, setPeriod] = useState("30d");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        setSubs(await base44.entities.Subscription.list("-paid_at", 1000));
      } catch {
        setSubs([]);
      }
      setLoading(false);
    })();
  }, []);

  const cfg = PERIODS.find((p) => p.key === period);
  const now = new Date();
  const since = cfg.days ? new Date(now.getTime() - cfg.days * 86400000) : null;
  const filtered = subs.filter(
    (s) => s.status === "payee" && (!since || new Date(s.paid_at || s.created_date) >= since)
  );
  const total = filtered.reduce((sum, s) => sum + (Number(s.amount) || 0), 0);
  const particulier = filtered
    .filter((s) => s.account_type === "particulier")
    .reduce((a, s) => a + (Number(s.amount) || 0), 0);
  const entreprise = filtered
    .filter((s) => s.account_type === "entreprise")
    .reduce((a, s) => a + (Number(s.amount) || 0), 0);

  return (
    <div className="bg-card border border-border rounded-2xl p-5 sm:p-6">
      <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
        <div className="flex items-center gap-2">
          <Banknote className="w-5 h-5 text-primary" />
          <h2 className="font-display text-lg">Chiffre d'affaires</h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">Admin</span>
        </div>
        <div className="flex gap-1 bg-muted rounded-lg p-1">
          {PERIODS.map((p) => (
            <button
              key={p.key}
              onClick={() => setPeriod(p.key)}
              className={`no-select-tap px-2.5 py-1 text-xs rounded-md transition-colors ${
                period === p.key ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="h-8 w-40 bg-muted animate-pulse rounded" />
      ) : (
        <>
          <p className="font-display text-3xl">{formatCurrency(total, "XAF")}</p>
          <p className="text-xs text-muted-foreground mt-1">
            {filtered.length} abonnement(s) sur la période.
          </p>
          <div className="grid grid-cols-2 gap-3 mt-4">
            <div className="rounded-xl bg-primary/5 p-3">
              <p className="text-xs text-muted-foreground">Particulier (JPM)</p>
              <p className="font-display text-lg">{formatCurrency(particulier, "XAF")}</p>
            </div>
            <div className="rounded-xl bg-accent/10 p-3">
              <p className="text-xs text-muted-foreground">Entreprise (JBM)</p>
              <p className="font-display text-lg">{formatCurrency(entreprise, "XAF")}</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}