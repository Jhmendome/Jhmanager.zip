import React, { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";
import { format, parseISO } from "date-fns";
import { useI18n } from "@/lib/i18n";
import { formatCurrency } from "@/lib/format";

export default function SalesChart({ sales = [], currency = "XAF" }) {
  const { t } = useI18n();

  const data = useMemo(() => {
    const map = {};
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      map[format(d, "yyyy-MM")] = 0;
    }
    sales.forEach((s) => {
      if (s.status === "annulee") return;
      const d = s.date ? parseISO(s.date) : null;
      if (!d) return;
      const key = format(d, "yyyy-MM");
      if (key in map) {
        map[key] += (Number(s.quantity) || 0) * (Number(s.unit_price) || 0);
      }
    });
    return Object.entries(map).map(([key, value]) => ({
      month: format(new Date(key + "-01"), "MMM"),
      value,
    }));
  }, [sales]);

  const hasData = data.some((d) => d.value > 0);

  if (!hasData) {
    return (
      <div className="bg-card border border-border rounded-2xl p-5 sm:p-6">
        <h2 className="font-display text-lg mb-3">{t("jbm.dashboard.salesChart")}</h2>
        <p className="text-sm text-muted-foreground">{t("jbm.dashboard.salesChartEmpty")}</p>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-5 sm:p-6">
      <h2 className="font-display text-lg mb-4">{t("jbm.dashboard.salesChart")}</h2>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
            <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
            <Tooltip formatter={(v) => formatCurrency(v, currency)} />
            <Bar dataKey="value" fill="hsl(var(--chart-2))" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}