import React from "react";
import { User, Building2 } from "lucide-react";
import { useSpace } from "@/lib/SpaceContext";
import { useAuth } from "@/lib/AuthContext";
import { cn } from "@/lib/utils";

// Admin-only preview toggle between JPM (Particulier) and JBM (Entreprise).
// Normal users keep the space fixed by their onboarding account type.
export default function ModeSwitcher() {
  const { user } = useAuth();
  const { space, setSpace } = useSpace();

  if (user?.role !== "admin") return null;

  const Btn = ({ value, icon: Icon, label, activeClass }) => (
    <button
      onClick={() => setSpace(value)}
      aria-pressed={space === value}
      className={cn(
        "no-select-tap min-touch flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
        space === value
          ? activeClass
          : "text-muted-foreground hover:text-foreground"
      )}
    >
      <Icon className="w-4 h-4" /> {label}
    </button>
  );

  return (
    <div className="inline-flex p-1 rounded-xl bg-secondary border border-border">
      <Btn value="jpm" icon={User} label="JPM" activeClass="bg-primary text-primary-foreground shadow" />
      <Btn value="jbm" icon={Building2} label="JBM" activeClass="bg-accent text-accent-foreground shadow" />
    </div>
  );
}