import React from "react";
import { Sparkles } from "lucide-react";

export default function TipCard({ title, children }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-5 sm:p-6 flex items-start gap-3">
      <Sparkles className="w-5 h-5 text-accent shrink-0 mt-0.5" />
      <div>
        <p className="text-sm font-medium">{title}</p>
        <p className="text-sm text-muted-foreground mt-1">{children}</p>
      </div>
    </div>
  );
}