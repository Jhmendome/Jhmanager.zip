import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { ListChecks } from "lucide-react";
import DashboardWindow from "./DashboardWindow";
import { formatDateFr } from "@/lib/format";

export default function TasksWindow() {
  const [tasks, setTasks] = useState([]);
  useEffect(() => {
    (async () => {
      try {
        const list = await base44.entities.Task.list("start", 200);
        const now = new Date();
        setTasks(
          (list || [])
            .filter((t) => t.status !== "terminee" && t.start && new Date(t.start) >= now)
            .slice(0, 4)
        );
      } catch { /* ignore */ }
    })();
  }, []);

  return (
    <DashboardWindow to="/taches" icon={ListChecks} title="Tâches" badge={tasks.length || undefined}>
      {tasks.length === 0 ? (
        <p className="text-sm text-muted-foreground">Aucune tâche à venir.</p>
      ) : (
        <ul className="space-y-2">
          {tasks.map((t) => (
            <li key={t.id} className="flex items-center gap-2 text-sm">
              <span className={`w-2 h-2 rounded-full shrink-0 ${t.priority === "haute" ? "bg-destructive" : t.priority === "normale" ? "bg-accent" : "bg-muted-foreground/40"}`} />
              <span className="flex-1 truncate">{t.title}</span>
              <span className="text-xs text-muted-foreground whitespace-nowrap">{formatDateFr(t.start)}</span>
            </li>
          ))}
        </ul>
      )}
    </DashboardWindow>
  );
}