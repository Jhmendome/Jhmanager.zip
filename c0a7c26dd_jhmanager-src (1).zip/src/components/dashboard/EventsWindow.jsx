import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { CalendarClock } from "lucide-react";
import DashboardWindow from "./DashboardWindow";
import { formatDateFr } from "@/lib/format";
import { useSpace } from "@/lib/SpaceContext";

export default function EventsWindow() {
  const { space, activeCompanyId } = useSpace();
  const [events, setEvents] = useState([]);
  useEffect(() => {
    (async () => {
      try {
        const list = await base44.entities.Event.list("start", 200);
        const scoped = space === "jpm"
          ? (list || [])
          : (list || []).filter((e) => !activeCompanyId || e.company_id === activeCompanyId);
        const now = new Date();
        setEvents(scoped.filter((e) => new Date(e.start) >= now).slice(0, 4));
      } catch { /* ignore */ }
    })();
  }, [space, activeCompanyId]);

  return (
    <DashboardWindow to="/evenements" icon={CalendarClock} title="Événements" badge={events.length || undefined}>
      {events.length === 0 ? (
        <p className="text-sm text-muted-foreground">Aucun événement à venir.</p>
      ) : (
        <ul className="space-y-2">
          {events.map((e) => (
            <li key={e.id} className="flex items-center gap-2 text-sm">
              <CalendarClock className="w-3 h-3 text-accent shrink-0" />
              <span className="flex-1 truncate">{e.title}</span>
              <span className="text-xs text-muted-foreground whitespace-nowrap">{formatDateFr(e.start)}</span>
            </li>
          ))}
        </ul>
      )}
    </DashboardWindow>
  );
}