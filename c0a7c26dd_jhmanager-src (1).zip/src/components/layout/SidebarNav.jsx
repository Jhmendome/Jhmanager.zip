import React from "react";
import { NavLink } from "react-router-dom";
import { LayoutDashboard, Wallet, ListChecks, CalendarRange, CalendarDays, Bell, Calculator, Gauge, Settings, LogOut, Bot, Boxes, ShoppingCart, Users, FileText, Building2, ScrollText, Truck, Percent, Link, Lightbulb, CalendarClock, BarChart3, UsersRound, HelpCircle, FileDown, Sunrise } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";

const ACCOUNT_BADGE = {
  jpm: { label: "Particulier", className: "bg-primary/15 text-primary" },
  jbm: { label: "Entreprise", className: "bg-accent/20 text-accent" },
};

export default function SidebarNav({ userEmail }) {
  const { t } = useI18n();
  const { space, companies, activeCompanyId } = useSpace();
  const badge = ACCOUNT_BADGE[space] || ACCOUNT_BADGE.jpm;

  const JPM_ITEMS = [
    { to: "/", label: t("nav.home"), icon: LayoutDashboard },
    { to: "/finances", label: t("nav.finances"), icon: Wallet },
    { to: "/taches", label: t("nav.tasks"), icon: ListChecks },
    { to: "/planning", label: t("nav.planning"), icon: CalendarRange },
    { to: "/evenements", label: t("nav.events"), icon: CalendarClock },
    { to: "/calendrier", label: t("nav.calendar"), icon: CalendarDays },
    { to: "/notifications", label: t("nav.notifications"), icon: Bell },
    { to: "/seuils", label: t("nav.thresholds"), icon: Gauge },
    { to: "/calculateurs", label: t("nav.calculators"), icon: Calculator },
    { to: "/reporting", label: "Reporting", icon: BarChart3 },
    { to: "/exportations", label: "Exportations", icon: FileDown },
    { to: "/assistants", label: t("nav.agents"), icon: Bot },
    { to: "/collaborateurs", label: "Collaborateurs", icon: UsersRound },
    { to: "/suggestions", label: t("nav.suggestions"), icon: Lightbulb },
    { to: "/faq", label: "FAQ", icon: HelpCircle },
    { to: "/resume-matinal", label: "Résumé matinal", icon: Sunrise },
    { to: "/parametres", label: t("nav.settings"), icon: Settings },
  ];

  const JBM_ITEMS = [
    { to: "/jbm", label: t("jbm.nav.dashboard"), icon: LayoutDashboard },
    { to: "/finances", label: t("nav.finances"), icon: Wallet },
    { to: "/taches", label: t("nav.tasks"), icon: ListChecks },
    { to: "/planning", label: t("nav.planning"), icon: CalendarRange },
    { to: "/evenements", label: t("nav.events"), icon: CalendarClock },
    { to: "/calendrier", label: t("nav.calendar"), icon: CalendarDays },
    { to: "/jbm/stock", label: t("jbm.nav.stock"), icon: Boxes },
    { to: "/jbm/ventes", label: t("jbm.nav.sales"), icon: ShoppingCart },
    { to: "/jbm/clients", label: t("nav.clients"), icon: Users },
    { to: "/jbm/devis", label: t("nav.quotes"), icon: ScrollText },
    { to: "/jbm/personnel", label: t("jbm.nav.personnel"), icon: Users },
    { to: "/jbm/prestataires", label: t("nav.suppliers"), icon: Truck },
    { to: "/jbm/taxes", label: t("nav.taxes"), icon: Percent },
    { to: "/jbm/partenariats", label: t("nav.partnerships"), icon: Link },
    { to: "/jbm/entreprises", label: t("jbm.nav.companies"), icon: Building2 },
    { to: "/calculateurs", label: t("nav.calculators"), icon: Calculator },
    { to: "/reporting", label: "Reporting", icon: BarChart3 },
    { to: "/exportations", label: "Exportations", icon: FileDown },
    { to: "/collaborateurs", label: "Collaborateurs", icon: UsersRound },
    { to: "/assistants", label: t("nav.agents"), icon: Bot },
    { to: "/suggestions", label: t("nav.suggestions"), icon: Lightbulb },
    { to: "/faq", label: "FAQ", icon: HelpCircle },
    { to: "/parametres", label: t("nav.settings"), icon: Settings },
  ];

  const ITEMS = space === "jbm" ? JBM_ITEMS : JPM_ITEMS;
  const activeCompany = companies.find((c) => c.id === activeCompanyId);

  return (
    <aside className="hidden md:flex md:flex-col md:fixed md:inset-y-0 md:left-0 md:w-64 bg-sidebar text-sidebar-foreground px-5 py-8 overflow-y-auto">
      <div className="mb-6 px-2">
        <p className="font-display text-2xl tracking-tight">JH Manager</p>
      </div>
      <div className="mb-6 px-1">
        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${badge.className}`}>
          {badge.label}
        </span>
      </div>
      {space === "jbm" && (
        <p className="text-xs text-sidebar-foreground/50 px-2 mb-4 truncate">
          {activeCompany?.name || t("jbm.companies.empty")}
        </p>
      )}
      <nav className="flex-1 space-y-1">
        {ITEMS.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/" || to === "/jbm"}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
              }`
            }
          >
            <Icon className="w-4 h-4" />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="pt-4 border-t border-sidebar-border/60">
        <p className="text-xs text-sidebar-foreground/50 px-3 truncate mb-2">{userEmail}</p>
        <button
          onClick={() => base44.auth.logout()}
          className="no-select-tap flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground w-full transition-colors"
        >
          <LogOut className="w-4 h-4" />
          {t("nav.logout")}
        </button>
      </div>
    </aside>
  );
}