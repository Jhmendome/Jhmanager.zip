import React from "react";
import { NavLink } from "react-router-dom";
import { LayoutDashboard, Wallet, ListChecks, CalendarRange, CalendarDays, Bell, Calculator, Gauge, Settings, Bot, Boxes, ShoppingCart, Users, FileText, ScrollText, Truck, Percent, Link, CalendarClock, Lightbulb, UsersRound, HelpCircle } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useSpace } from "@/lib/SpaceContext";

export default function BottomNav() {
  const { t } = useI18n();
  const { space } = useSpace();

  const JPM_ITEMS = [
    { to: "/", label: t("nav.home"), icon: LayoutDashboard },
    { to: "/finances", label: t("nav.finances"), icon: Wallet },
    { to: "/taches", label: t("nav.tasks"), icon: ListChecks },
    { to: "/planning", label: t("nav.planning"), icon: CalendarRange },
    { to: "/evenements", label: t("nav.events"), icon: CalendarClock },
    { to: "/calendrier", label: t("nav.calendar"), icon: CalendarDays },
    { to: "/notifications", label: t("nav.notifications"), icon: Bell },
    { to: "/seuils", label: t("nav.thresholds"), icon: Gauge },
    { to: "/calculateurs", label: t("nav.calculators"), icon: Calculator },
    { to: "/collaborateurs", label: "Collaborateurs", icon: UsersRound },
    { to: "/assistants", label: t("nav.agents"), icon: Bot },
    { to: "/suggestions", label: t("nav.suggestions"), icon: Lightbulb },
    { to: "/faq", label: "FAQ", icon: HelpCircle },
    { to: "/parametres", label: t("nav.settings"), icon: Settings },
  ];

  const JBM_ITEMS = [
    { to: "/jbm", label: t("jbm.nav.dashboard"), icon: LayoutDashboard },
    { to: "/finances", label: t("nav.finances"), icon: Wallet },
    { to: "/taches", label: t("nav.tasks"), icon: ListChecks },
    { to: "/planning", label: t("nav.planning"), icon: CalendarRange },
    { to: "/evenements", label: t("nav.events"), icon: CalendarClock },
    { to: "/calendrier", label: t("nav.calendar"), icon: CalendarDays },
    { to: "/jbm/stock", label: t("jbm.nav.stock"), icon: Boxes },
    { to: "/jbm/ventes", label: t("jbm.nav.sales"), icon: ShoppingCart },
    { to: "/jbm/factures", label: t("jbm.nav.invoices"), icon: FileText },
    { to: "/jbm/clients", label: t("nav.clients"), icon: Users },
    { to: "/jbm/devis", label: t("nav.quotes"), icon: ScrollText },
    { to: "/jbm/prestataires", label: t("nav.suppliers"), icon: Truck },
    { to: "/jbm/taxes", label: t("nav.taxes"), icon: Percent },
    { to: "/jbm/partenariats", label: t("nav.partnerships"), icon: Link },
    { to: "/collaborateurs", label: "Collaborateurs", icon: UsersRound },
    { to: "/assistants", label: t("nav.agents"), icon: Bot },
    { to: "/faq", label: "FAQ", icon: HelpCircle },
    { to: "/parametres", label: t("nav.settings"), icon: Settings },
  ];

  const NAV_ITEMS = space === "jbm" ? JBM_ITEMS : JPM_ITEMS;

  return (
    <nav className="no-select-tap md:hidden fixed bottom-0 inset-x-0 bg-card/95 backdrop-blur border-t border-border z-20">
      <div className="flex items-stretch overflow-x-auto no-scrollbar px-1 pb-[env(safe-area-inset-bottom)]">
        {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/" || to === "/jbm"}
            className={({ isActive }) =>
              `no-select-tap min-touch shrink-0 flex flex-col items-center justify-center gap-1 px-2.5 py-2 text-[11px] transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`
            }
          >
            <Icon className="w-5 h-5" />
            <span className="max-w-[60px] truncate">{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}