import React from "react";
import SpaceSwitcher from "@/components/layout/SpaceSwitcher";
import AddAccountButton from "@/components/account/AddAccountButton";
import { useSpace } from "@/lib/SpaceContext";
import { useAuth } from "@/lib/AuthContext";

// Barre de compte affichée en haut du contenu :
// - deux espaces possédés → sélecteur JPM / JBM ;
// - un seul espace (non-admin) → bouton « Ajouter un compte ».
export default function AccountBar() {
  const { availableSpaces, loading } = useSpace();
  const { user } = useAuth();
  if (loading || !user) return null;
  const isAdmin = user.role === "admin";
  if (isAdmin || availableSpaces.length >= 2) return <SpaceSwitcher />;
  return <AddAccountButton />;
}