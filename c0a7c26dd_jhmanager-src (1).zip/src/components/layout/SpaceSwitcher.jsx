import React from "react";
import { useNavigate } from "react-router-dom";
import { User, Building2 } from "lucide-react";
import { useSpace } from "@/lib/SpaceContext";
import { useI18n } from "@/lib/i18n";

export default function SpaceSwitcher() {
  const { space, setSpace } = useSpace();
  const { t } = useI18n();
  const navigate = useNavigate();

  const switchTo = (next) => {
    if (next === space) return;
    setSpace(next);
    navigate(next === "jbm" ? "/jbm" : "/");
  };

  return (
    <div className="no-select-tap inline-flex rounded-full bg-secondary p-1 text-xs font-medium">
      <button
        type="button"
        onClick={() => switchTo("jpm")}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-colors ${
          space === "jpm" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
        }`}
      >
        <User className="w-3.5 h-3.5" />
        {t("space.jpm")}
      </button>
      <button
        type="button"
        onClick={() => switchTo("jbm")}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-colors ${
          space === "jbm" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
        }`}
      >
        <Building2 className="w-3.5 h-3.5" />
        {t("space.jbm")}
      </button>
    </div>
  );
}