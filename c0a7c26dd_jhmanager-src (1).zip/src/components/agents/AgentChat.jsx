import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Send, Loader2, Plus, Paperclip, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Image } from "@/components/ui/image";
import { useToast } from "@/components/ui/use-toast";
import { useI18n } from "@/lib/i18n";
import MessageBubble from "./MessageBubble";

const IMAGE_EXT = /\.(png|jpe?g|gif|webp)$/i;

export default function AgentChat({ agentName }) {
  const { t } = useI18n();
  const { toast } = useToast();
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [attachment, setAttachment] = useState(null); // { url, name }
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const fileRef = useRef(null);
  const bottomRef = useRef(null);

  useEffect(() => {
    let unsub = () => {};
    setLoading(true);
    setMessages([]);
    setConversation(null);
    (async () => {
      try {
        const convs = await base44.agents.listConversations({ agent_name: agentName });
        let conv = convs?.[0];
        if (!conv) {
          conv = await base44.agents.createConversation({ agent_name: agentName, metadata: { name: agentName } });
        }
        setConversation(conv);
        setMessages(conv.messages || []);
        setLoading(false);
        unsub = base44.agents.subscribeToConversation(conv.id, (data) => {
          setMessages(data.messages || []);
        });
      } catch (e) {
        setLoading(false);
      }
    })();
    return () => { unsub(); };
  }, [agentName]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (sending && messages.length && messages[messages.length - 1].role === "assistant") {
      setSending(false);
    }
  }, [messages, sending]);

  const newConversation = async () => {
    try {
      const conv = await base44.agents.createConversation({ agent_name: agentName, metadata: { name: agentName } });
      setConversation(conv);
      setMessages([]);
      setSending(false);
    } catch (e) {
      /* ignore */
    }
  };

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || sending || uploading) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setAttachment({ url: file_url, name: file.name });
    } catch (err) {
      toast({ title: "Erreur", description: err?.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const send = async () => {
    const content = input.trim();
    if ((!content && !attachment) || !conversation || sending) return;
    const file_urls = attachment ? [attachment.url] : undefined;
    setInput("");
    setAttachment(null);
    setSending(true);
    setMessages((prev) => [...prev, { role: "user", content, file_urls: file_urls || [] }]);
    try {
      const conv = await base44.agents.addMessage(conversation, { role: "user", content, file_urls });
      setConversation(conv);
    } catch (e) {
      setSending(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[65vh]">
      <div className="flex justify-end mb-2">
        <Button variant="outline" size="sm" onClick={newConversation} className="no-select-tap">
          <Plus className="w-4 h-4 mr-1" /> {t("agents.newConversation")}
        </Button>
      </div>
      <div className="flex-1 overflow-y-auto space-y-4 pb-4">
        {messages.length === 0 && (
          <p className="text-sm text-muted-foreground text-center mt-10">{t("agents.empty")}</p>
        )}
        {messages.map((m, i) => (
          <MessageBubble key={i} message={m} />
        ))}
        {sending && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="w-4 h-4 animate-spin" /> {t("agents.thinking")}
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div className="pt-3 border-t border-border">
        {attachment && (
          <div className="flex items-center gap-2 mb-2 text-xs bg-muted rounded-lg px-2 py-1.5">
            {IMAGE_EXT.test(attachment.url) ? (
              <Image src={attachment.url} alt={attachment.name} className="w-8 h-8 rounded object-cover shrink-0" />
            ) : (
              <Paperclip className="w-4 h-4 shrink-0" />
            )}
            <span className="truncate flex-1">{attachment.name}</span>
            <button type="button" onClick={() => setAttachment(null)} className="no-select-tap p-1 rounded hover:bg-background">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
        <div className="flex gap-2">
          <input
            ref={fileRef}
            type="file"
            className="hidden"
            onChange={onFile}
            accept="image/*,audio/*,video/*,application/pdf"
          />
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => fileRef.current?.click()}
            disabled={sending || uploading}
            title="Joindre un fichier multimédia"
            className="no-select-tap shrink-0"
          >
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Paperclip className="w-4 h-4" />}
          </Button>
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder={t("agents.placeholder")}
            className="flex-1"
          />
          <Button onClick={send} disabled={(!input.trim() && !attachment) || sending} className="no-select-tap shrink-0">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}