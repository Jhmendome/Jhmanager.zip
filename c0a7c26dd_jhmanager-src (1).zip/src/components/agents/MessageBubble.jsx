import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import { ChevronRight, CheckCircle2, Loader2, AlertCircle, Wrench } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { Image } from "@/components/ui/image";

const IMAGE_EXT = /\.(png|jpe?g|gif|webp)$/i;
const MEDIA_RE = /(https?:\/\/[^\s)]+\.(mp3|wav|m4a|ogg|mp4|webm|mov))(?=[\s)]|$)/gi;

function FunctionDisplay({ toolCall }) {
  const { t } = useI18n();
  const [expanded, setExpanded] = useState(false);
  const proj = toolCall.display_projection || {};
  const hideDetails = proj.hide_details && proj.details_redacted;
  const status = toolCall.status || "pending";
  const failed = status === "failed" || status === "error";
  const running = ["pending", "running", "in_progress"].includes(status);

  let parsedArgs = toolCall.arguments_string;
  if (typeof parsedArgs === "string") {
    try { parsedArgs = JSON.parse(parsedArgs); } catch (e) { /* keep raw */ }
  }
  let parsedResults = toolCall.results;
  if (typeof parsedResults === "string") {
    try { parsedResults = JSON.parse(parsedResults); } catch (e) { /* keep raw */ }
  }

  const label = hideDetails
    ? (failed ? (proj.error_label || status) : running ? (proj.active_label || t("agents.tool.running")) : (proj.label || status))
    : (toolCall.name || t("agents.tool.running"));

  return (
    <div className="mt-2 text-xs rounded-lg border border-border bg-secondary/40 p-2">
      <button
        type="button"
        onClick={() => !hideDetails && setExpanded((v) => !v)}
        className="flex items-center gap-2 w-full text-left"
      >
        {failed
          ? <AlertCircle className="w-3.5 h-3.5 text-destructive shrink-0" />
          : running
            ? <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
            : <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0" />}
        <Wrench className="w-3 h-3 text-muted-foreground shrink-0" />
        <span className="font-medium truncate">{label}</span>
        {!hideDetails && (
          <ChevronRight className={`w-3 h-3 ml-auto shrink-0 transition-transform ${expanded ? "rotate-90" : ""}`} />
        )}
      </button>
      {expanded && !hideDetails && (
        <div className="mt-2 space-y-1">
          <p className="text-muted-foreground">{t("agents.tool.params")}</p>
          <pre className="whitespace-pre-wrap break-words rounded bg-background/60 p-1.5">
            {typeof parsedArgs === "string" ? parsedArgs : JSON.stringify(parsedArgs, null, 2)}
          </pre>
          {parsedResults !== undefined && (
            <>
              <p className="text-muted-foreground mt-1">{t("agents.tool.result")}</p>
              <pre className="whitespace-pre-wrap break-words rounded bg-background/60 p-1.5">
                {typeof parsedResults === "string" ? parsedResults : JSON.stringify(parsedResults, null, 2)}
              </pre>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default function MessageBubble({ message }) {
  const isUser = message.role === "user";
  return (
    <div className={isUser ? "flex justify-end" : "flex justify-start"}>
      <div
        className={`max-w-[85%] rounded-2xl px-4 py-2.5 ${
          isUser ? "bg-primary text-primary-foreground" : "bg-card border border-border"
        }`}
      >
        {message.content &&
          (isUser ? (
            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
          ) : (
            <div className="text-sm space-y-2 [&_p]:m-0 [&_ul]:list-disc [&_ul]:pl-4 [&_ol]:list-decimal [&_ol]:pl-4 [&_code]:rounded [&_code]:bg-secondary [&_code]:px-1">
              <ReactMarkdown
                components={{ img: ({ src, alt }) => (
                  <Image src={src} alt={alt || ""} className="rounded-lg max-h-56 w-auto max-w-full object-cover my-1" />
                ) }}
              >
                {message.content.replace(MEDIA_RE, "").trim()}
              </ReactMarkdown>
              {(message.content.match(MEDIA_RE) || []).map((url, i) =>
                /\.(mp3|wav|m4a|ogg)$/i.test(url) ? (
                  <audio key={`media${i}`} controls src={url} className="w-full mt-1" />
                ) : (
                  <video key={`media${i}`} controls src={url} className="w-full mt-1 max-h-60 rounded-lg" />
                )
              )}
            </div>
          ))}
        {message.file_urls?.length > 0 && (
          <div className="mt-2 flex flex-col gap-1">
            {message.file_urls.map((url, i) =>
              IMAGE_EXT.test(url) ? (
                <Image key={i} src={url} alt="pièce jointe" className="rounded-lg max-h-48 w-auto max-w-full object-cover" />
              ) : (
                <a key={i} href={url} target="_blank" rel="noreferrer" className="underline text-xs break-all">
                  {url.split("/").pop() || "Fichier"}
                </a>
              )
            )}
          </div>
        )}
        {message.tool_calls?.map((tc, i) => (
          <FunctionDisplay key={i} toolCall={tc} />
        ))}
      </div>
    </div>
  );
}