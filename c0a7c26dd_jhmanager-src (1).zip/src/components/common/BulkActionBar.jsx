import React from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BulkActionBar({ count, total, allSelected, onToggleAll, onClear, busy, children }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-3 flex items-center gap-3 flex-wrap shadow-sm sticky top-2 z-10">
      <div className="flex items-center gap-2">
        <Checkbox
          checked={total > 0 && allSelected}
          onCheckedChange={onToggleAll}
          disabled={total === 0}
          aria-label="Tout sélectionner"
        />
        <span className="text-sm font-medium whitespace-nowrap">
          {count > 0 ? `${count} sélectionné${count > 1 ? "s" : ""}` : "Sélectionner"}
          {total > 0 && <span className="text-muted-foreground"> / {total}</span>}
        </span>
      </div>
      <div className="flex items-center gap-2 flex-wrap flex-1">{children}</div>
      <Button variant="ghost" size="sm" onClick={onClear} disabled={busy}>
        <X className="w-4 h-4 mr-1" /> Annuler
      </Button>
    </div>
  );
}