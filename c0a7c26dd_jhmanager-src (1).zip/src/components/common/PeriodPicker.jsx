import React from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PERIOD_OPTIONS, CUSTOM_UNITS } from "@/lib/periods";

// Sélecteur de période unifié. Renvoie { period, customCount, customUnit } via onChange.
export default function PeriodPicker({ period, customCount = "", customUnit = "jour", onChange, label = "Périodicité", id }) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <Select value={period} onValueChange={(v) => onChange({ period: v, customCount, customUnit })}>
        <SelectTrigger id={id}><SelectValue /></SelectTrigger>
        <SelectContent>
          {PERIOD_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
        </SelectContent>
      </Select>
      {period === "personnalise" && (
        <div className="grid grid-cols-2 gap-2">
          <Input
            type="number"
            min="1"
            placeholder="Nombre"
            value={customCount}
            onChange={(e) => onChange({ period, customCount: e.target.value, customUnit })}
          />
          <Select value={customUnit} onValueChange={(v) => onChange({ period, customCount, customUnit: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {CUSTOM_UNITS.map((u) => <SelectItem key={u.value} value={u.value}>{u.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}