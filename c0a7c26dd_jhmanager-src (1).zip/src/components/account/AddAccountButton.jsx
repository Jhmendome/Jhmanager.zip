import React, { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import SubscribeDialog from "@/components/onboarding/SubscribeDialog";

const PLANS = {
  particulier: { type: "particulier", label: "Compte Particulier", baseAmount: 5000 },
  entreprise: { type: "entreprise", label: "Compte Entreprise", unitPrice: 20000 },
};

export default function AddAccountButton({ label = "Ajouter un compte" }) {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState("particulier");
  const [plan, setPlan] = useState(null);

  return (
    <>
      <Button variant="outline" onClick={() => setOpen(true)} className="no-select-tap">
        <Plus className="w-4 h-4 mr-2" /> {label}
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display">Ajouter un compte</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Label>Type de compte (nouvel abonnement)</Label>
            <RadioGroup value={type} onValueChange={setType}>
              <div className="flex items-center gap-2 border border-border rounded-lg p-3">
                <RadioGroupItem value="particulier" id="add-p" />
                <label htmlFor="add-p" className="text-sm">Particulier (JPM) — 5 000 XAF</label>
              </div>
              <div className="flex items-center gap-2 border border-border rounded-lg p-3">
                <RadioGroupItem value="entreprise" id="add-e" />
                <label htmlFor="add-e" className="text-sm">Entreprise (JBM) — 20 000 XAF / entreprise</label>
              </div>
            </RadioGroup>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Annuler</Button>
            <Button onClick={() => { setPlan(PLANS[type]); setOpen(false); }}>Continuer vers le paiement</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SubscribeDialog
        plan={plan}
        open={!!plan}
        onOpenChange={(o) => !o && setPlan(null)}
        onSuccess={() => { setPlan(null); window.location.reload(); }}
      />
    </>
  );
}