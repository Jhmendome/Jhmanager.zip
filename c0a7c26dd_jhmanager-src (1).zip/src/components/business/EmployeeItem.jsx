import React, { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const PERIOD_LABEL = {
  jour: "jour", semaine: "sem.", mois: "mois", trimestre: "trim.", semestre: "semest.", annee: "an",
};

export default function EmployeeItem({ employee, currency, onEdit, onDelete }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const per = PERIOD_LABEL[employee.salary_periodicity] || "mois";
  const headcount = Number(employee.headcount) || 1;

  return (
    <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="text-sm font-medium truncate">{employee.full_name}</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          {employee.role || "—"} · {headcount > 1 ? `${headcount} pers. · ` : ""}{formatCurrency(employee.salary, currency)}/{per}
        </p>
        {Number(employee.bonus) > 0 && (
          <p className="text-xs text-primary mt-0.5">
            Prime : {formatCurrency(employee.bonus, currency)}{employee.bonus_type === "periodique" ? `/${PERIOD_LABEL[employee.bonus_periodicity] || "mois"}` : " (ponctuelle)"}
          </p>
        )}
        {employee.hire_date && (
          <p className="text-xs text-muted-foreground">{t("jbm.employee.hireDate")}: {formatDateFr(employee.hire_date)}</p>
        )}
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <span className={`text-xs px-2 py-0.5 rounded-full ${employee.status === "actif" ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"}`}>
          {employee.status === "actif" ? t("jbm.employee.statusActive") : t("jbm.employee.statusInactive")}
        </span>
        <button onClick={() => onEdit(employee)} aria-label={t("taskitem.editAria")} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary">
          <Pencil className="w-4 h-4" />
        </button>
        <button onClick={() => setOpen(true)} aria-label={t("taskitem.deleteAria")} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("jbm.employee.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("jbm.employee.deleteDesc", { name: employee.full_name })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); onDelete(employee); setOpen(false); }}>
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}