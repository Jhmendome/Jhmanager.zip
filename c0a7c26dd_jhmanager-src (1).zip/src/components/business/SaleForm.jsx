import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useI18n } from "@/lib/i18n";
import { base44 } from "@/api/base44Client";
import { evalExpr, computeGrandeurs, formatNumber } from "@/lib/mathEval";
import { loadMetrics } from "@/lib/calcSources";
import CategorySelect from "@/components/categories/CategorySelect";
import { useSpace } from "@/lib/SpaceContext";

const empty = { customer_name: "", item_name: "", quantity: "1", unit_price: "0", date: "", status: "payee", category: "", use_formula: false, base_price: "0", pricing_formula: "", scheduled: false };

export default function SaleForm({ open, onOpenChange, sale, onSubmit }) {
  const { t } = useI18n();
  const { activeCompanyId } = useSpace();
  const [form, setForm] = useState(empty);
  const [repeat, setRepeat] = useState(false);
  const [frequency, setFrequency] = useState("mois");
  const [repeatCount, setRepeatCount] = useState("1");
  const [error, setError] = useState("");
  const [grandeurs, setGrandeurs] = useState([]);
  const [metrics, setMetrics] = useState({});

  useEffect(() => {
    if (sale) {
      setForm({
        customer_name: sale.customer_name || "",
        item_name: sale.item_name || "",
        quantity: String(sale.quantity ?? 1),
        unit_price: String(sale.unit_price ?? 0),
        date: sale.date || "",
        status: sale.status || "payee",
        category: sale.category || "",
        use_formula: !!sale.pricing_formula,
        base_price: String(sale.base_price ?? 0),
        pricing_formula: sale.pricing_formula || "",
        scheduled: sale.scheduled || sale.status === "en_attente",
      });
    } else {
      setForm({ ...empty, date: new Date().toISOString().slice(0, 10) });
    }
    setRepeat(false);
    setFrequency("mois");
    setRepeatCount("1");
    setError("");
  }, [sale, open]);

  useEffect(() => {
    if (!open) return;
    (async () => {
      try {
        const list = await base44.entities.CalcDefinition.list("-created_date", 200);
        setGrandeurs((list || []).filter((i) => i.kind === "grandeur"));
      } catch { /* ignore */ }
      try { setMetrics(await loadMetrics(activeCompanyId)); } catch { /* ignore */ }
    })();
  }, [open, activeCompanyId]);

  const scope = computeGrandeurs(grandeurs, metrics);
  const previewPrice = (() => {
    if (!form.use_formula || !form.pricing_formula.trim()) return null;
    try {
      const v = evalExpr(form.pricing_formula, { ...scope, qte: parseFloat(form.quantity) || 0, base: parseFloat(form.base_price) || 0 });
      return isFinite(v) ? v : null;
    } catch { return null; }
  })();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.item_name.trim() || !form.date) {
      setError(t("jbm.err.saleFields"));
      return;
    }
    const qte = parseFloat(form.quantity) || 1;
    let unit_price = parseFloat(form.unit_price) || 0;
    let pricing_formula = null;
    let base_price = null;
    if (form.use_formula && form.pricing_formula.trim()) {
      try {
        const v = evalExpr(form.pricing_formula, { ...scope, qte, base: parseFloat(form.base_price) || 0 });
        if (!isFinite(v)) { setError("Formule invalide"); return; }
        unit_price = v;
        pricing_formula = form.pricing_formula.trim();
        base_price = parseFloat(form.base_price) || 0;
      } catch (err) {
        setError("Formule invalide : " + err.message);
        return;
      }
    }
    const scheduled = form.scheduled;
    onSubmit({
      customer_name: form.customer_name.trim(),
      item_name: form.item_name.trim(),
      quantity: qte,
      unit_price,
      base_price,
      pricing_formula,
      scheduled,
      date: form.date,
      status: scheduled ? "en_attente" : form.status,
      category: form.category.trim(),
    }, repeat && !sale && parseInt(repeatCount, 10) > 1 ? { frequency, count: parseInt(repeatCount, 10) } : null);
  };

  const grandeurNames = grandeurs.map((g) => g.name).join(", ");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display">{sale ? t("jbm.sale.edit") : t("jbm.sale.new")}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>{t("jbm.sale.item")}</Label>
            <Input value={form.item_name} onChange={(e) => setForm({ ...form, item_name: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>{t("jbm.sale.customer")}</Label>
            <Input value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>Catégorie</Label>
            <CategorySelect scope="jbm" domain="vente" companyId={activeCompanyId} value={form.category} onChange={(v) => setForm({ ...form, category: v })} placeholder="Catégorie" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.sale.quantity")}</Label>
              <Input type="number" min="1" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>{t("jbm.sale.status")}</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="payee">{t("jbm.sale.statusPayee")}</SelectItem>
                  <SelectItem value="en_attente">{t("jbm.sale.statusPending")}</SelectItem>
                  <SelectItem value="annulee">{t("jbm.sale.statusCancelled")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="rounded-xl border border-border p-3 space-y-3">
            <div className="flex items-center gap-2">
              <Checkbox checked={form.use_formula} onCheckedChange={(v) => setForm({ ...form, use_formula: !!v })} id="sale-formula" />
              <Label htmlFor="sale-formula">Tarification par formule</Label>
            </div>
            {form.use_formula && (
              <div className="space-y-3">
                <p className="text-xs text-muted-foreground">
                  Variables : <span className="font-mono">qte</span> (quantité), <span className="font-mono">base</span> (prix de base)
                  {grandeurs.length > 0 && <span>, et vos grandeurs : {grandeurNames}</span>}.
                </p>
                <div className="space-y-2">
                  <Label>Prix de base (base)</Label>
                  <Input type="number" min="0" step="any" value={form.base_price} onChange={(e) => setForm({ ...form, base_price: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Formule du prix unitaire</Label>
                  <Input value={form.pricing_formula} onChange={(e) => setForm({ ...form, pricing_formula: e.target.value })} placeholder="base + qte * 100" />
                </div>
                <div className="bg-secondary rounded-lg p-2 text-sm">
                  Prix unitaire calculé : <span className="font-medium">{previewPrice != null ? formatNumber(previewPrice) : "—"}</span>
                </div>
              </div>
            )}
          </div>

          {!form.use_formula && (
            <div className="space-y-2">
              <Label>{t("jbm.sale.unitPrice")}</Label>
              <Input type="number" min="0" step="any" value={form.unit_price} onChange={(e) => setForm({ ...form, unit_price: e.target.value })} />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.sale.date")}</Label>
              <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Programmer</Label>
              <div className="flex items-center gap-2 h-9">
                <Checkbox checked={form.scheduled} onCheckedChange={(v) => setForm({ ...form, scheduled: !!v })} id="sale-sched" />
                <Label htmlFor="sale-sched" className="text-sm font-normal">Vente programmée (rappel J-1 et J)</Label>
              </div>
            </div>
          </div>

          {!sale && (
            <div className="space-y-3 rounded-xl border border-border p-3">
              <div className="flex items-center gap-2">
                <Checkbox checked={repeat} onCheckedChange={setRepeat} id="sale-repeat" />
                <Label htmlFor="sale-repeat">Répéter périodiquement</Label>
              </div>
              {repeat && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="sale-freq" className="text-xs">Fréquence</Label>
                    <Select value={frequency} onValueChange={setFrequency}>
                      <SelectTrigger id="sale-freq"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="jour">Jour</SelectItem>
                        <SelectItem value="semaine">Semaine</SelectItem>
                        <SelectItem value="trimestre">Trimestre</SelectItem>
                        <SelectItem value="mois">Mois</SelectItem>
                        <SelectItem value="annee">Année</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="sale-count" className="text-xs">Nombre d'échéances</Label>
                    <Input id="sale-count" type="number" min="1" max="120" value={repeatCount} onChange={(e) => setRepeatCount(e.target.value)} />
                  </div>
                </div>
              )}
            </div>
          )}
          {error && <p className="text-sm text-destructive">{error}</p>}
          <DialogFooter>
            <Button type="submit" className="w-full">{t("common.save")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}