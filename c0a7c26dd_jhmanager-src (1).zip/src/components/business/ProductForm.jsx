import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import CategorySelect from "@/components/categories/CategorySelect";
import { useSpace } from "@/lib/SpaceContext";
import { useI18n } from "@/lib/i18n";

const empty = { name: "", sku: "", category: "", quantity: "0", unit_cost: "0", sale_price: "0", reorder_level: "0" };

export default function ProductForm({ open, onOpenChange, product, onSubmit }) {
  const { t } = useI18n();
  const { activeCompanyId } = useSpace();
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");

  useEffect(() => {
    if (product) {
      setForm({
        name: product.name || "",
        sku: product.sku || "",
        category: product.category || "",
        quantity: String(product.quantity ?? 0),
        unit_cost: String(product.unit_cost ?? 0),
        sale_price: String(product.sale_price ?? 0),
        reorder_level: String(product.reorder_level ?? 0),
      });
    } else {
      setForm(empty);
    }
    setError("");
  }, [product, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setError(t("jbm.err.name"));
      return;
    }
    onSubmit({
      name: form.name.trim(),
      sku: form.sku.trim(),
      category: form.category.trim(),
      quantity: parseFloat(form.quantity) || 0,
      unit_cost: parseFloat(form.unit_cost) || 0,
      sale_price: parseFloat(form.sale_price) || 0,
      reorder_level: parseFloat(form.reorder_level) || 0,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">{product ? t("jbm.product.edit") : t("jbm.product.new")}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>{t("jbm.product.name")}</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.product.sku")}</Label>
              <Input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>{t("jbm.product.category")}</Label>
              <CategorySelect scope="jbm" domain="produit" companyId={activeCompanyId} value={form.category} onChange={(v) => setForm({ ...form, category: v })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.product.quantity")}</Label>
              <Input type="number" min="0" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>{t("jbm.product.reorder")}</Label>
              <Input type="number" min="0" value={form.reorder_level} onChange={(e) => setForm({ ...form, reorder_level: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.product.unitCost")}</Label>
              <Input type="number" min="0" step="any" value={form.unit_cost} onChange={(e) => setForm({ ...form, unit_cost: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>{t("jbm.product.salePrice")}</Label>
              <Input type="number" min="0" step="any" value={form.sale_price} onChange={(e) => setForm({ ...form, sale_price: e.target.value })} />
            </div>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <DialogFooter>
            <Button type="submit" className="w-full">{t("common.save")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}