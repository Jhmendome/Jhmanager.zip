import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useI18n } from "@/lib/i18n";

const empty = { number: "", customer_name: "", amount: "0", issue_date: "", due_date: "", status: "brouillon" };

export default function InvoiceForm({ open, onOpenChange, invoice, onSubmit, nextNumber }) {
  const { t } = useI18n();
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");

  useEffect(() => {
    if (invoice) {
      setForm({
        number: invoice.number || "",
        customer_name: invoice.customer_name || "",
        amount: String(invoice.amount ?? 0),
        issue_date: invoice.issue_date || "",
        due_date: invoice.due_date || "",
        status: invoice.status || "brouillon",
      });
    } else {
      setForm({
        ...empty,
        number: nextNumber || "",
        issue_date: new Date().toISOString().slice(0, 10),
      });
    }
    setError("");
  }, [invoice, open, nextNumber]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.number.trim() || !form.customer_name.trim() || !form.issue_date) {
      setError(t("jbm.err.invoiceFields"));
      return;
    }
    onSubmit({
      number: form.number.trim(),
      customer_name: form.customer_name.trim(),
      amount: parseFloat(form.amount) || 0,
      issue_date: form.issue_date,
      due_date: form.due_date,
      status: form.status,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">{invoice ? t("jbm.invoice.edit") : t("jbm.invoice.new")}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.invoice.number")}</Label>
              <Input value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>{t("jbm.invoice.amount")}</Label>
              <Input type="number" min="0" step="any" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>{t("jbm.invoice.customer")}</Label>
            <Input value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.invoice.issueDate")}</Label>
              <Input type="date" value={form.issue_date} onChange={(e) => setForm({ ...form, issue_date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>{t("jbm.invoice.dueDate")}</Label>
              <Input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>{t("jbm.invoice.status")}</Label>
            <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="brouillon">{t("jbm.invoice.statusDraft")}</SelectItem>
                <SelectItem value="envoyee">{t("jbm.invoice.statusSent")}</SelectItem>
                <SelectItem value="payee">{t("jbm.invoice.statusPaid")}</SelectItem>
                <SelectItem value="en_retard">{t("jbm.invoice.statusLate")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <DialogFooter>
            <Button type="submit" className="w-full">{t("common.save")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}