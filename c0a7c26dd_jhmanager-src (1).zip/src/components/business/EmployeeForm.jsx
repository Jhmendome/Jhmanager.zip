import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useI18n } from "@/lib/i18n";

const PERIODS = [
  { value: "jour", label: "Journalier" },
  { value: "semaine", label: "Hebdomadaire" },
  { value: "mois", label: "Mensuel" },
  { value: "trimestre", label: "Trimestriel" },
  { value: "semestre", label: "Semestriel" },
  { value: "annee", label: "Annuel" },
];

const empty = {
  full_name: "", role: "", headcount: "1", salary: "0", salary_periodicity: "mois",
  bonus: "0", bonus_type: "ponctuel", bonus_periodicity: "mois",
  phone: "", email: "", hire_date: "", status: "actif",
};

export default function EmployeeForm({ open, onOpenChange, employee, onSubmit }) {
  const { t } = useI18n();
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");

  useEffect(() => {
    if (employee) {
      setForm({
        full_name: employee.full_name || "",
        role: employee.role || "",
        headcount: String(employee.headcount ?? 1),
        salary: String(employee.salary ?? 0),
        salary_periodicity: employee.salary_periodicity || "mois",
        bonus: String(employee.bonus ?? 0),
        bonus_type: employee.bonus_type || "ponctuel",
        bonus_periodicity: employee.bonus_periodicity || "mois",
        phone: employee.phone || "",
        email: employee.email || "",
        hire_date: employee.hire_date || "",
        status: employee.status || "actif",
      });
    } else {
      setForm({ ...empty, hire_date: new Date().toISOString().slice(0, 10) });
    }
    setError("");
  }, [employee, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.full_name.trim()) {
      setError(t("jbm.err.name"));
      return;
    }
    onSubmit({
      full_name: form.full_name.trim(),
      role: form.role.trim(),
      headcount: parseInt(form.headcount, 10) || 1,
      salary: parseFloat(form.salary) || 0,
      salary_periodicity: form.salary_periodicity,
      bonus: parseFloat(form.bonus) || 0,
      bonus_type: form.bonus_type,
      bonus_periodicity: form.bonus_type === "periodique" ? form.bonus_periodicity : null,
      phone: form.phone.trim(),
      email: form.email.trim(),
      hire_date: form.hire_date,
      status: form.status,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">{employee ? t("jbm.employee.edit") : t("jbm.employee.new")}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>{t("jbm.employee.name")}</Label>
            <Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.employee.role")}</Label>
              <Input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Nombre à ce poste</Label>
              <Input type="number" min="1" value={form.headcount} onChange={(e) => setForm({ ...form, headcount: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.employee.salary")}</Label>
              <Input type="number" min="0" step="any" value={form.salary} onChange={(e) => setForm({ ...form, salary: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Périodicité du salaire</Label>
              <Select value={form.salary_periodicity} onValueChange={(v) => setForm({ ...form, salary_periodicity: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PERIODS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Prime</Label>
              <Input type="number" min="0" step="any" value={form.bonus} onChange={(e) => setForm({ ...form, bonus: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Type de prime</Label>
              <Select value={form.bonus_type} onValueChange={(v) => setForm({ ...form, bonus_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ponctuel">Ponctuelle</SelectItem>
                  <SelectItem value="periodique">Périodique</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          {form.bonus_type === "periodique" && (
            <div className="space-y-2">
              <Label>Périodicité de la prime</Label>
              <Select value={form.bonus_periodicity} onValueChange={(v) => setForm({ ...form, bonus_periodicity: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PERIODS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.employee.hireDate")}</Label>
              <Input type="date" value={form.hire_date} onChange={(e) => setForm({ ...form, hire_date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>{t("jbm.employee.status")}</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="actif">{t("jbm.employee.statusActive")}</SelectItem>
                  <SelectItem value="inactif">{t("jbm.employee.statusInactive")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>{t("jbm.employee.phone")}</Label>
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>{t("jbm.employee.email")}</Label>
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <DialogFooter>
            <Button type="submit" className="w-full">{t("common.save")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}