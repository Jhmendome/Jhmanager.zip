import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { formatDateFr } from "@/lib/format";

const TYPE_LABEL = {
  presence: "Présence", absence: "Absence", retard: "Retard", conge: "Congé", discipline: "Discipline",
};
const SEV_LABEL = { info: "Info", avertissement: "Avertissement", sanction: "Sanction" };
const SEV_STYLE = {
  info: "bg-secondary text-muted-foreground",
  avertissement: "bg-accent/15 text-accent-foreground",
  sanction: "bg-destructive/10 text-destructive",
};

const empty = { employee_id: "", type: "presence", date: "", note: "", severity: "info" };

export default function AttendancePanel({ companyId, employees }) {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const { toast } = useToast();

  const load = async () => {
    try {
      const list = await base44.entities.AttendanceRecord.list("-date", 500);
      setRecords(list || []);
    } catch { setRecords([]); }
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const mine = companyId ? records.filter((r) => r.company_id === companyId) : records;

  const empName = (id) => employees.find((e) => e.id === id)?.full_name || "—";

  const submit = async (e) => {
    e.preventDefault();
    if (!form.employee_id || !form.date) { toast({ title: "Employé et date requis", variant: "destructive" }); return; }
    const payload = {
      ...form,
      company_id: companyId,
      employee_name: empName(form.employee_id),
    };
    try {
      await base44.entities.AttendanceRecord.create(payload);
      toast({ title: "Enregistrement ajouté" });
      setOpen(false);
      setForm(empty);
      load();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const remove = async (r) => {
    try { await base44.entities.AttendanceRecord.delete(r.id); setRecords((c) => c.filter((x) => x.id !== r.id)); }
    catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  if (loading) return <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">Présences, absences, retards et comportements des employés.</p>
        <Button onClick={() => { setForm({ ...empty, date: new Date().toISOString().slice(0, 10) }); setOpen(true); }}>
          <Plus className="w-4 h-4 mr-2" /> Enregistrer
        </Button>
      </div>

      {mine.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">
          <CalendarDays className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">Aucun enregistrement.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {mine.map((r) => (
            <div key={r.id} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{r.employee_name || empName(r.employee_id)}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {TYPE_LABEL[r.type] || r.type} · {formatDateFr(r.date)}
                  {r.note && ` · ${r.note}`}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {r.type === "discipline" && (
                  <span className={`text-xs px-2 py-0.5 rounded-full ${SEV_STYLE[r.severity] || SEV_STYLE.info}`}>
                    {SEV_LABEL[r.severity] || r.severity}
                  </span>
                )}
                <button onClick={() => remove(r)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader><DialogTitle className="font-display">Absence & discipline</DialogTitle></DialogHeader>
          <form onSubmit={submit} className="space-y-3">
            <div className="space-y-2">
              <Label>Employé</Label>
              <Select value={form.employee_id} onValueChange={(v) => setForm({ ...form, employee_id: v })}>
                <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                <SelectContent>
                  {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.full_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(TYPE_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
              </div>
            </div>
            {form.type === "discipline" && (
              <div className="space-y-2">
                <Label>Gravité</Label>
                <Select value={form.severity} onValueChange={(v) => setForm({ ...form, severity: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(SEV_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="space-y-2">
              <Label>Note / comportement</Label>
              <Textarea rows={2} value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
            </div>
            <DialogFooter><Button type="submit" className="w-full">Enregistrer</Button></DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}