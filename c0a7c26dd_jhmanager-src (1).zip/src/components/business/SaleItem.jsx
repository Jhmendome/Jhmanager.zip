import React, { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const STATUS_KEY = { payee: "jbm.sale.statusPayee", en_attente: "jbm.sale.statusPending", annulee: "jbm.sale.statusCancelled" };

export default function SaleItem({ sale, currency, onEdit, onDelete }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const total = (Number(sale.quantity) || 0) * (Number(sale.unit_price) || 0);

  return (
    <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="text-sm font-medium truncate">{sale.item_name}</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          {sale.customer_name || "—"} · {formatDateFr(sale.date)}
          {sale.scheduled && <span className="ml-1.5 text-accent">· Programmée</span>}
        </p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <div className="text-right mr-1">
          <p className="text-sm font-medium">{formatCurrency(total, currency)}</p>
          <span className="text-xs px-2 py-0.5 rounded-full bg-secondary text-secondary-foreground">{t(STATUS_KEY[sale.status] || "common.other")}</span>
        </div>
        <button onClick={() => onEdit(sale)} aria-label={t("taskitem.editAria")} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary">
          <Pencil className="w-4 h-4" />
        </button>
        <button onClick={() => setOpen(true)} aria-label={t("taskitem.deleteAria")} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("jbm.sale.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("jbm.sale.deleteDesc", { name: sale.item_name })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); onDelete(sale); setOpen(false); }}>
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}