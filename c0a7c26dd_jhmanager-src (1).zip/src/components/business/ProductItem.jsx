import React, { useState } from "react";
import { Pencil, Trash2, AlertTriangle } from "lucide-react";
import { formatCurrency } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ProductItem({ product, currency, onEdit, onDelete }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const low = (Number(product.quantity) || 0) <= (Number(product.reorder_level) || 0);

  return (
    <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          <p className="text-sm font-medium truncate">{product.name}</p>
          {low && Number(product.reorder_level) > 0 && (
            <span className="text-xs px-2 py-0.5 rounded-full bg-destructive/10 text-destructive flex items-center gap-1 shrink-0">
              <AlertTriangle className="w-3 h-3" /> {t("jbm.product.low")}
            </span>
          )}
        </div>
        <p className="text-xs text-muted-foreground mt-0.5">
          {product.sku ? `${product.sku} · ` : ""}{product.category || t("common.other")} · {t("jbm.product.stock")}: {product.quantity}
        </p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <div className="text-right mr-1">
          <p className="text-sm font-medium">{formatCurrency(product.sale_price, currency)}</p>
          <p className="text-xs text-muted-foreground">{formatCurrency(product.unit_cost, currency)}</p>
        </div>
        <button onClick={() => onEdit(product)} aria-label={t("taskitem.editAria")} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary">
          <Pencil className="w-4 h-4" />
        </button>
        <button onClick={() => setOpen(true)} aria-label={t("taskitem.deleteAria")} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("jbm.product.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("jbm.product.deleteDesc", { name: product.name })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); onDelete(product); setOpen(false); }}>
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}