import React, { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const STATUS_KEY = {
  brouillon: "jbm.invoice.statusDraft",
  envoyee: "jbm.invoice.statusSent",
  payee: "jbm.invoice.statusPaid",
  en_retard: "jbm.invoice.statusLate",
};

export default function InvoiceItem({ invoice, currency, onEdit, onDelete }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const tone =
    invoice.status === "payee" ? "bg-primary/10 text-primary"
      : invoice.status === "en_retard" ? "bg-destructive/10 text-destructive"
      : "bg-secondary text-secondary-foreground";

  return (
    <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="text-sm font-medium truncate">{invoice.number} · {invoice.customer_name}</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          {formatDateFr(invoice.issue_date)}{invoice.due_date ? ` → ${formatDateFr(invoice.due_date)}` : ""}
        </p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <div className="text-right mr-1">
          <p className="text-sm font-medium">{formatCurrency(invoice.amount, currency)}</p>
          <span className={`text-xs px-2 py-0.5 rounded-full ${tone}`}>{t(STATUS_KEY[invoice.status] || "common.other")}</span>
        </div>
        <button onClick={() => onEdit(invoice)} aria-label={t("taskitem.editAria")} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary">
          <Pencil className="w-4 h-4" />
        </button>
        <button onClick={() => setOpen(true)} aria-label={t("taskitem.deleteAria")} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      <AlertDialog open={open} onOpenChange={setOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("jbm.invoice.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("jbm.invoice.deleteDesc", { number: invoice.number })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); onDelete(invoice); setOpen(false); }}>
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}