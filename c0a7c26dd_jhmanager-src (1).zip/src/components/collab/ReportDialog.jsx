import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, Flag } from "lucide-react";

const REASONS = [
  ["spam", "Spam ou pub non sollicitée"],
  ["harcelement", "Harcèlement"],
  ["contenu_inapproprie", "Contenu inapproprié"],
  ["arnaque", "Arnaque / fraude"],
  ["usurpation", "Usurpation d'identité"],
  ["autre", "Autre"],
];

export default function ReportDialog({ open, onOpenChange, target }) {
  const { toast } = useToast();
  const [reason, setReason] = useState("spam");
  const [custom, setCustom] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) { setReason("spam"); setCustom(""); }
  }, [open]);

  const submit = async () => {
    if (!target) return;
    setBusy(true);
    try {
      await base44.entities.Report.create({
        target_type: target.type,
        target_id: target.id,
        target_name: target.name || "",
        reason,
        custom_reason: custom.trim(),
      });
      toast({ title: "Signalement envoyé", description: "Les administrateurs ont été notifiés." });
      onOpenChange?.(false);
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Flag className="w-4 h-4 text-accent" /> Signaler</DialogTitle>
          <DialogDescription>
            {target?.type === "group" ? "Signaler le groupe" : "Signaler l'abonné"} « {target?.name || ""} ». Les administrateurs examineront votre signalement.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label className="text-xs">Raison</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                {REASONS.map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Précisions (optionnel)</Label>
            <Textarea
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="Décrivez ce qui s'est passé…"
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange?.(false)}>Annuler</Button>
          <Button onClick={submit} disabled={busy}>
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : "Envoyer le signalement"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}