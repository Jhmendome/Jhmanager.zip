import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { UserPlus, Loader2, Building2, MapPin } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { BUSINESS_TYPES } from "@/lib/businessTypes";

export default function CompanySearch({ currentUserId, excludeIds = [], onSent }) {
  const [typeTerm, setTypeTerm] = useState("");
  const [locTerm, setLocTerm] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    const term = typeTerm.trim().toLowerCase();
    const loc = locTerm.trim().toLowerCase();
    const hasTerm = term.length >= 2 || loc.length >= 2;
    if (!hasTerm) { setResults([]); return; }
    let cancelled = false;
    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const list = await base44.entities.Company.list("-created_date", 500);
        if (cancelled) return;
        const matched = (list || []).filter((c) => {
          const bt = (c.business_type || "").toLowerCase();
          const lo = (c.location || "").toLowerCase();
          const typeOk = term.length >= 2 ? bt.includes(term) : true;
          const locOk = loc.length >= 2 ? lo.includes(loc) : true;
          return typeOk && locOk;
        });
        setResults(matched);
      } catch {
        if (!cancelled) setResults([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 300);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [typeTerm, locTerm]);

  const sendRequest = async (c) => {
    setSending(c.id);
    try {
      await base44.entities.CollaborationRequest.create({
        to_user_id: c.created_by_id,
        to_name: c.name,
        status: "pending",
      });
      toast({ title: "Demande envoyée", description: c.name });
      onSent?.();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message || "Échec de l'envoi", variant: "destructive" });
    } finally {
      setSending(null);
    }
  };

  const hasSearched = typeTerm.trim().length >= 2 || locTerm.trim().length >= 2;

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <Input
          list="business-types-list"
          value={typeTerm}
          onChange={(e) => setTypeTerm(e.target.value)}
          placeholder="Type d'entreprise (ex: Restauration)"
        />
        <Input
          value={locTerm}
          onChange={(e) => setLocTerm(e.target.value)}
          placeholder="Lieu (optionnel)"
        />
        <datalist id="business-types-list">
          {BUSINESS_TYPES.map((bt) => <option key={bt} value={bt} />)}
        </datalist>
      </div>

      {loading && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="w-3.5 h-3.5 animate-spin" /> Recherche…
        </div>
      )}

      {!loading && hasSearched && results.length === 0 && (
        <p className="text-xs text-muted-foreground text-center py-2">Aucune entreprise trouvée.</p>
      )}

      {results.length > 0 && (
        <div className="space-y-2">
          {results.map((c) => {
            const isSelf = c.created_by_id === currentUserId;
            const excluded = excludeIds.includes(c.created_by_id);
            return (
              <div key={c.id} className="flex items-center justify-between gap-2 bg-card border border-border rounded-xl p-2.5">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-accent shrink-0" /> {c.name}
                  </p>
                  <p className="text-xs text-muted-foreground flex items-center gap-2 truncate">
                    <span>{c.business_type || "—"}</span>
                    {c.location && (
                      <span className="flex items-center gap-0.5">
                        <MapPin className="w-3 h-3" /> {c.location}
                      </span>
                    )}
                  </p>
                </div>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  disabled={isSelf || excluded || sending === c.id}
                  onClick={() => sendRequest(c)}
                  className="flex items-center gap-1 shrink-0"
                >
                  {sending === c.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <UserPlus className="w-3.5 h-3.5" />}
                  {isSelf ? "Vous" : excluded ? "Collaborateur" : "Collaboration"}
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}