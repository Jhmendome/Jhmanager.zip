import React, { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Paperclip, Loader2 } from "lucide-react";
import { Image } from "@/components/ui/image";
import { canWriteInGroup, canSendMediaInGroup } from "@/lib/collabUtils";
import { useToast } from "@/components/ui/use-toast";

const IMAGE_EXT = /\.(png|jpe?g|gif|webp)$/i;

export default function ChatView({ conversationType, conversationId, participants, group, currentUserId }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const fileRef = useRef(null);
  const scrollRef = useRef(null);
  const { toast } = useToast();

  const canWrite = conversationType === "direct" ? true : canWriteInGroup(currentUserId, group);
  const canMedia = conversationType === "direct" ? true : canSendMediaInGroup(currentUserId, group);

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.Message.filter({ conversation_id: conversationId }, "-created_date", 200);
      setMessages((list || []).reverse());
    } catch {
      setMessages([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const unsubscribe = base44.entities.Message.subscribe((event) => {
      if (event.data?.conversation_id !== conversationId) return;
      setMessages((prev) => {
        if (event.type === "create" && !prev.find((m) => m.id === event.data.id)) return [...prev, event.data];
        if (event.type === "delete") return prev.filter((m) => m.id !== event.data.id);
        return prev;
      });
    });
    return unsubscribe;
  }, [conversationId]);

  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current?.scrollHeight, behavior: "smooth" }); }, [messages]);

  const send = async (e) => {
    e?.preventDefault();
    const content = text.trim();
    if (!content || sending) return;
    setSending(true);
    try {
      await base44.entities.Message.create({
        conversation_type: conversationType,
        conversation_id: conversationId,
        participants,
        content,
      });
      setText("");
    } catch (err) {
      toast({ title: "Erreur", description: err?.message, variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || !canMedia || sending) return;
    setSending(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      await base44.entities.Message.create({
        conversation_type: conversationType,
        conversation_id: conversationId,
        participants,
        content: "",
        attachment_url: file_url,
        attachment_name: file.name,
      });
    } catch (err) {
      toast({ title: "Erreur", description: err?.message, variant: "destructive" });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col h-[60vh] border border-border rounded-2xl bg-card">
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2">
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
        ) : messages.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-8">Aucun message. Démarrez la conversation.</p>
        ) : messages.map((m) => {
          const mine = m.created_by_id === currentUserId;
          const isImg = m.attachment_url && IMAGE_EXT.test(m.attachment_url);
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[78%] rounded-2xl px-3 py-2 text-sm ${mine ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                <p className="text-[10px] opacity-70 mb-0.5">{m.created_by || ""}</p>
                {m.content && <p className="whitespace-pre-wrap break-words">{m.content}</p>}
                {m.attachment_url && (isImg ? (
                  <Image src={m.attachment_url} alt={m.attachment_name || ""} className="mt-1 rounded-lg max-h-48 w-auto max-w-full object-cover" />
                ) : (
                  <a href={m.attachment_url} target="_blank" rel="noreferrer" className="block mt-1 underline text-xs">{m.attachment_name || "Fichier"}</a>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      {!canWrite ? (
        <div className="p-3 text-center text-xs text-muted-foreground border-t border-border">
          L'écriture est réservée aux administrateurs / membres autorisés.
        </div>
      ) : (
        <form onSubmit={send} className="flex items-center gap-2 p-2 border-t border-border">
          <input ref={fileRef} type="file" className="hidden" onChange={onFile} accept="image/*,application/pdf,.doc,.docx,.txt" />
          <Button type="button" size="icon" variant="ghost" onClick={() => fileRef.current?.click()} disabled={!canMedia || sending} title={canMedia ? "Joindre un fichier" : "Médias restreints"}>
            <Paperclip className="w-4 h-4" />
          </Button>
          <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Écrire un message…" />
          <Button type="submit" size="icon" disabled={sending || !text.trim()}>
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </form>
      )}
    </div>
  );
}