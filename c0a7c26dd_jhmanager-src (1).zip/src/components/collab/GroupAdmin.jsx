import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, X, Crown, ShieldCheck, ShieldOff, Pencil, ImageIcon, Trash2, LogOut, UserPlus } from "lucide-react";
import { isGroupAdmin, isGroupCreator } from "@/lib/collabUtils";
import { useToast } from "@/components/ui/use-toast";

export default function GroupAdmin({ group, currentUserId, nameMap, onChanged }) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState([]);
  const { toast } = useToast();
  const admin = isGroupAdmin(currentUserId, group);
  const creator = isGroupCreator(currentUserId, group);

  const update = async (patch) => {
    try {
      await base44.entities.Group.update(group.id, patch);
      onChanged?.();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    }
  };

  const removeMember = async (uid) => {
    try {
      await base44.functions.invoke('manageGroup', { action: "remove_member", group_id: group.id, target_id: uid });
      onChanged?.();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    }
  };

  const toggleAdmin = (uid) => {
    if (uid === group.created_by_id) return;
    const admins = group.admins || [];
    update({ admins: admins.includes(uid) ? admins.filter((a) => a !== uid) : [...admins, uid] });
  };

  const toggleAllowed = (uid, field) => {
    const arr = group[field] || [];
    update({ [field]: arr.includes(uid) ? arr.filter((a) => a !== uid) : [...arr, uid] });
  };

  const search = async () => {
    const term = q.trim();
    if (term.length < 2) { setResults([]); return; }
    const list = await base44.entities.Collaborator.list("-created_date", 200);
    const t = term.toLowerCase();
    setResults((list || []).filter(
      (c) => (c.display_name || "").toLowerCase().includes(t)
        && !(group.members || []).includes(c.created_by_id)
        && c.created_by_id !== currentUserId
    ));
  };

  const invite = async (c) => {
    try {
      await base44.entities.GroupInvite.create({
        group_id: group.id, group_name: group.name,
        to_user_id: c.created_by_id, to_name: c.display_name, status: "pending",
      });
      toast({ title: "Invitation envoyée", description: c.display_name });
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    }
  };

  const leave = async () => {
    await removeMember(currentUserId);
    onChanged?.();
  };

  const del = async () => {
    try { await base44.entities.Group.delete(group.id); onChanged?.(); }
    catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-display text-lg flex items-center gap-1.5">{group.name}</h3>
          <p className="text-xs text-muted-foreground">Créé par {nameMap[group.created_by_id] || group.created_by}</p>
        </div>
        {creator ? (
          <Button size="sm" variant="destructive" onClick={del} className="flex items-center gap-1"><Trash2 className="w-4 h-4" /> Supprimer</Button>
        ) : (
          <Button size="sm" variant="outline" onClick={leave} className="flex items-center gap-1"><LogOut className="w-4 h-4" /> Quitter</Button>
        )}
      </div>

      {admin && (
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant={group.write_restricted ? "default" : "outline"} onClick={() => update({ write_restricted: !group.write_restricted })} className="flex items-center gap-1">
            <Pencil className="w-4 h-4" /> Écriture restreinte
          </Button>
          <Button size="sm" variant={group.media_restricted ? "default" : "outline"} onClick={() => update({ media_restricted: !group.media_restricted })} className="flex items-center gap-1">
            <ImageIcon className="w-4 h-4" /> Médias restreints
          </Button>
        </div>
      )}

      <div className="space-y-2">
        <p className="text-xs font-medium text-muted-foreground">Membres ({(group.members || []).length})</p>
        {(group.members || []).map((uid) => {
          const isCreator = uid === group.created_by_id;
          const isAdmin = (group.admins || []).includes(uid) || isCreator;
          return (
            <div key={uid} className="flex items-center justify-between gap-2 bg-card border border-border rounded-xl p-2.5">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-sm font-medium truncate">{nameMap[uid] || uid}</span>
                {isCreator && <Crown className="w-3.5 h-3.5 text-accent shrink-0" />}
                {!isCreator && isAdmin && <ShieldCheck className="w-3.5 h-3.5 text-primary shrink-0" />}
              </div>
              {admin && !isCreator && (
                <div className="flex items-center gap-1">
                  {creator && (
                    <Button size="icon" variant="ghost" title={isAdmin ? "Retirer admin" : "Promouvoir admin"} onClick={() => toggleAdmin(uid)}>
                      {isAdmin ? <ShieldOff className="w-4 h-4" /> : <ShieldCheck className="w-4 h-4" />}
                    </Button>
                  )}
                  {group.write_restricted && (
                    <Button size="icon" variant={(group.allowed_writers||[]).includes(uid) ? "default" : "ghost"} title="Autorisé à écrire" onClick={() => toggleAllowed(uid, "allowed_writers")}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                  )}
                  {group.media_restricted && (
                    <Button size="icon" variant={(group.allowed_media||[]).includes(uid) ? "default" : "ghost"} title="Autorisé médias" onClick={() => toggleAllowed(uid, "allowed_media")}>
                      <ImageIcon className="w-4 h-4" />
                    </Button>
                  )}
                  <Button size="icon" variant="ghost" onClick={() => removeMember(uid)}><X className="w-4 h-4 text-destructive" /></Button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {admin && (
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground flex items-center gap-1"><UserPlus className="w-3.5 h-3.5" /> Inviter un membre</p>
          <div className="flex items-center gap-2">
            <Input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); search(); } }} placeholder="Rechercher un utilisateur…" />
            <Button size="icon" variant="outline" onClick={search}><Search className="w-4 h-4" /></Button>
          </div>
          {results.map((c) => (
            <div key={c.id} className="flex items-center justify-between bg-card border border-border rounded-xl p-2.5">
              <span className="text-sm font-medium truncate">{c.display_name}</span>
              <Button size="sm" variant="outline" onClick={() => invite(c)}>Inviter</Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}