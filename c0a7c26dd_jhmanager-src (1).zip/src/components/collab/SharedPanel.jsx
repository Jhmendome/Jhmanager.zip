import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ListChecks, Wallet, CalendarDays, Handshake, Plus, Trash2, Loader2, UsersRound } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { canWriteInGroup } from "@/lib/collabUtils";

const PERIODS = [
  { value: "jour", label: "Jour" },
  { value: "semaine", label: "Semaine" },
  { value: "trimestre", label: "Trimestre" },
  { value: "mois", label: "Mois" },
  { value: "annee", label: "Année" },
];

function fmtMoney(n) {
  if (n == null || isNaN(n)) return "-";
  return new Intl.NumberFormat("fr-FR").format(Number(n)) + " XAF";
}

function toLocalInput(d) {
  const dt = new Date(d);
  const pad = (x) => String(x).padStart(2, "0");
  return `${dt.getFullYear()}-${pad(dt.getMonth() + 1)}-${pad(dt.getDate())}T${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
}

function memberName(id, nameMap, fallback) {
  return nameMap?.[id] || (id === fallback ? "Vous" : (id || "").slice(-4));
}

export default function SharedPanel({ conversation, currentUserId, nameMap }) {
  const { toast } = useToast();
  const [domain, setDomain] = useState("taches");
  const [items, setItems] = useState({ taches: [], budget: [], evenements: [], partenariats: [] });
  const [loading, setLoading] = useState(false);
  const [showAdd, setShowAdd] = useState(false);

  const canManage =
    conversation?.type === "group"
      ? canWriteInGroup(currentUserId, conversation.group)
      : true;

  const participants = conversation?.participants || [];

  const loadDomain = async (d) => {
    const map = { taches: "Task", budget: "Expense", evenements: "Event", partenariats: "Partnership" };
    try {
      const list = await base44.entities[map[d]].filter({ shared_context_id: conversation.id });
      setItems((prev) => ({ ...prev, [d]: list || [] }));
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    }
  };

  useEffect(() => {
    if (!conversation) return;
    setLoading(true);
    Promise.all(["taches", "budget", "evenements", "partenariats"].map(loadDomain)).finally(() => setLoading(false));
    // eslint-disable-next-line
  }, [conversation?.id]);

  const remove = async (d, id) => {
    const map = { taches: "Task", budget: "Expense", evenements: "Event", partenariats: "Partnership" };
    if (!confirm("Supprimer cet élément partagé ?")) return;
    try {
      await base44.entities[map[d]].delete(id);
      setItems((prev) => ({ ...prev, [d]: prev[d].filter((x) => x.id !== id) }));
    } catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
  };

  const tabs = [
    { id: "taches", label: "Tâches", icon: ListChecks, count: items.taches.length },
    { id: "budget", label: "Budget", icon: Wallet, count: items.budget.length },
    { id: "evenements", label: "Événements", icon: CalendarDays, count: items.evenements.length },
    { id: "partenariats", label: "Partenariats", icon: Handshake, count: items.partenariats.length },
  ];

  return (
    <div className="bg-card border border-border rounded-2xl p-3 space-y-3">
      <div className="flex items-center gap-1.5 text-sm font-medium">
        <UsersRound className="w-4 h-4 text-accent" /> Espace partagé
        {!canManage && <span className="text-xs text-muted-foreground ml-auto">Lecture seule</span>}
      </div>

      <div className="flex gap-1 overflow-x-auto no-scrollbar">
        {tabs.map((t) => (
          <button key={t.id} onClick={() => setDomain(t.id)}
            className={`no-select-tap flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs whitespace-nowrap ${domain === t.id ? "bg-primary text-primary-foreground" : "bg-muted/50 text-muted-foreground"}`}>
            <t.icon className="w-3.5 h-3.5" /> {t.label}
            <span className="opacity-70">{t.count}</span>
          </button>
        ))}
      </div>

      <div className="space-y-2">
        {loading ? (
          <div className="flex justify-center py-4"><Loader2 className="w-4 h-4 animate-spin" /></div>
        ) : domain === "taches" ? (
          <TaskList items={items.taches} nameMap={nameMap} currentUserId={currentUserId} canManage={canManage} onRemove={(id) => remove("taches", id)} />
        ) : domain === "budget" ? (
          <BudgetList items={items.budget} canManage={canManage} onRemove={(id) => remove("budget", id)} />
        ) : domain === "evenements" ? (
          <EventList items={items.evenements} canManage={canManage} onRemove={(id) => remove("evenements", id)} />
        ) : (
          <PartnerList items={items.partenariats} canManage={canManage} onRemove={(id) => remove("partenariats", id)} />
        )}
      </div>

      {canManage && (
        <Button size="sm" variant="outline" className="w-full flex items-center gap-1" onClick={() => setShowAdd(true)}>
          <Plus className="w-4 h-4" /> Ajouter
        </Button>
      )}

      {showAdd && (
        <AddDialog
          domain={domain}
          conversation={conversation}
          participants={participants}
          nameMap={nameMap}
          currentUserId={currentUserId}
          onClose={() => setShowAdd(false)}
          onCreated={(d) => { setShowAdd(false); loadDomain(d); }}
        />
      )}
    </div>
  );
}

function Row({ title, sub, meta, canManage, onRemove }) {
  return (
    <div className="flex items-start justify-between gap-2 bg-muted/40 rounded-xl p-2.5">
      <div className="min-w-0">
        <p className="text-sm font-medium truncate">{title}</p>
        {sub && <p className="text-xs text-muted-foreground truncate">{sub}</p>}
        {meta && <p className="text-[11px] text-muted-foreground mt-0.5">{meta}</p>}
      </div>
      {canManage && (
        <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={onRemove}><Trash2 className="w-3.5 h-3.5" /></Button>
      )}
    </div>
  );
}

function TaskList({ items, nameMap, currentUserId, canManage, onRemove }) {
  if (!items.length) return <p className="text-xs text-muted-foreground text-center py-3">Aucune tâche partagée.</p>;
  return items.map((t) => (
    <Row key={t.id}
      title={t.title}
      sub={t.assignee_id ? `Responsable : ${memberName(t.assignee_id, nameMap, currentUserId)}` : "Non assignée"}
      meta={`${t.priority || ""} · ${t.status || ""}`}
      canManage={canManage} onRemove={() => onRemove(t.id)} />
  ));
}

function BudgetList({ items, canManage, onRemove }) {
  if (!items.length) return <p className="text-xs text-muted-foreground text-center py-3">Aucun budget partagé.</p>;
  return items.map((e) => (
    <Row key={e.id}
      title={e.name}
      sub={fmtMoney((e.unit_cost || 0) * (e.quantity || 1))}
      meta={`${e.date || ""}${e.recurring ? " · récurrent" : ""}${e.period ? " · " + e.period : ""}`}
      canManage={canManage} onRemove={() => onRemove(e.id)} />
  ));
}

function EventList({ items, canManage, onRemove }) {
  if (!items.length) return <p className="text-xs text-muted-foreground text-center py-3">Aucun événement partagé.</p>;
  return items.map((ev) => (
    <Row key={ev.id}
      title={ev.title}
      sub={ev.location}
      meta={`${new Date(ev.start).toLocaleString("fr-FR")} · ${ev.category || ""}`}
      canManage={canManage} onRemove={() => onRemove(ev.id)} />
  ));
}

function PartnerList({ items, canManage, onRemove }) {
  if (!items.length) return <p className="text-xs text-muted-foreground text-center py-3">Aucun partenariat partagé.</p>;
  return items.map((p) => (
    <Row key={p.id}
      title={p.partner_name}
      sub={p.contact_name || p.email || p.phone}
      meta={`${p.partner_type || ""} · ${p.status || ""}`}
      canManage={canManage} onRemove={() => onRemove(p.id)} />
  ));
}

function AddDialog({ domain, conversation, participants, nameMap, currentUserId, onClose, onCreated }) {
  const ctxType = conversation.type === "group" ? "group" : "collaboration";
  const ctxId = conversation.id;
  const base = { shared_context_type: ctxType, shared_context_id: ctxId, participants };

  const [form, setForm] = useState(() => initForm(domain));
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    const map = { taches: "Task", budget: "Expense", evenements: "Event", partenariats: "Partnership" };
    setBusy(true);
    try {
      const payload = buildPayload(domain, form, base);
      await base44.entities[map[domain]].create(payload);
      onCreated(domain);
    } catch (e) { toast({ title: "Erreur", description: e?.message, variant: "destructive" }); }
    finally { setBusy(false); }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader><DialogTitle>Nouvel élément partagé</DialogTitle></DialogHeader>
        <div className="space-y-3 max-h-[60vh] overflow-y-auto">
          {domain === "taches" && (
            <>
              <Field label="Titre"><Input value={form.title} onChange={(e) => set("title", e.target.value)} /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Priorité">
                  <Sel value={form.priority} onChange={(v) => set("priority", v)} opts={[["basse", "Basse"], ["normale", "Normale"], ["haute", "Haute"]]} />
                </Field>
                <Field label="Statut">
                  <Sel value={form.status} onChange={(v) => set("status", v)} opts={[["a_faire", "À faire"], ["en_cours", "En cours"], ["terminee", "Terminée"]]} />
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Début"><Input type="datetime-local" value={form.start} onChange={(e) => set("start", e.target.value)} /></Field>
                <Field label="Fin"><Input type="datetime-local" value={form.end} onChange={(e) => set("end", e.target.value)} /></Field>
              </div>
              <Field label="Responsable">
                <Sel value={form.assignee_id} onChange={(v) => set("assignee_id", v)}
                  opts={participants.map((id) => [id, memberName(id, nameMap, currentUserId)])} placeholder="Non assignée" />
              </Field>
            </>
          )}
          {domain === "budget" && (
            <>
              <Field label="Nom"><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Coût unitaire"><Input type="number" value={form.unit_cost} onChange={(e) => set("unit_cost", e.target.value)} /></Field>
                <Field label="Quantité"><Input type="number" value={form.quantity} onChange={(e) => set("quantity", e.target.value)} /></Field>
              </div>
              <Field label="Date"><Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Période"><Sel value={form.period} onChange={(v) => set("period", v)} opts={PERIODS.map((p) => [p.value, p.label])} placeholder="—" /></Field>
                <Field label="Récurrent">
                  <Sel value={form.recurring ? "oui" : "non"} onChange={(v) => set("recurring", v === "oui")} opts={[["non", "Non"], ["oui", "Oui"]]} />
                </Field>
              </div>
            </>
          )}
          {domain === "evenements" && (
            <>
              <Field label="Titre"><Input value={form.title} onChange={(e) => set("title", e.target.value)} /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Début"><Input type="datetime-local" value={form.start} onChange={(e) => set("start", e.target.value)} /></Field>
                <Field label="Fin"><Input type="datetime-local" value={form.end} onChange={(e) => set("end", e.target.value)} /></Field>
              </div>
              <Field label="Lieu"><Input value={form.location} onChange={(e) => set("location", e.target.value)} /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Catégorie"><Sel value={form.category} onChange={(v) => set("category", v)} opts={[["reunion", "Réunion"], ["rendez_vous", "RDV"], ["formation", "Formation"], ["ceremonie", "Cérémonie"], ["autre", "Autre"]]} /></Field>
                <Field label="Priorité"><Sel value={form.priority} onChange={(v) => set("priority", v)} opts={[["basse", "Basse"], ["normale", "Normale"], ["haute", "Haute"]]} /></Field>
              </div>
            </>
          )}
          {domain === "partenariats" && (
            <>
              <Field label="Nom du partenaire"><Input value={form.partner_name} onChange={(e) => set("partner_name", e.target.value)} /></Field>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Type"><Sel value={form.partner_type} onChange={(v) => set("partner_type", v)} opts={[["individu", "Individu"], ["personne_morale", "Personne morale"]]} /></Field>
                <Field label="Statut"><Sel value={form.status} onChange={(v) => set("status", v)} opts={[["prospect", "Prospect"], ["actif", "Actif"], ["inactif", "Inactif"]]} /></Field>
              </div>
              <Field label="Contact"><Input value={form.contact_name} onChange={(e) => set("contact_name", e.target.value)} /></Field>
              <Field label="Date de début"><Input type="date" value={form.start_date} onChange={(e) => set("start_date", e.target.value)} /></Field>
              <Field label="Modalités"><Input value={form.modalities} onChange={(e) => set("modalities", e.target.value)} /></Field>
            </>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Annuler</Button>
          <Button onClick={submit} disabled={busy}>{busy ? <Loader2 className="w-4 h-4 animate-spin" /> : "Ajouter"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}

function Sel({ value, onChange, opts, placeholder }) {
  return (
    <Select value={value || ""} onValueChange={onChange}>
      <SelectTrigger className="h-9"><SelectValue placeholder={placeholder || "Sélectionner"} /></SelectTrigger>
      <SelectContent>
        {opts.map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
      </SelectContent>
    </Select>
  );
}

function initForm(domain) {
  const now = new Date();
  const later = new Date(now.getTime() + 60 * 60 * 1000);
  if (domain === "taches") return { title: "", priority: "normale", status: "a_faire", start: toLocalInput(now), end: toLocalInput(later), assignee_id: "" };
  if (domain === "budget") return { name: "", unit_cost: "", quantity: 1, date: now.toISOString().slice(0, 10), period: "mois", recurring: false };
  if (domain === "evenements") return { title: "", start: toLocalInput(now), end: toLocalInput(later), location: "", category: "reunion", priority: "normale" };
  return { partner_name: "", partner_type: "individu", status: "prospect", contact_name: "", start_date: now.toISOString().slice(0, 10), modalities: "" };
}

function buildPayload(domain, form, base) {
  if (domain === "taches") {
    return { ...base, title: form.title, priority: form.priority, status: form.status, start: new Date(form.start).toISOString(), end: new Date(form.end).toISOString(), assignee_id: form.assignee_id || undefined };
  }
  if (domain === "budget") {
    return { ...base, name: form.name, unit_cost: Number(form.unit_cost) || 0, quantity: Number(form.quantity) || 1, date: form.date, period: form.period, recurring: !!form.recurring };
  }
  if (domain === "evenements") {
    return { ...base, title: form.title, start: new Date(form.start).toISOString(), end: new Date(form.end).toISOString(), location: form.location, category: form.category, priority: form.priority };
  }
  return { ...base, scope: base.shared_context_type, partner_name: form.partner_name, partner_type: form.partner_type, status: form.status, contact_name: form.contact_name, start_date: form.start_date, modalities: form.modalities };
}