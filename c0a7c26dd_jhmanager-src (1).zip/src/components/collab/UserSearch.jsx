import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, UserPlus, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function UserSearch({ currentUserId, excludeIds = [], onSent }) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(null);
  const { toast } = useToast();

  const runSearch = async () => {
    const term = q.trim();
    if (term.length < 2) { setResults([]); return; }
    setLoading(true);
    try {
      const list = await base44.entities.Collaborator.list("-created_date", 200);
      const t = term.toLowerCase();
      setResults((list || []).filter((c) => (c.display_name || "").toLowerCase().includes(t)));
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const sendRequest = async (c) => {
    setSending(c.id);
    try {
      await base44.entities.CollaborationRequest.create({
        to_user_id: c.created_by_id,
        to_name: c.display_name,
        status: "pending",
      });
      toast({ title: "Demande envoyée", description: c.display_name });
      onSent?.();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message || "Échec de l'envoi", variant: "destructive" });
    } finally {
      setSending(null);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); runSearch(); } }}
          placeholder="Rechercher un utilisateur par nom…"
        />
        <Button type="button" size="icon" onClick={runSearch} disabled={loading}>
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
        </Button>
      </div>
      {results.length > 0 && (
        <div className="space-y-2">
          {results.map((c) => {
            const isSelf = c.created_by_id === currentUserId;
            const excluded = excludeIds.includes(c.created_by_id);
            return (
              <div key={c.id} className="flex items-center justify-between gap-2 bg-card border border-border rounded-xl p-2.5">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{c.display_name}</p>
                </div>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  disabled={isSelf || excluded || sending === c.id}
                  onClick={() => sendRequest(c)}
                  className="flex items-center gap-1"
                >
                  {sending === c.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <UserPlus className="w-3.5 h-3.5" />}
                  {isSelf ? "Vous" : excluded ? "Collaborateur" : "Collaboration"}
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}