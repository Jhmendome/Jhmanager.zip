import React from "react";
import { PiggyBank, Trash2, CheckCircle2 } from "lucide-react";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { daysInPeriod, periodLabel, customOf } from "@/lib/periods";

export default function SavingsPlanList({ plans = [], currency = "XAF", onDelete, onToggleReached }) {
  if (!plans.length) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <PiggyBank className="w-8 h-8 mx-auto mb-3 opacity-50" />
        <p className="text-sm">Aucun plan d'épargne. Créez-en un pour mettre de côté automatiquement.</p>
      </div>
    );
  }
  return (
    <div className="space-y-2">
      {plans.map((p) => {
        const days = daysInPeriod(p.period, new Date(p.start_date || Date.now()), customOf(p));
        const daily = days > 0 ? (Number(p.target_amount) || 0) / days : 0;
        const reached = p.status === "atteint";
        return (
          <div key={p.id} className="bg-card border border-border rounded-xl p-4 flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm font-medium truncate">{p.name}</p>
                {reached && <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />}
              </div>
              <p className="text-xs text-muted-foreground">
                {formatCurrency(p.target_amount, currency)} sur {periodLabel(p.period, customOf(p))}
                {p.start_date ? ` · dès ${formatDateFr(p.start_date)}` : ""}
                {` · ${formatCurrency(daily, currency)}/jour`}
              </p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button onClick={() => onToggleReached(p)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary" title="Marquer atteint">
                <CheckCircle2 className={`w-4 h-4 ${reached ? "text-primary" : "text-muted-foreground"}`} />
              </button>
              <button onClick={() => onDelete(p)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive" title="Supprimer">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}