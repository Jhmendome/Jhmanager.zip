import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import PeriodPicker from "@/components/common/PeriodPicker";
import { daysInPeriod, periodLabel } from "@/lib/periods";
import { formatCurrency } from "@/lib/format";

const empty = { name: "", target_amount: "", period: "mois", customCount: "", customUnit: "jour", start_date: new Date().toISOString().slice(0, 10) };

export default function SavingsPlanForm({ open, onOpenChange, onSubmit, currency = "XAF" }) {
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");

  useEffect(() => { if (open) { setForm(empty); setError(""); } }, [open]);

  const amount = parseFloat(form.target_amount) || 0;
  const days = daysInPeriod(form.period, new Date(form.start_date || Date.now()), { count: form.customCount, unit: form.customUnit });
  const daily = days > 0 ? amount / days : 0;

  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim()) { setError("Nom requis"); return; }
    if (isNaN(amount) || amount <= 0) { setError("Montant invalide"); return; }
    onSubmit({
      name: form.name.trim(),
      target_amount: amount,
      period: form.period,
      custom_count: form.period === "personnalise" ? (parseInt(form.customCount, 10) || 0) : null,
      custom_unit: form.period === "personnalise" ? form.customUnit : null,
      start_date: form.start_date,
      status: "actif",
      saved_amount: 0,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle className="font-display">Nouveau plan d'épargne</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="space-y-2"><Label>Nom</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex. Vacances, fonds d'urgence…" required /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2"><Label>Montant à épargner ({currency})</Label><Input type="number" min="0" step="any" value={form.target_amount} onChange={(e) => setForm({ ...form, target_amount: e.target.value })} required /></div>
            <div className="space-y-2"><Label>Date de début</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></div>
          </div>
          <PeriodPicker
            period={form.period}
            customCount={form.customCount}
            customUnit={form.customUnit}
            onChange={({ period, customCount, customUnit }) => setForm({ ...form, period, customCount, customUnit })}
            label="Période d'épargne"
          />
          {amount > 0 && (
            <div className="rounded-xl bg-secondary p-3 text-sm space-y-1">
              <p>Soit <span className="font-medium">{formatCurrency(daily, currency)}</span> / jour</p>
              <p className="text-muted-foreground">Sur {days} jour(s) · {periodLabel(form.period, { count: form.customCount, unit: form.customUnit })}</p>
            </div>
          )}
          <DialogFooter><Button type="submit" className="w-full">Créer le plan</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}