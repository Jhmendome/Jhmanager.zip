import React, { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import CategorySelect from "@/components/categories/CategorySelect";
import PeriodPicker from "@/components/common/PeriodPicker";
import { useSpace } from "@/lib/SpaceContext";
import { useI18n } from "@/lib/i18n";

function todayInput() {
  return new Date().toISOString().slice(0, 10);
}

export default function ExpenseForm({ open, onOpenChange, expense, onSubmit }) {
  const { t } = useI18n();
  const { space } = useSpace();
  const [name, setName] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [unitCost, setUnitCost] = useState("");
  const [category, setCategory] = useState("");
  const [date, setDate] = useState(todayInput());
  const [repeat, setRepeat] = useState(false);
  const [frequency, setFrequency] = useState("mois");
  const [repeatCount, setRepeatCount] = useState("1");
  const [customCount, setCustomCount] = useState("");
  const [customUnit, setCustomUnit] = useState("jour");
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setName(expense?.name || "");
      setQuantity(String(expense?.quantity ?? 1));
      setUnitCost(String(expense?.unit_cost ?? ""));
      setCategory(expense?.category || "");
      setDate(expense?.date || todayInput());
      setRepeat(false);
      setFrequency("mois");
      setRepeatCount("1");
      setCustomCount("");
      setCustomUnit("jour");
      setError("");
    }
  }, [open, expense]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const qty = parseFloat(quantity);
    const cost = parseFloat(unitCost);
    if (!name.trim()) {
      setError(t("expform.err.name"));
      return;
    }
    if (isNaN(qty) || qty <= 0) {
      setError(t("expform.err.qty"));
      return;
    }
    if (isNaN(cost) || cost < 0) {
      setError(t("expform.err.cost"));
      return;
    }
    onSubmit({
      name: name.trim(),
      quantity: qty,
      unit_cost: cost,
      category: category.trim(),
      date,
    }, repeat && !expense && parseInt(repeatCount, 10) > 1 ? { frequency, count: parseInt(repeatCount, 10), custom: frequency === "personnalise" ? { count: parseInt(customCount, 10) || 0, unit: customUnit } : null } : null);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">{expense ? t("expform.edit") : t("expform.new")}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="space-y-2">
            <Label htmlFor="name">{t("expform.name")}</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("expform.namePlaceholder")} autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="quantity">{t("expform.quantity")}</Label>
              <Input id="quantity" type="number" min="0" step="any" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="unitCost">{t("expform.unitCost")}</Label>
              <Input id="unitCost" type="number" min="0" step="any" value={unitCost} onChange={(e) => setUnitCost(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="category">{t("expform.category")}</Label>
              <CategorySelect scope={space} domain="depense" value={category} onChange={setCategory} placeholder={t("expform.categoryPlaceholder")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">{t("expform.date")}</Label>
              <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
          </div>
          {!expense && (
            <div className="space-y-3 rounded-xl border border-border p-3">
              <div className="flex items-center gap-2">
                <Checkbox checked={repeat} onCheckedChange={setRepeat} id="exp-repeat" />
                <Label htmlFor="exp-repeat">Répéter périodiquement</Label>
              </div>
              {repeat && (
                <div className="space-y-3">
                  <PeriodPicker
                    period={frequency}
                    customCount={customCount}
                    customUnit={customUnit}
                    onChange={({ period, customCount: cc, customUnit: cu }) => { setFrequency(period); setCustomCount(cc); setCustomUnit(cu); }}
                    label="Fréquence"
                    id="exp-freq"
                  />
                  <div className="space-y-1.5">
                    <Label htmlFor="exp-count" className="text-xs">Nombre d'échéances</Label>
                    <Input id="exp-count" type="number" min="1" max="120" value={repeatCount} onChange={(e) => setRepeatCount(e.target.value)} />
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button type="submit" className="w-full">{expense ? t("common.save") : t("expform.add")}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}