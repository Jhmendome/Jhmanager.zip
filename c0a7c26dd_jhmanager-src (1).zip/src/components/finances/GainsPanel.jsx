import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Pencil, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { evalExpr, computeGrandeurs, sanitizeName, formatNumber } from "@/lib/mathEval";
import { loadMetrics } from "@/lib/calcSources";
import { useSpace } from "@/lib/SpaceContext";
import { formatCurrency } from "@/lib/format";

const PERIODS = [
  { value: "jour", label: "Journalier" },
  { value: "semaine", label: "Hebdomadaire" },
  { value: "mois", label: "Mensuel" },
  { value: "trimestre", label: "Trimestriel" },
  { value: "semestre", label: "Semestriel" },
  { value: "annee", label: "Annuel" },
];
const MONTH_FACTOR = { jour: 30, semaine: 4.345, mois: 1, trimestre: 1 / 3, semestre: 1 / 6, annee: 1 / 12 };
const toMonthly = (amount, period) => (Number(amount) || 0) * (MONTH_FACTOR[period] || 0);

const empty = { name: "", label: "", expression: "", unit: "XAF", gain_recurring: false, gain_period: "mois" };

export default function GainsPanel({ currency }) {
  const { activeCompanyId } = useSpace();
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [metrics, setMetrics] = useState({});
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);

  const reload = async () => {
    const list = await base44.entities.CalcDefinition.list("-created_date", 500);
    setItems((list || []).filter((i) => i.kind === "gain"));
  };
  useEffect(() => {
    (async () => {
      await reload();
      try { setMetrics(await loadMetrics(activeCompanyId)); } catch { /* ignore */ }
      setLoading(false);
    })();
  }, [activeCompanyId]);

  const grandeurs = items; // gains can also reference other grandeurs
  const allDefs = useMemo(() => items, [items]);
  const scope = computeGrandeurs(allDefs, metrics);

  const evalGain = (g) => {
    try {
      const v = evalExpr(g.expression, { ...scope, ...metrics });
      return isFinite(v) ? v : null;
    } catch { return null; }
  };

  const totalMonthly = items.reduce((s, g) => {
    const v = evalGain(g);
    if (v == null) return s;
    return s + (g.gain_recurring ? toMonthly(v, g.gain_period) : 0);
  }, 0);
  const totalOneShot = items.reduce((s, g) => {
    const v = evalGain(g);
    if (v == null) return s;
    return s + (g.gain_recurring ? 0 : v);
  }, 0);

  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (g) => {
    setEditing(g);
    setForm({
      name: g.name || "",
      label: g.label || "",
      expression: g.expression || "",
      unit: g.unit || "XAF",
      gain_recurring: !!g.gain_recurring,
      gain_period: g.gain_period || "mois",
    });
    setOpen(true);
  };

  const save = async () => {
    const name = sanitizeName(form.name);
    if (!name || !form.expression.trim()) { toast({ title: "Nom et formule requis", variant: "destructive" }); return; }
    const payload = { name, label: form.label || name, kind: "gain", expression: form.expression, unit: form.unit, gain_recurring: form.gain_recurring, gain_period: form.gain_period };
    try {
      if (editing) await base44.entities.CalcDefinition.update(editing.id, payload);
      else await base44.entities.CalcDefinition.create(payload);
      toast({ title: "Gain enregistré" });
      setOpen(false); reload();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const remove = async (g) => {
    try { await base44.entities.CalcDefinition.delete(g.id); reload(); }
    catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  if (loading) return <div className="flex justify-center py-8"><div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <div className="grid grid-cols-2 gap-3 w-full">
          <div className="bg-card border border-border rounded-2xl p-4">
            <p className="text-sm text-muted-foreground">Gains récurrents (mois)</p>
            <p className="font-display text-xl mt-1">{formatCurrency(totalMonthly, currency)}</p>
          </div>
          <div className="bg-card border border-border rounded-2xl p-4">
            <p className="text-sm text-muted-foreground">Gains ponctuels</p>
            <p className="font-display text-xl mt-1">{formatCurrency(totalOneShot, currency)}</p>
          </div>
        </div>
        <Button onClick={openNew} size="sm"><Plus className="w-4 h-4 mr-1" /> Nouveau</Button>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground">
          <TrendingUp className="w-8 h-8 mx-auto mb-3 opacity-50" />
          <p className="text-sm">Aucune formule de gain. Créez-en une (ex. <span className="font-mono">budget_initial * 0.2</span>).</p>
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((g) => {
            const v = evalGain(g);
            const monthly = g.gain_recurring && v != null ? toMonthly(v, g.gain_period) : 0;
            return (
              <div key={g.id} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{g.label} <span className="text-xs text-muted-foreground font-mono">({g.name})</span></p>
                    <p className="text-sm font-mono text-accent truncate">{g.expression}{g.unit ? ` [${g.unit}]` : ""}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {g.gain_recurring ? `Récurrent · ${PERIODS.find((p) => p.value === g.gain_period)?.label}` : "Ponctuel"} ·
                      {" "}Valeur : {v != null ? formatCurrency(v, currency) : "—"}
                      {g.gain_recurring && v != null && ` · ≈ ${formatCurrency(monthly, currency)}/mois`}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button onClick={() => openEdit(g)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => remove(g)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Modifier le gain" : "Nouvelle formule de gain"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Nom (identifiant)</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="benefice_net" /></div>
              <div className="space-y-1"><Label>Libellé</Label><Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Bénéfice net" /></div>
            </div>
            <div className="space-y-1"><Label>Formule</Label><Input value={form.expression} onChange={(e) => setForm({ ...form, expression: e.target.value })} placeholder="budget_initial * 0.2 - total_depenses" />
              <p className="text-xs text-muted-foreground">Référencez vos indicateurs : budget_initial, total_depenses, ca_ventes, etc.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Type</Label>
                <Select value={form.gain_recurring ? "rec" : "ponc"} onValueChange={(v) => setForm({ ...form, gain_recurring: v === "rec" })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="ponc">Ponctuel</SelectItem><SelectItem value="rec">Récurrent</SelectItem></SelectContent>
                </Select>
              </div>
              {form.gain_recurring && (
                <div className="space-y-1"><Label>Périodicité</Label>
                  <Select value={form.gain_period} onValueChange={(v) => setForm({ ...form, gain_period: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{PERIODS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              )}
            </div>
            <div className="space-y-1"><Label>Unité</Label><Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} placeholder="XAF" /></div>
          </div>
          <DialogFooter><Button onClick={save}>Enregistrer</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}