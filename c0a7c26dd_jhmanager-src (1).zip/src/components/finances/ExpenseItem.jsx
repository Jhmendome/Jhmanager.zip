import React, { useState } from "react";
import { Pencil, Trash2 } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ExpenseItem({ expense, currency, onEdit, onDelete, selectable, selected, onToggleSelect }) {
  const { t } = useI18n();
  const total = (Number(expense.quantity) || 0) * (Number(expense.unit_cost) || 0);
  const [confirmOpen, setConfirmOpen] = useState(false);

  return (
    <>
      <div className="flex items-center gap-3 p-4 rounded-2xl border border-border bg-card">
        {selectable && (
          <Checkbox
            checked={!!selected}
            onCheckedChange={() => onToggleSelect(expense.id)}
            aria-label="Sélectionner"
            className="shrink-0"
          />
        )}
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium truncate">{expense.name}</p>
          <p className="text-sm text-muted-foreground mt-0.5">
            {expense.category || t("common.other")} · {formatDateFr(expense.date)} · {expense.quantity} × {formatCurrency(expense.unit_cost, currency)}
          </p>
        </div>
        <p className="font-display text-sm shrink-0">{formatCurrency(total, currency)}</p>
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => onEdit(expense)}
            aria-label={t("expitem.editAria")}
            className="no-select-tap min-touch p-2.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
          >
            <Pencil className="w-4 h-4" />
          </button>
          <button
            onClick={() => setConfirmOpen(true)}
            aria-label={t("expitem.deleteAria")}
            className="no-select-tap min-touch p-2.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-destructive transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("expitem.deleteTitle")}</AlertDialogTitle>
            <AlertDialogDescription>{t("expitem.deleteDesc", { name: expense.name })}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => onDelete(expense)}
            >
              {t("common.delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}