import React, { useEffect, useState } from "react";
import { useLocation, useOutlet, Navigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { base44 } from "@/api/base44Client";
import SidebarNav from "@/components/layout/SidebarNav";
import BottomNav from "@/components/layout/BottomNav";
import PullToRefresh from "@/components/PullToRefresh";
import AccountBar from "@/components/layout/AccountBar";
import { RefreshProvider, useRefresh } from "@/lib/RefreshContext";
import { SpaceProvider, useSpace } from "@/lib/SpaceContext";
import { useAuth } from "@/lib/AuthContext";
import { pageVariants, pageTransition } from "@/lib/pageTransitions";

// Routes strictement liées à un espace. Un utilisateur entreprise n'accède pas
// aux outils JPM, et inverse versa. L'admin garde accès à tout.
const JPM_ONLY = ["/finances", "/taches", "/planning", "/calendrier", "/seuils", "/reporting", "/taxes", "/emprunts"];

function SpaceGuard({ children }) {
  const location = useLocation();
  const { user } = useAuth();
  const { availableSpaces } = useSpace();
  if (!user || user.role === "admin") return children;
  const path = location.pathname;
  // Accès autorisé selon les espaces possédés (un utilisateur peut avoir les deux).
  if (!availableSpaces.includes("jpm") && JPM_ONLY.includes(path)) {
    return <Navigate to="/jbm" replace />;
  }
  if (!availableSpaces.includes("jbm") && path.startsWith("/jbm")) {
    return <Navigate to="/" replace />;
  }
  return children;
}

function AnimatedContent({ children }) {
  const location = useLocation();
  const outlet = useOutlet();
  const { run } = useRefresh();
  const content = outlet ?? children;

  return (
    <PullToRefresh onRefresh={run}>
      <AnimatePresence mode="wait">
        <motion.div
          key={location.pathname}
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          transition={pageTransition}
        >
          {content}
        </motion.div>
      </AnimatePresence>
    </PullToRefresh>
  );
}

export default function Layout({ children }) {
  const [email, setEmail] = useState("");

  useEffect(() => {
    base44.auth.me().then((u) => setEmail(u?.email || "")).catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-background font-body">
      <SidebarNav userEmail={email} />
      <main className="md:pl-64 pb-24 md:pb-10 min-h-screen safe-top">
        <SpaceProvider>
          <RefreshProvider>
            <SpaceGuard>
              <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
                <div className="flex justify-end mb-4">
                  <AccountBar />
                </div>
                <AnimatedContent children={children} />
              </div>
            </SpaceGuard>
          </RefreshProvider>
        </SpaceProvider>
      </main>
      <BottomNav />
    </div>
  );
}