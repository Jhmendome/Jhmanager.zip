import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Search, Loader2 } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { base44 } from "@/api/base44Client";
import { useSpace } from "@/lib/SpaceContext";
import { useNavigate } from "react-router-dom";

// Recherche globale : charge les principales entités puis filre côté client.
const CONFIG = [
  { key: "Task", label: "Tâche", fields: ["title"], link: "/taches", primary: "title" },
  { key: "Expense", label: "Dépense", fields: ["name", "category"], link: "/finances", primary: "name" },
  { key: "Event", label: "Événement", fields: ["title", "location"], link: "/evenements", primary: "title" },
  { key: "Notification", label: "Notification", fields: ["title", "message"], link: "/notifications", primary: "title" },
  { key: "Suggestion", label: "Suggestion", fields: ["content"], link: "/suggestions", primary: "content" },
  { key: "Product", label: "Produit", fields: ["name"], link: "/jbm/stock", primary: "name", scoped: true },
  { key: "Sale", label: "Vente", fields: ["item_name", "customer_name"], link: "/jbm/ventes", primary: "item_name", scoped: true },
  { key: "Invoice", label: "Facture", fields: ["number", "customer_name"], link: "/jbm/factures", primary: "number", scoped: true },
  { key: "Client", label: "Client", fields: ["name"], link: "/jbm/clients", primary: "name", scoped: true },
  { key: "Quote", label: "Devis", fields: ["number", "client_name"], link: "/jbm/devis", primary: "number", scoped: true },
  { key: "Supplier", label: "Prestataire", fields: ["name"], link: "/jbm/prestataires", primary: "name", scoped: true },
  { key: "Tax", label: "Taxe", fields: ["name"], link: "/jbm/taxes", primary: "name", scoped: true },
  { key: "Partnership", label: "Partenariat", fields: ["partner_name"], link: "/jbm/partenariats", primary: "partner_name", scoped: true },
  { key: "Employee", label: "Employé", fields: ["full_name", "role"], link: "/jbm/personnel", primary: "full_name", scoped: true },
  { key: "Company", label: "Entreprise", fields: ["name"], link: "/jbm/entreprises", primary: "name" },
];

export default function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({});
  const { activeCompanyId } = useSpace();
  const navigate = useNavigate();

  const loadAll = useCallback(async () => {
    setLoading(true);
    const entries = await Promise.all(
      CONFIG.map(async (c) => {
        try {
          const list = await base44.entities[c.key].list("-created_date", 200);
          let recs = list || [];
          if (c.scoped && activeCompanyId) recs = recs.filter((r) => r.company_id === activeCompanyId);
          return [c.key, recs];
        } catch {
          return [c.key, []];
        }
      })
    );
    setData(Object.fromEntries(entries));
    setLoading(false);
  }, [activeCompanyId]);

  // Recharge quand on ouvre ou quand l'entreprise active change.
  useEffect(() => {
    if (open) loadAll();
  }, [open, loadAll]);

  // Raccourci Cmd/Ctrl+K.
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const results = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return [];
    const out = [];
    for (const c of CONFIG) {
      const recs = data[c.key] || [];
      const matches = [];
      for (const r of recs) {
        const hit = c.fields.some((f) => {
          const v = r[f];
          return v != null && String(v).toLowerCase().includes(query);
        });
        if (hit) {
          matches.push(r);
          if (matches.length >= 6) break;
        }
      }
      if (matches.length) out.push({ config: c, matches });
    }
    return out;
  }, [q, data]);

  const go = (link) => {
    setOpen(false);
    setQ("");
    navigate(link);
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="no-select-tap min-touch flex items-center gap-2 w-full sm:w-64 h-9 px-3 rounded-md border border-input bg-muted/50 text-sm text-muted-foreground hover:bg-muted transition-colors"
      >
        <Search className="w-4 h-4" />
        <span className="flex-1 text-left truncate">Rechercher…</span>
        <kbd className="hidden sm:inline text-[10px] px-1.5 py-0.5 rounded border border-border bg-background">⌘K</kbd>
      </button>

      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setQ(""); }}>
        <DialogContent className="p-0 max-w-xl gap-0 overflow-hidden">
          <div className="flex items-center gap-2 px-4 border-b border-border">
            <Search className="w-4 h-4 text-muted-foreground shrink-0" />
            <Input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Tâche, client, facture, produit…"
              className="border-0 shadow-none focus-visible:ring-0 h-12 px-0"
            />
            {loading && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground shrink-0" />}
          </div>
          <div className="max-h-[60vh] overflow-y-auto p-2">
            {!q.trim() ? (
              <p className="text-sm text-muted-foreground px-3 py-8 text-center">
                Saisissez quelques mots pour rechercher dans toutes vos données.
              </p>
            ) : results.length === 0 ? (
              <p className="text-sm text-muted-foreground px-3 py-8 text-center">
                Aucun résultat pour « {q.trim()} ».
              </p>
            ) : (
              results.map((g) => (
                <div key={g.config.key} className="mb-1">
                  <p className="text-[11px] uppercase tracking-wide text-muted-foreground px-3 pt-2 pb-1">
                    {g.config.label}
                  </p>
                  {g.matches.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => go(g.config.link)}
                      className="no-select-tap w-full text-left px-3 py-2 rounded-lg hover:bg-accent/10 transition-colors"
                    >
                      <span className="text-sm font-medium truncate block">
                        {r[g.config.primary] || "(sans titre)"}
                      </span>
                    </button>
                  ))}
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}