import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Wallet, TrendingDown, CheckCircle2, AlertTriangle, ListChecks, CalendarRange,
  CalendarDays, Bot, Calculator, Bell, Tag, UsersRound, Gift, Boxes,
  ShoppingCart, FileText, Handshake, BarChart3, Building2, User, ArrowRight,
} from "lucide-react";
import KpiCard from "@/components/dashboard/KpiCard";
import QuickLinks from "@/components/dashboard/QuickLinks";

const JPM_PREVIEW = {
  badge: "JPM",
  badgeIcon: User,
  tone: "primary",
  title: "Espace personnel (JPM)",
  subtitle: "Bienvenue 👋 Voici un aperçu de votre tableau de bord particulier.",
  kpis: [
    { icon: Wallet, label: "Budget restant", value: "285 000 XAF", tone: "default" },
    { icon: TrendingDown, label: "Dépenses du mois", value: "215 000 XAF", tone: "accent" },
    { icon: CheckCircle2, label: "Tâches du jour", value: 3, tone: "default" },
    { icon: AlertTriangle, label: "En retard", value: 1, tone: "warn" },
  ],
  upcoming: [
    { title: "Réunion banque", when: "Demain · 09:00", priority: "Haute" },
    { title: "Course marché", when: "Sam. · 08:00", priority: "Normale" },
    { title: "Rendez-vous médecin", when: "Lun. · 14:30", priority: "Normale" },
  ],
  links: [
    { to: "#", label: "Finances", icon: Wallet, desc: "Budget, dépenses, taxes & emprunts" },
    { to: "#", label: "Tâches", icon: ListChecks, desc: "Vos tâches" },
    { to: "#", label: "Planning", icon: CalendarRange, desc: "Calendrier" },
    { to: "#", label: "Événements", icon: CalendarDays, desc: "RDV & événements" },
    { to: "#", label: "Calculatrice", icon: Calculator, desc: "Calculatrice & formules" },
    { to: "#", label: "Assistant IA JPM", icon: Bot, desc: "Aide intelligente" },
    { to: "#", label: "Catégories", icon: Tag, desc: "Organisez vos catégories" },
    { to: "#", label: "Collaborateurs", icon: UsersRound, desc: "Échangez ensemble" },
    { to: "#", label: "Suggestions", icon: Gift, desc: "Proposez des idées" },
    { to: "#", label: "Affiliation", icon: Gift, desc: "Parrainez et gagnez" },
  ],
};

const JBM_PREVIEW = {
  badge: "JBM",
  badgeIcon: Building2,
  tone: "accent",
  title: "Espace entreprise (JBM)",
  subtitle: "Pilotez votre activité comme un pro — multi-entreprises.",
  kpis: [
    { icon: TrendingDown, label: "Ventes du mois", value: "1 250 000 XAF", tone: "default" },
    { icon: Wallet, label: "Stock valorisé", value: "640 000 XAF", tone: "accent" },
    { icon: FileText, label: "Factures impayées", value: 4, tone: "warn" },
    { icon: AlertTriangle, label: "Alertes stock bas", value: 2, tone: "warn" },
  ],
  upcoming: [
    { title: "Livraison Fournisseur X", when: "Auj. · 16:00", priority: "Haute" },
    { title: "Réunion équipe ventes", when: "Jeu. · 10:00", priority: "Normale" },
    { title: "Échéance TVA", when: "15 oct.", priority: "Haute" },
  ],
  links: [
    { to: "#", label: "Stock", icon: Boxes, desc: "Inventaire & produits" },
    { to: "#", label: "Ventes", icon: ShoppingCart, desc: "Ventes & clients" },
    { to: "#", label: "Factures", icon: FileText, desc: "Factures & devis" },
    { to: "#", label: "Partenariats", icon: Handshake, desc: "Vos partenaires" },
    { to: "#", label: "Reporting", icon: BarChart3, desc: "Rapports & graphiques" },
    { to: "#", label: "Assistant IA JBM", icon: Bot, desc: "Aide métier" },
    { to: "#", label: "Personnel", icon: UsersRound, desc: "Équipe & salaires" },
    { to: "#", label: "Taxes", icon: TrendingDown, desc: "Taxes & charges" },
  ],
};

export default function DashboardPreview() {
  const [space, setSpace] = useState("jpm");
  const data = space === "jbm" ? JBM_PREVIEW : JPM_PREVIEW;
  const BadgeIcon = data.badgeIcon;

  return (
    <div className="rounded-3xl border border-border bg-card p-5 sm:p-7">
      {/* Bascule JPM / JBM */}
      <div className="flex items-center justify-between gap-3 flex-wrap mb-5">
        <div className="inline-flex items-center gap-2">
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${data.tone === "accent" ? "bg-accent/15 text-accent-foreground" : "bg-primary/10 text-primary"}`}>
            <BadgeIcon className="w-3.5 h-3.5" /> {data.badge}
          </span>
          <span className="text-sm text-muted-foreground">Abonnement simulé · validé automatiquement</span>
        </div>
        <div className="inline-flex rounded-xl border border-border overflow-hidden">
          <button
            onClick={() => setSpace("jpm")}
            className={`no-select-tap min-touch px-4 py-2 text-sm font-medium transition-colors ${space === "jpm" ? "bg-primary text-primary-foreground" : "bg-transparent hover:bg-accent/10"}`}
          >
            Particulier
          </button>
          <button
            onClick={() => setSpace("jbm")}
            className={`no-select-tap min-touch px-4 py-2 text-sm font-medium transition-colors ${space === "jbm" ? "bg-accent text-accent-foreground" : "bg-transparent hover:bg-accent/10"}`}
          >
            Entreprise
          </button>
        </div>
      </div>

      <div className="mb-5">
        <h3 className="font-display text-xl sm:text-2xl">{data.title}</h3>
        <p className="text-muted-foreground mt-1 text-sm">{data.subtitle}</p>
      </div>

      {/* Bandeau abonnement actif */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="mb-5 rounded-2xl bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20 p-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center shrink-0">
          <CheckCircle2 className="w-5 h-5" />
        </div>
        <div className="flex-1">
          <p className="font-medium text-sm">Abonnement {space === "jbm" ? "Entreprise" : "Particulier"} actif ✓</p>
          <p className="text-xs text-muted-foreground">Mode démo · aucune transaction réelle · valide par défaut</p>
        </div>
      </motion.div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {data.kpis.map((k) => (
          <KpiCard key={k.label} icon={k.icon} label={k.label} value={k.value} tone={k.tone} />
        ))}
      </div>

      <div className="mb-6">
        <h4 className="font-display text-lg mb-3">Accès rapide</h4>
        <QuickLinks items={data.links} />
      </div>

      <div className="bg-background border border-border rounded-2xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-display text-lg">À venir</h4>
          <span className="text-sm text-muted-foreground inline-flex items-center gap-1">
            Voir le planning <ArrowRight className="w-3.5 h-3.5" />
          </span>
        </div>
        <div className="space-y-3">
          {data.upcoming.map((t) => (
            <div key={t.title} className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{t.title}</p>
                <p className="text-xs text-muted-foreground">{t.when}</p>
              </div>
              <span className="text-xs px-2 py-1 rounded-full bg-secondary text-secondary-foreground shrink-0">{t.priority}</span>
            </div>
          ))}
        </div>
      </div>

      <p className="mt-5 text-xs text-muted-foreground text-center">
        Aperçu statique illustratif. Les liens ci-dessus ne naviguent pas (mode démo).
      </p>
    </div>
  );
}