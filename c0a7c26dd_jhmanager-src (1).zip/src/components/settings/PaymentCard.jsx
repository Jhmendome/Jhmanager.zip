import React, { useState } from "react";
import { CreditCard, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { base44 } from "@/api/base44Client";

export default function PaymentCard() {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [provider, setProvider] = useState("airtel");
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const handlePay = async (e) => {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) {
      toast({ title: "Montant invalide", variant: "destructive" });
      return;
    }
    if (!phoneNumber.trim()) {
      toast({ title: "Numéro de téléphone requis", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const res = await base44.functions.invoke('processPayment', {
        amount: amt,
        phoneNumber: phoneNumber.trim(),
        provider,
      });
      if (res?.success || res?.data) {
        toast({
          title: "Paiement initié",
          description: res?.data?.message || "Votre demande de paiement a été envoyée.",
        });
        setOpen(false);
        setAmount("");
        setPhoneNumber("");
      } else {
        toast({
          title: "Échec du paiement",
          description: res?.error || "Erreur inconnue",
          variant: "destructive",
        });
      }
    } catch (err) {
      const body = err && err.response && err.response.data;
      toast({
        title: "Échec du paiement",
        description: (body && body.error) || err?.message || "Erreur réseau",
        variant: "destructive",
      });
    }
    setSubmitting(false);
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-6 space-y-3">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl bg-accent/15 text-accent flex items-center justify-center shrink-0">
          <CreditCard className="w-5 h-5" />
        </div>
        <div>
          <h2 className="font-display text-lg">Paiement Mobile Money</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Rechargez votre compte via Airtel Money ou Moov Money.
          </p>
        </div>
      </div>
      <Button className="w-full" onClick={() => setOpen(true)}>
        <CreditCard className="w-4 h-4" /> Payer
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Paiement Mobile Money</DialogTitle>
            <DialogDescription>
              Renseignez les détails pour initier le paiement.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handlePay} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="pay-amount">Montant (XAF)</Label>
              <Input
                id="pay-amount"
                type="number"
                min="1"
                step="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="1000"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pay-phone">Numéro de téléphone</Label>
              <Input
                id="pay-phone"
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="06 00 00 00 00"
              />
            </div>
            <div className="space-y-2">
              <Label>Opérateur</Label>
              <Select value={provider} onValueChange={setProvider}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="airtel">Airtel Money</SelectItem>
                  <SelectItem value="moov">Moov Money</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={submitting}>
                Annuler
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Traitement…
                  </>
                ) : (
                  "Payer"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}