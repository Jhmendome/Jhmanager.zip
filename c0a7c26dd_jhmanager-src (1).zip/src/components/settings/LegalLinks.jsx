import React from "react";
import { Link } from "react-router-dom";
import { Shield, FileText, Info } from "lucide-react";
import { useI18n } from "@/lib/i18n";

export default function LegalLinks() {
  const { t } = useI18n();
  return (
    <div className="bg-card border border-border rounded-2xl p-6 space-y-3">
      <div>
        <h2 className="font-display text-lg flex items-center gap-2"><Shield className="w-4 h-4" /> {t("settings.legal")}</h2>
        <p className="text-sm text-muted-foreground mt-1">JM (JH Manager)</p>
      </div>
      <div className="flex flex-col gap-2 text-sm">
        <Link to="/confidentialite" className="text-primary hover:underline flex items-center gap-2"><FileText className="w-4 h-4" /> {t("settings.privacy")}</Link>
        <Link to="/conditions" className="text-primary hover:underline flex items-center gap-2"><FileText className="w-4 h-4" /> {t("settings.terms")}</Link>
        <Link to="/confidentialite" className="text-muted-foreground hover:underline flex items-center gap-2"><Info className="w-4 h-4" /> {t("settings.about")}</Link>
      </div>
    </div>
  );
}