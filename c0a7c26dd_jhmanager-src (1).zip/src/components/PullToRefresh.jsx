import React, { useRef, useState, useCallback, useEffect } from "react";
import { Loader2, RefreshCw } from "lucide-react";

const THRESHOLD = 70;
const MAX = 100;

/**
 * Native-style pull-to-refresh that works with the window/page scroll
 * (no nested scroll container), so desktop window scrolling stays intact.
 * Engages only when the page is scrolled to the very top.
 */
export default function PullToRefresh({ onRefresh, children }) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef(null);
  const pulling = useRef(false);

  const atTop = () => {
    const el = document.scrollingElement || document.documentElement;
    return (el ? el.scrollTop : window.scrollY) <= 0;
  };

  const onTouchStart = useCallback((e) => {
    if (refreshing || !atTop()) {
      startY.current = null;
      pulling.current = false;
      return;
    }
    startY.current = e.touches[0].clientY;
    pulling.current = false;
  }, [refreshing]);

  const onTouchMove = useCallback((e) => {
    if (startY.current === null || refreshing) return;
    if (!atTop()) {
      if (pull > 0) setPull(0);
      pulling.current = false;
      return;
    }
    const dy = e.touches[0].clientY - startY.current;
    if (dy <= 0) {
      if (pull > 0) setPull(0);
      pulling.current = false;
      return;
    }
    pulling.current = true;
    setPull(Math.min(MAX, dy * 0.5));
  }, [refreshing, pull]);

  const onTouchEnd = useCallback(async () => {
    if (!pulling.current || refreshing) {
      setPull(0);
      startY.current = null;
      return;
    }
    startY.current = null;
    pulling.current = false;
    if (pull >= THRESHOLD) {
      setRefreshing(true);
      setPull(THRESHOLD);
      try {
        await Promise.resolve(onRefresh && onRefresh());
      } catch (e) {
        /* errors handled by caller toasts */
      } finally {
        setRefreshing(false);
        setPull(0);
      }
    } else {
      setPull(0);
    }
  }, [pull, refreshing, onRefresh]);

  useEffect(() => {
    document.addEventListener("touchstart", onTouchStart, { passive: true });
    document.addEventListener("touchmove", onTouchMove, { passive: true });
    document.addEventListener("touchend", onTouchEnd, { passive: true });
    return () => {
      document.removeEventListener("touchstart", onTouchStart);
      document.removeEventListener("touchmove", onTouchMove);
      document.removeEventListener("touchend", onTouchEnd);
    };
  }, [onTouchStart, onTouchMove, onTouchEnd]);

  const progress = Math.min(1, pull / THRESHOLD);

  return (
    <>
      <div
        className="fixed left-0 right-0 top-0 flex items-end justify-center pointer-events-none z-30"
        style={{
          height: pull,
          opacity: progress,
          transition: pull === 0 || refreshing ? "height 0.2s ease, opacity 0.2s ease" : "none",
        }}
        aria-hidden="true"
      >
        {refreshing ? (
          <Loader2 className="w-6 h-6 text-primary animate-spin mb-2" />
        ) : (
          <RefreshCw
            className="w-5 h-5 text-primary mb-2"
            style={{ transform: `rotate(${progress * 360}deg)` }}
          />
        )}
      </div>
      <div
        style={{
          transform: `translateY(${pull}px)`,
          transition: pull === 0 || refreshing ? "transform 0.2s ease" : "none",
        }}
      >
        {children}
      </div>
    </>
  );
}