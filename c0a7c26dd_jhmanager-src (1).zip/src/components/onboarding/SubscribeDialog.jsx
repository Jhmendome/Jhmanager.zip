import React, { useState, useEffect } from "react";
import { Loader2, Minus, Plus, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { base44 } from "@/api/base44Client";

const UNIT_PRICE_ENTREPRISE = 20000;
const PRICE_PARTICULIER = 5000;

export default function SubscribeDialog({ plan, open, onOpenChange, onSuccess, defaultCount = 1, alreadyCovered = 0 }) {
  const [accountName, setAccountName] = useState("");
  const [phone, setPhone] = useState("");
  const [provider, setProvider] = useState("airtel");
  const [companiesCount, setCompaniesCount] = useState(defaultCount);
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      setAccountName("");
      setPhone("");
      setProvider("airtel");
      setCompaniesCount(defaultCount);
    }
  }, [open, defaultCount]);

  if (!plan) return null;
  const isEnt = plan.type === "entreprise";
  const unitPrice = plan.unitPrice || UNIT_PRICE_ENTREPRISE;
  const isUpgrade = alreadyCovered > 0;
  // En mise à niveau (ajout d'entreprise), le compteur est figé au nouveau total
  // et l'on ne facture que l'entreprise supplémentaire (les autres sont déjà payées).
  const newTotal = isUpgrade ? defaultCount : companiesCount;
  const billableUnits = isEnt ? Math.max(0, newTotal - alreadyCovered) : 1;
  const fullAmount = isEnt
    ? unitPrice * billableUnits
    : plan.baseAmount || PRICE_PARTICULIER;
  // Réduction parrainage : 20 % les 6 premiers mois (validée côté serveur).
  const hasRef = typeof localStorage !== "undefined" && !!localStorage.getItem("jpm_ref");
  const discount = hasRef ? Math.round(fullAmount * 0.8) : fullAmount;
  const amount = discount;

  const setCount = (v) => setCompaniesCount(Math.max(1, Math.min(20, v)));

  const handlePay = async (e) => {
    e.preventDefault();
    if (!accountName.trim()) {
      toast({ title: "Nom requis", description: "Indiquez le nom figurant sur votre compte Mobile Money.", variant: "destructive" });
      return;
    }
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 6) {
      toast({ title: "Numéro invalide", description: "Entrez un numéro d'au moins 6 chiffres (ex. 60367591).", variant: "destructive" });
      return;
    }
    const fullPhone = "+241" + digits;
    setSubmitting(true);
    try {
      const res = await base44.functions.invoke('processPayment', {
        account_name: accountName.trim(),
        phoneNumber: fullPhone,
        provider,
        account_type: plan.type,
        companies_count: isEnt ? newTotal : 1,
        already_covered: alreadyCovered,
        referral_code: (typeof localStorage !== "undefined" ? localStorage.getItem("jpm_ref") : "") || "",
      });
      if (res?.success) {
        try {
          const patch = { account_type: plan.type };
          await base44.auth.updateMe(patch);
        } catch { /* non-fatal */ }
        toast({ title: "Paiement validé", description: "Votre abonnement est actif. Bienvenue !" });
        onSuccess?.();
      } else {
        toast({ title: "Échec du paiement", description: res?.error || "Erreur inconnue", variant: "destructive" });
      }
    } catch (err) {
      const body = err && err.response && err.response.data;
      const msg = (body && body.error) || (err && err.message) || "Erreur réseau";
      toast({
        title: "Échec du paiement",
        description: /invoke|undefined|Request failed/i.test(msg)
          ? "Erreur technique : la fonction de paiement est injoignable. Réessayez plus tard."
          : msg,
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Abonnement {plan.label}</DialogTitle>
          <DialogDescription>
            {isEnt
              ? `${unitPrice.toLocaleString("fr-FR")} XAF par entreprise gérée.`
              : `Montant : ${amount.toLocaleString("fr-FR")} XAF — prélevés sur votre Mobile Money.`}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handlePay} className="space-y-4">
          {isEnt && !isUpgrade && (
            <div className="space-y-2">
              <Label>Nombre d'entreprises à gérer</Label>
              <div className="flex items-center gap-3">
                <button type="button" onClick={() => setCount(companiesCount - 1)} className="no-select-tap min-touch p-2 rounded-lg border border-input"><Minus className="w-4 h-4" /></button>
                <span className="font-display text-xl w-10 text-center">{companiesCount}</span>
                <button type="button" onClick={() => setCount(companiesCount + 1)} className="no-select-tap min-touch p-2 rounded-lg border border-input"><Plus className="w-4 h-4" /></button>
                <span className="ml-auto text-sm text-muted-foreground">1 = {unitPrice.toLocaleString("fr-FR")} XAF</span>
              </div>
            </div>
          )}
          {isEnt && isUpgrade && (
            <div className="rounded-lg border border-input bg-secondary/40 px-3 py-2 text-sm space-y-1">
              <div className="font-medium">Ajout d'une entreprise</div>
              <div className="text-muted-foreground">Total couvert après paiement : {newTotal} entreprise(s) · coût de la nouvelle entreprise : {unitPrice.toLocaleString("fr-FR")} XAF.</div>
            </div>
          )}
          <div className="space-y-1">
            <div className="text-sm font-medium">{`Total : ${amount.toLocaleString("fr-FR")} XAF`}</div>
            {hasRef && (
              <p className="text-xs text-primary flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Parrainage : 20 % de réduction les 6 premiers mois.
                {!isEnt && null}
              </p>
            )}
          </div>
          <div className="space-y-2">
            <Label>Pays</Label>
            <Select value="GA" disabled>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="GA">Gabon (+241)</SelectItem></SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="sub-name">Nom sur le compte Mobile Money</Label>
            <Input id="sub-name" value={accountName} onChange={(e) => setAccountName(e.target.value)} placeholder="Ex. Jean Dupont" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sub-phone">Numéro Mobile Money</Label>
            <div className="flex items-center gap-2">
              <span className="px-3 h-9 inline-flex items-center rounded-md border border-input bg-muted text-sm shrink-0">+241</span>
              <Input id="sub-phone" type="tel" inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Ex. 074 12 34 56" />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Opérateur</Label>
            <Select value={provider} onValueChange={setProvider}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="airtel">Airtel Money</SelectItem>
                <SelectItem value="moov">Moov Money</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>Annuler</Button>
            <Button type="submit" disabled={submitting} className={isEnt ? "bg-accent text-accent-foreground hover:bg-accent/90" : ""}>
              {submitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Traitement…</> : `Payer ${amount.toLocaleString("fr-FR")} XAF`}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}