import React, { useState } from "react";
import { ChevronDown, ChevronUp, CheckCircle2, Trash2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { buildSchedule } from "@/lib/loanMath";
import { formatCurrency, formatDateFr } from "@/lib/format";
import { periodLabel, customOf } from "@/lib/periods";

export default function LoanItem({ loan, payments, onPay, onDelete, payingId, delId, setDelId }) {
  const [open, setOpen] = useState(false);
  const schedule = buildSchedule(loan.principal, loan.interest_rate, loan.term_periods, loan.interest_type);
  const made = loan.payments_made || 0;
  const progress = loan.term_periods > 0 ? Math.min(100, Math.round((made / loan.term_periods) * 100)) : 0;
  const isDone = loan.status === "rembourse" || made >= loan.term_periods;
  const next = loan.payments_made < schedule.length ? schedule[loan.payments_made] : null;

  return (
    <div className="bg-card border border-border rounded-2xl p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-medium truncate">{loan.name}</p>
            {isDone && <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />}
          </div>
          <p className="text-xs text-muted-foreground">
            {formatCurrency(loan.principal, "XAF")} · {loan.interest_rate}% / {periodLabel(loan.frequency, customOf(loan))} · {loan.interest_type === "simple" ? "intérêts simples" : "composés"} · {loan.term_periods} échéances
          </p>
        </div>
        <button onClick={() => setDelId(loan)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
      </div>

      <div className="grid grid-cols-3 gap-2 mt-3 text-center">
        <div className="rounded-lg bg-secondary p-2"><p className="text-[11px] text-muted-foreground">Échéance</p><p className="text-sm font-medium">{formatCurrency(loan.monthly_payment, "XAF")}</p></div>
        <div className="rounded-lg bg-secondary p-2"><p className="text-[11px] text-muted-foreground">Solde restant</p><p className="text-sm font-medium">{formatCurrency(loan.remaining_balance, "XAF")}</p></div>
        <div className="rounded-lg bg-secondary p-2"><p className="text-[11px] text-muted-foreground">Prochaine</p><p className="text-sm font-medium">{isDone ? "—" : formatDateFr(loan.next_payment_date)}</p></div>
      </div>

      <div className="mt-3">
        <div className="flex justify-between text-xs text-muted-foreground mb-1"><span>{made}/{loan.term_periods} réglées</span><span>{progress}%</span></div>
        <div className="h-2 rounded-full bg-secondary overflow-hidden"><div className="h-full bg-primary transition-all" style={{ width: `${progress}%` }} /></div>
      </div>

      <div className="flex items-center gap-2 mt-3">
        {!isDone ? (
          <Button size="sm" className="flex-1" onClick={() => onPay(loan)} disabled={payingId === loan.id}>
            {payingId === loan.id && <Loader2 className="w-4 h-4 mr-2 animate-spin" />} Enregistrer l'échéance n°{made + 1}
          </Button>
        ) : (
          <p className="text-sm text-primary flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> Emprunt remboursé</p>
        )}
        <Button size="sm" variant="outline" onClick={() => setOpen((o) => !o)}>{open ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}Détails</Button>
      </div>

      {open && (
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-xs">
            <thead><tr className="text-muted-foreground text-left">
              <th className="py-1 pr-2">#</th><th className="py-1 pr-2">Échéance</th><th className="py-1 pr-2">Intérêts</th><th className="py-1 pr-2">Capital</th><th className="py-1">Solde</th>
            </tr></thead>
            <tbody>
              {schedule.map((row) => {
                const paid = row.n <= made;
                return (
                  <tr key={row.n} className={paid ? "text-muted-foreground line-through" : ""}>
                    <td className="py-1 pr-2">{row.n}</td>
                    <td className="py-1 pr-2">{formatCurrency(row.payment, "XAF")}</td>
                    <td className="py-1 pr-2">{formatCurrency(row.interest, "XAF")}</td>
                    <td className="py-1 pr-2">{formatCurrency(row.principal, "XAF")}</td>
                    <td className="py-1">{formatCurrency(row.balance, "XAF")}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <AlertDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Supprimer cet emprunt ?</AlertDialogTitle><AlertDialogDescription>« {delId?.name} » et son historique seront supprimés.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Annuler</AlertDialogCancel><AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={(e) => { e.preventDefault(); onDelete(delId); }}>Supprimer</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}