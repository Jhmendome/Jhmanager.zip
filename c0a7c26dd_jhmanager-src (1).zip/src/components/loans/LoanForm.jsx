import React, { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { LOAN_INTEREST_TYPES, computePayment, totalToRepay, totalInterest } from "@/lib/loanMath";
import PeriodPicker from "@/components/common/PeriodPicker";
import { formatCurrency } from "@/lib/format";

const empty = { name: "", principal: "", interest_rate: "", interest_type: "compose", frequency: "mois", customCount: "", customUnit: "jour", term_periods: "", start_date: new Date().toISOString().slice(0, 10), description: "" };

export default function LoanForm({ open, onOpenChange, onSubmit, loading }) {
  const [form, setForm] = useState(empty);

  useEffect(() => { if (open) setForm(empty); }, [open]);

  const P = parseFloat(form.principal) || 0;
  const r = parseFloat(form.interest_rate) || 0;
  const n = parseInt(form.term_periods, 10) || 0;
  const payment = computePayment(P, r, n, form.interest_type);
  const total = totalToRepay(P, r, n, form.interest_type);
  const interest = totalInterest(P, r, n, form.interest_type);

  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || P <= 0 || n <= 0 || !form.start_date) return;
    onSubmit({
      name: form.name.trim(),
      principal: P,
      interest_rate: r,
      interest_type: form.interest_type,
      frequency: form.frequency,
      custom_count: form.frequency === "personnalise" ? (parseInt(form.customCount, 10) || 0) : null,
      custom_unit: form.frequency === "personnalise" ? form.customUnit : null,
      term_periods: n,
      start_date: form.start_date,
      monthly_payment: payment,
      total_to_repay: total,
      total_interest: interest,
      remaining_balance: P,
      payments_made: 0,
      next_payment_date: form.start_date,
      status: "en_cours",
      description: form.description.trim(),
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">Nouvel emprunt</DialogTitle>
          <DialogDescription>Définissez le capital, le taux d'intérêt et la période. Le suivi s'actualise à chaque versement.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="space-y-2"><Label>Libellé</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Ex. Prêt moto, crédit étudiant…" required /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2"><Label>Capital (XAF)</Label><Input type="number" min="0" value={form.principal} onChange={(e) => setForm({ ...form, principal: e.target.value })} required /></div>
            <div className="space-y-2"><Label>Taux / période (%)</Label><Input type="number" min="0" step="0.01" value={form.interest_rate} onChange={(e) => setForm({ ...form, interest_rate: e.target.value })} required /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2"><Label>Type d'intérêt</Label>
              <Select value={form.interest_type} onValueChange={(v) => setForm({ ...form, interest_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{LOAN_INTEREST_TYPES.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <PeriodPicker
                period={form.frequency}
                customCount={form.customCount}
                customUnit={form.customUnit}
                onChange={({ period, customCount, customUnit }) => setForm({ ...form, frequency: period, customCount, customUnit })}
                label="Périodicité"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2"><Label>Nb d'échéances</Label><Input type="number" min="1" value={form.term_periods} onChange={(e) => setForm({ ...form, term_periods: e.target.value })} required /></div>
            <div className="space-y-2"><Label>1ʳᵉ échéance</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} required /></div>
          </div>
          {payment > 0 && (
            <div className="rounded-xl bg-secondary p-3 text-sm space-y-1">
              <p>Échéance : <span className="font-medium">{formatCurrency(payment, "XAF")}</span></p>
              <p>Total à rembourser : <span className="font-medium">{formatCurrency(total, "XAF")}</span></p>
              <p className="text-muted-foreground">Dont intérêts : {formatCurrency(interest, "XAF")}</p>
            </div>
          )}
          <div className="space-y-2"><Label>Description</Label><Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          <DialogFooter><Button type="submit" className="w-full" disabled={loading}>{loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Créer l'emprunt</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}