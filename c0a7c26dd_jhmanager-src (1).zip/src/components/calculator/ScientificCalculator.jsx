import React, { useState } from "react";
import { Delete } from "lucide-react";
import { evalExpr, formatNumber } from "@/lib/mathEval";

const KEYS = [
  ["7", "8", "9", "/", "C"],
  ["4", "5", "6", "*", "("],
  ["1", "2", "3", "-", ")"],
  ["0", ".", "^", "+", "="],
  ["sin(", "cos(", "tan(", "sqrt(", "pi"],
  ["ln(", "log(", "abs(", "exp(", "e"],
];

export default function ScientificCalculator({ scope = {} }) {
  const [expr, setExpr] = useState("");
  const [result, setResult] = useState("");
  const [history, setHistory] = useState([]);

  const press = (k) => {
    if (k === "C") { setExpr(""); setResult(""); return; }
    if (k === "=") { compute(); return; }
    setExpr((e) => e + k);
  };

  const compute = () => {
    if (!expr.trim()) return;
    try {
      const r = evalExpr(expr, scope);
      if (!isFinite(r)) { setResult("Erreur"); return; }
      const out = formatNumber(r);
      setResult(out);
      setHistory((h) => [{ expr, result: out, id: Date.now() }, ...h].slice(0, 8));
    } catch { setResult("Erreur"); }
  };

  const backspace = () => setExpr((e) => e.slice(0, -1));

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4 max-w-2xl">
      <div className="space-y-2">
        <div className="min-h-[2.5rem] text-right text-2xl font-mono break-all">{expr || "0"}</div>
        <div className="min-h-[2rem] text-right text-xl font-mono text-accent">{result && "= " + result}</div>
      </div>
      <div className="grid grid-cols-5 gap-2">
        {KEYS.flat().map((k) => (
          <button
            key={k}
            onClick={() => press(k)}
            className={`no-select-tap min-touch rounded-xl text-sm font-mono transition-colors ${
              k === "=" ? "bg-primary text-primary-foreground" : "bg-secondary hover:bg-secondary/70"
            }`}
          >
            {k}
          </button>
        ))}
      </div>
      <div className="flex gap-2">
        <button onClick={backspace} className="no-select-tap min-touch flex-1 rounded-xl bg-secondary hover:bg-secondary/70 flex items-center justify-center gap-1 text-sm">
          <Delete className="w-4 h-4" /> Effacer
        </button>
      </div>
      {history.length > 0 && (
        <div className="space-y-1 pt-2 border-t border-border">
          <p className="text-xs text-muted-foreground">Historique</p>
          {history.map((h) => (
            <button
              key={h.id}
              onClick={() => { setExpr(h.expr); setResult(h.result); }}
              className="block w-full text-left text-sm font-mono py-1 hover:bg-secondary rounded px-2"
            >
              {h.expr} = <span className="text-accent">{h.result}</span>
            </button>
          ))}
        </div>
      )}
      <p className="text-xs text-muted-foreground">
        Fonctions : sin, cos, tan, sqrt, ln, log, exp, abs, ^, pi, e. Les grandeurs que vous créez dans l'onglet « Grandeurs » sont aussi utilisables ici via leur nom.
      </p>
    </div>
  );
}