import React, { useState, useMemo } from "react";
import { TrendingUp, Percent, Coins } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatCurrency } from "@/lib/format";

export default function QuickTools() {
  const [cost, setCost] = useState("");
  const [price, setPrice] = useState("");
  const [ht, setHt] = useState("");
  const [rate, setRate] = useState("18");
  const [loan, setLoan] = useState("");
  const [apr, setApr] = useState("");
  const [months, setMonths] = useState("12");

  const margin = useMemo(() => {
    const c = parseFloat(cost) || 0, p = parseFloat(price) || 0;
    const m = p - c;
    return { m, pct: p > 0 ? (m / p) * 100 : 0 };
  }, [cost, price]);

  const tva = useMemo(() => {
    const h = parseFloat(ht) || 0, r = parseFloat(rate) || 0;
    const tax = h * (r / 100);
    return { tax, ttc: h + tax };
  }, [ht, rate]);

  const loanCalc = useMemo(() => {
    const P = parseFloat(loan) || 0;
    const r = (parseFloat(apr) || 0) / 100 / 12;
    const n = parseInt(months, 10) || 0;
    if (P <= 0 || n <= 0) return { monthly: 0, total: 0, interest: 0 };
    const monthly = r === 0 ? P / n : (P * r) / (1 - Math.pow(1 + r, -n));
    const total = monthly * n;
    return { monthly, total, interest: total - P };
  }, [loan, apr, months]);

  return (
    <div className="space-y-4 max-w-2xl">
      <section className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <h2 className="font-display text-lg flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Marge / Rentabilité</h2>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1"><Label>Coût unitaire (XAF)</Label><Input type="number" min="0" value={cost} onChange={(e) => setCost(e.target.value)} /></div>
          <div className="space-y-1"><Label>Prix de vente (XAF)</Label><Input type="number" min="0" value={price} onChange={(e) => setPrice(e.target.value)} /></div>
        </div>
        <div className="text-sm space-y-1">
          <p>Marge : <span className="font-medium">{formatCurrency(margin.m, "XAF")}</span></p>
          <p>Taux de marge : <span className="font-medium">{margin.pct.toFixed(1)} %</span></p>
        </div>
      </section>

      <section className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <h2 className="font-display text-lg flex items-center gap-2"><Percent className="w-4 h-4" /> TVA</h2>
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1"><Label>Montant HT (XAF)</Label><Input type="number" min="0" value={ht} onChange={(e) => setHt(e.target.value)} /></div>
          <div className="space-y-1"><Label>Taux TVA (%)</Label><Input type="number" min="0" value={rate} onChange={(e) => setRate(e.target.value)} /></div>
        </div>
        <div className="text-sm space-y-1">
          <p>TVA : <span className="font-medium">{formatCurrency(tva.tax, "XAF")}</span></p>
          <p>Montant TTC : <span className="font-medium">{formatCurrency(tva.ttc, "XAF")}</span></p>
        </div>
      </section>

      <section className="bg-card border border-border rounded-2xl p-5 space-y-4">
        <h2 className="font-display text-lg flex items-center gap-2"><Coins className="w-4 h-4" /> Prêt / Remboursement</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="space-y-1"><Label>Montant (XAF)</Label><Input type="number" min="0" value={loan} onChange={(e) => setLoan(e.target.value)} /></div>
          <div className="space-y-1"><Label>Taux annuel (%)</Label><Input type="number" min="0" value={apr} onChange={(e) => setApr(e.target.value)} /></div>
          <div className="space-y-1"><Label>Durée (mois)</Label><Input type="number" min="1" value={months} onChange={(e) => setMonths(e.target.value)} /></div>
        </div>
        <div className="text-sm space-y-1">
          <p>Mensualité : <span className="font-medium">{formatCurrency(loanCalc.monthly, "XAF")}</span></p>
          <p>Coût total : <span className="font-medium">{formatCurrency(loanCalc.total, "XAF")}</span></p>
          <p>Intérêts : <span className="font-medium">{formatCurrency(loanCalc.interest, "XAF")}</span></p>
        </div>
      </section>
    </div>
  );
}