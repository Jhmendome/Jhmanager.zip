import React, { useMemo, useState } from "react";
import { Plus, Trash2, Pencil, FunctionSquare, ChevronDown, ChevronRight } from "lucide-react";
import { LineChart, Line, AreaChart, Area, BarChart, Bar, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { sanitizeName, sampleFunction, studyFunction, formatNumber, computeGrandeurs } from "@/lib/mathEval";

const PLOT_TYPES = [
  { value: "courbe", label: "Courbe" },
  { value: "aire", label: "Aire" },
  { value: "histogramme", label: "Histogramme" },
  { value: "nuage", label: "Nuage de points" },
];
const empty = { name: "", label: "", expression: "", unit: "", plot_variable: "x", plot_x_min: "-10", plot_x_max: "10", plot_steps: "100", plot_type: "courbe" };

const COLORS = {
  primary: "hsl(var(--primary))",
  accent: "hsl(var(--accent))",
  border: "hsl(var(--border))",
  muted: "hsl(var(--muted-foreground))",
};

function Chart({ f, scope }) {
  const variable = f.plot_variable || "x";
  const xMin = Number(f.plot_x_min) || 0;
  const xMax = Number(f.plot_x_max) || 10;
  const steps = f.plot_type === "histogramme" ? Math.min(24, f.plot_steps || 24) : Math.min(300, f.plot_steps || 100);
  const pts = useMemo(
    () => sampleFunction(f.expression, variable, xMin, xMax, steps, scope),
    [f.expression, variable, xMin, xMax, steps, scope]
  );
  const valid = pts.filter((p) => p.y != null);
  const tip = ({ active, payload }) =>
    active && payload?.length ? (
      <div className="bg-card border border-border rounded-lg px-2 py-1 text-xs">
        {variable}: {payload[0].payload.x} · f: {payload[0].payload.y}
      </div>
    ) : null;
  const axisProps = { domain: [xMin, xMax], type: "number", allowDecimals: true };
  const tick = { fontSize: 11, fill: COLORS.muted };

  if (valid.length === 0)
    return <p className="text-sm text-muted-foreground py-6 text-center">Aucune valeur finie sur cet intervalle.</p>;

  let chart;
  if (f.plot_type === "aire") {
    chart = (
      <AreaChart data={pts}>
        <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
        <XAxis dataKey="x" {...axisProps} tick={tick} />
        <YAxis tick={tick} />
        <Tooltip content={tip} />
        <ReferenceLine y={0} stroke={COLORS.muted} />
        <Area type="monotone" dataKey="y" stroke={COLORS.primary} fill={COLORS.primary} fillOpacity={0.15} dot={false} connectNulls />
      </AreaChart>
    );
  } else if (f.plot_type === "histogramme") {
    chart = (
      <BarChart data={pts}>
        <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
        <XAxis dataKey="x" {...axisProps} tick={tick} />
        <YAxis tick={tick} />
        <Tooltip content={tip} />
        <ReferenceLine y={0} stroke={COLORS.muted} />
        <Bar dataKey="y" fill={COLORS.accent} />
      </BarChart>
    );
  } else if (f.plot_type === "nuage") {
    chart = (
      <ScatterChart>
        <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
        <XAxis dataKey="x" {...axisProps} tick={tick} />
        <YAxis dataKey="y" tick={tick} />
        <Tooltip content={tip} />
        <Scatter data={pts} fill={COLORS.primary} />
      </ScatterChart>
    );
  } else {
    chart = (
      <LineChart data={pts}>
        <CartesianGrid strokeDasharray="3 3" stroke={COLORS.border} />
        <XAxis dataKey="x" {...axisProps} tick={tick} />
        <YAxis tick={tick} />
        <Tooltip content={tip} />
        <ReferenceLine y={0} stroke={COLORS.muted} />
        <Line type="monotone" dataKey="y" stroke={COLORS.primary} dot={false} connectNulls strokeWidth={2} />
      </LineChart>
    );
  }

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">{chart}</ResponsiveContainer>
    </div>
  );
}

export default function FonctionsPanel({ items, metrics, reload }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [showTable, setShowTable] = useState({});

  const grandeurs = items.filter((i) => i.kind === "grandeur");
  const fonctions = items.filter((i) => i.kind === "fonction");
  const scope = useMemo(() => computeGrandeurs(grandeurs, metrics || {}), [grandeurs, metrics]);

  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (f) => {
    setEditing(f);
    setForm({
      name: f.name, label: f.label, expression: f.expression || "", unit: f.unit || "",
      plot_variable: f.plot_variable || "x",
      plot_x_min: String(f.plot_x_min ?? -10),
      plot_x_max: String(f.plot_x_max ?? 10),
      plot_steps: String(f.plot_steps ?? 100),
      plot_type: f.plot_type || "courbe",
    });
    setOpen(true);
  };

  const save = async () => {
    const name = sanitizeName(form.name);
    if (!name || !form.expression) { toast({ title: "Nom et formule requis", variant: "destructive" }); return; }
    const payload = {
      name, label: form.label || name, kind: "fonction", expression: form.expression, unit: form.unit,
      plot_variable: form.plot_variable || "x",
      plot_x_min: Number(form.plot_x_min) || 0,
      plot_x_max: Number(form.plot_x_max) || 10,
      plot_steps: Math.max(2, Math.min(500, Number(form.plot_steps) || 100)),
      plot_type: form.plot_type,
    };
    if (payload.plot_x_max <= payload.plot_x_min) { toast({ title: "x_max doit être > x_min", variant: "destructive" }); return; }
    try {
      if (editing) await base44.entities.CalcDefinition.update(editing.id, payload);
      else await base44.entities.CalcDefinition.create(payload);
      toast({ title: "Fonction enregistrée" });
      setOpen(false); reload();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const remove = async (f) => {
    try { await base44.entities.CalcDefinition.delete(f.id); reload(); }
    catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-display text-lg flex items-center gap-2"><FunctionSquare className="w-4 h-4" /> Fonctions</h2>
        <Button onClick={openNew} size="sm"><Plus className="w-4 h-4 mr-1" /> Nouvelle</Button>
      </div>

      {grandeurs.length > 0 && (
        <p className="text-xs text-muted-foreground">Astuce : vos fonctions peuvent référencer vos grandeurs (ex. <span className="font-mono">CA * x</span>).</p>
      )}

      {fonctions.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground text-sm">Aucune fonction. Créez-en une pour tracer et étudier une courbe.</div>
      ) : (
        <div className="space-y-4">
          {fonctions.map((f) => {
            const study = studyFunction(f.expression, f.plot_variable || "x", Number(f.plot_x_min) || 0, Number(f.plot_x_max) || 10, 200, scope);
            const openTbl = showTable[f.id];
            return (
              <div key={f.id} className="bg-card border border-border rounded-2xl p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{f.label} <span className="text-xs text-muted-foreground font-mono">({f.name})</span></p>
                    <p className="text-sm font-mono text-accent truncate">f({f.plot_variable || "x"}) = {f.expression}{f.unit ? ` [${f.unit}]` : ""}</p>
                    <p className="text-xs text-muted-foreground">[{f.plot_x_min} ; {f.plot_x_max}] · {PLOT_TYPES.find((p) => p.value === f.plot_type)?.label}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button onClick={() => openEdit(f)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                    <button onClick={() => remove(f)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>

                <Chart f={f} scope={scope} />

                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="bg-secondary rounded-lg p-2"><p className="text-muted-foreground">Minimum</p><p className="font-mono font-medium">{formatNumber(study.min)} {study.min != null && `@ ${formatNumber(study.minX)}`}</p></div>
                  <div className="bg-secondary rounded-lg p-2"><p className="text-muted-foreground">Maximum</p><p className="font-mono font-medium">{formatNumber(study.max)} {study.max != null && `@ ${formatNumber(study.maxX)}`}</p></div>
                  <div className="bg-secondary rounded-lg p-2"><p className="text-muted-foreground">Dérivée (milieu)</p><p className="font-mono font-medium">{formatNumber(study.derivMid)}</p></div>
                </div>

                <div className="text-xs">
                  <p className="text-muted-foreground">Zéros détectés : {study.roots.length ? study.roots.map((r) => formatNumber(r)).join(", ") : "aucun"}</p>
                </div>

                <button onClick={() => setShowTable((s) => ({ ...s, [f.id]: !s[f.id] }))} className="no-select-tap flex items-center gap-1 text-xs text-primary">
                  {openTbl ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />} Tableau de valeurs
                </button>
                {openTbl && (
                  <div className="border border-border rounded-lg overflow-hidden text-xs">
                    <div className="grid grid-cols-11 bg-secondary font-mono">
                      <div className="px-2 py-1">{f.plot_variable || "x"}</div>
                      {study.table.map((p, i) => <div key={i} className="px-1 py-1 text-right">{formatNumber(p.x)}</div>)}
                    </div>
                    <div className="grid grid-cols-11 border-t border-border font-mono">
                      <div className="px-2 py-1">f</div>
                      {study.table.map((p, i) => <div key={i} className="px-1 py-1 text-right">{formatNumber(p.y)}</div>)}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Modifier la fonction" : "Nouvelle fonction"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Nom (identifiant)</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="f, demande…" /></div>
              <div className="space-y-1"><Label>Libellé</Label><Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Coût total" /></div>
            </div>
            <div className="space-y-1"><Label>Formule f({form.plot_variable || "x"}) =</Label><Input value={form.expression} onChange={(e) => setForm({ ...form, expression: e.target.value })} placeholder="x^2 + 3*x - 5" /></div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="space-y-1"><Label>Variable</Label><Input value={form.plot_variable} onChange={(e) => setForm({ ...form, plot_variable: e.target.value })} placeholder="x" /></div>
              <div className="space-y-1"><Label>x min</Label><Input type="number" value={form.plot_x_min} onChange={(e) => setForm({ ...form, plot_x_min: e.target.value })} /></div>
              <div className="space-y-1"><Label>x max</Label><Input type="number" value={form.plot_x_max} onChange={(e) => setForm({ ...form, plot_x_max: e.target.value })} /></div>
              <div className="space-y-1"><Label>Pas</Label><Input type="number" min="2" value={form.plot_steps} onChange={(e) => setForm({ ...form, plot_steps: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Représentation</Label>
                <Select value={form.plot_type} onValueChange={(v) => setForm({ ...form, plot_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PLOT_TYPES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1"><Label>Unité</Label><Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} placeholder="XAF, kg…" /></div>
            </div>
          </div>
          <DialogFooter><Button onClick={save}>Enregistrer</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}