import React, { useMemo, useState } from "react";
import { Plus, Trash2, Pencil, Link2, Sigma } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import { sanitizeName, formatNumber, computeGrandeurs } from "@/lib/mathEval";
import { METRIC_GROUPS, METRIC_BY_KEY } from "@/lib/calcSources";
import { formatCurrency } from "@/lib/format";

const empty = { name: "", label: "", expression: "", unit: "", value: "", source_type: "manual", source_key: "" };

export default function GrandeursPanel({ items, metrics, reload }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);

  const grandeurs = items.filter((i) => i.kind === "grandeur");
  const scope = useMemo(() => computeGrandeurs(grandeurs, metrics), [grandeurs, metrics]);

  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (g) => {
    setEditing(g);
    setForm({ name: g.name, label: g.label, expression: g.expression || "", unit: g.unit || "", value: g.value ?? "", source_type: g.source_type || "manual", source_key: g.source_key || "" });
    setOpen(true);
  };

  const save = async () => {
    const name = sanitizeName(form.name);
    if (!name) { toast({ title: "Nom requis", variant: "destructive" }); return; }
    const payload = {
      name, label: form.label || name, kind: "grandeur",
      expression: form.expression, unit: form.unit,
      value: form.source_type === "manual" && !form.expression ? (parseFloat(form.value) || 0) : 0,
      source_type: form.source_type, source_key: form.source_type === "manual" ? "" : form.source_key,
    };
    if (form.source_type !== "manual" && !form.source_key) { toast({ title: "Choisir un indicateur", variant: "destructive" }); return; }
    try {
      if (editing) await base44.entities.CalcDefinition.update(editing.id, payload);
      else await base44.entities.CalcDefinition.create(payload);
      toast({ title: "Grandeur enregistrée" });
      setOpen(false); reload();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const remove = async (g) => {
    try { await base44.entities.CalcDefinition.delete(g.id); reload(); }
    catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const importMetric = async (m) => {
    const name = sanitizeName(m.key);
    try {
      await base44.entities.CalcDefinition.create({ name, label: m.label, kind: "grandeur", source_type: m.source, source_key: m.key, unit: m.unit });
      toast({ title: `${m.label} importée` });
      reload();
    } catch { toast({ title: "Erreur", variant: "destructive" }); }
  };

  const displayVal = (g) => {
    const v = scope[g.name];
    if (v == null || !isFinite(v)) return "—";
    return g.unit === "XAF" ? formatCurrency(v, "XAF") : formatNumber(v);
  };

  const metricValue = (m) => {
    const v = metrics?.[m.key];
    if (v == null) return "—";
    return m.unit === "XAF" ? formatCurrency(v, "XAF") : String(v);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-display text-lg flex items-center gap-2"><Sigma className="w-4 h-4" /> Grandeurs</h2>
        <Button onClick={openNew} size="sm"><Plus className="w-4 h-4 mr-1" /> Nouvelle</Button>
      </div>

      <div className="bg-card border border-border rounded-2xl p-4 space-y-3">
        <p className="text-sm font-medium flex items-center gap-2"><Link2 className="w-4 h-4 text-accent" /> Importer depuis vos sections</p>
        {METRIC_GROUPS.map((grp) => (
          <div key={grp.source} className="space-y-1.5">
            <p className="text-xs text-muted-foreground">{grp.label}</p>
            <div className="flex flex-wrap gap-2">
              {grp.metrics.map((m) => (
                <button
                  key={m.key}
                  onClick={() => importMetric(m)}
                  className="no-select-tap text-xs px-3 py-1.5 rounded-lg border border-border bg-secondary hover:bg-secondary/70 flex items-center gap-1.5"
                >
                  <Plus className="w-3 h-3" /> {m.label}
                  <span className="text-muted-foreground">: {metricValue(m)}</span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {grandeurs.length === 0 ? (
        <div className="text-center py-10 text-muted-foreground text-sm">Aucune grandeur. Créez-en une ou importez un indicateur ci-dessus.</div>
      ) : (
        <div className="space-y-2">
          {grandeurs.map((g) => (
            <div key={g.id} className="bg-card border border-border rounded-xl p-3 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{g.label} <span className="text-xs text-muted-foreground font-mono">({g.name})</span></p>
                <p className="text-xs text-muted-foreground truncate">
                  {g.source_type === "manual" ? (g.expression ? `= ${g.expression}` : "valeur saisie") : `lié · ${METRIC_BY_KEY[g.source_key]?.label || g.source_key}`}
                  {g.unit ? ` · ${g.unit}` : ""}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-sm font-mono font-medium">{displayVal(g)}</span>
                <button onClick={() => openEdit(g)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-secondary"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => remove(g)} className="no-select-tap min-touch p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Modifier la grandeur" : "Nouvelle grandeur"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1"><Label>Nom (identifiant)</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="CA, prix_unitaire…" /></div>
              <div className="space-y-1"><Label>Libellé</Label><Input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} placeholder="Chiffre d'affaires" /></div>
            </div>
            <div className="space-y-1"><Label>Source</Label>
              <Select value={form.source_type} onValueChange={(v) => setForm({ ...form, source_type: v, source_key: "", expression: "" })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="manual">Manuelle (valeur ou formule)</SelectItem>
                  {METRIC_GROUPS.map((g) => <SelectItem key={g.source} value={g.source}>{g.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {form.source_type !== "manual" ? (
              <div className="space-y-1"><Label>Indicateur</Label>
                <Select value={form.source_key} onValueChange={(v) => setForm({ ...form, source_key: v })}>
                  <SelectTrigger><SelectValue placeholder="Choisir…" /></SelectTrigger>
                  <SelectContent>
                    {(METRIC_GROUPS.find((g) => g.source === form.source_type)?.metrics || []).map((m) => (
                      <SelectItem key={m.key} value={m.key}>{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <>
                <div className="space-y-1"><Label>Formule (optionnel — utilise les autres grandeurs)</Label><Input value={form.expression} onChange={(e) => setForm({ ...form, expression: e.target.value })} placeholder="CA - couts" /></div>
                {!form.expression && <div className="space-y-1"><Label>Valeur</Label><Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} /></div>}
              </>
            )}
            <div className="space-y-1"><Label>Unité</Label><Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} placeholder="XAF, kg, …" /></div>
          </div>
          <DialogFooter><Button onClick={save}>Enregistrer</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}