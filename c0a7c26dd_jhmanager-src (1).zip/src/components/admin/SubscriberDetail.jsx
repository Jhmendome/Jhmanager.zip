import React, { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { base44 } from "@/api/base44Client";
import { Trash2, Loader2 } from "lucide-react";
import { formatCurrency, formatDateFr } from "@/lib/format";

function Info({ label, value }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-sm font-medium">{value}</p>
    </div>
  );
}

const accountTypeLabel = (u) =>
  u.accountType === "entreprise" ? "Entreprise (JBM)" : u.accountType === "particulier" ? "Particulier (JPM)" : "Non défini";

export default function SubscriberDetail({ user, subscriptions, open, onOpenChange }) {
  const [deleting, setDeleting] = useState(false);
  const { toast } = useToast();
  if (!user) return null;

  const removeSubscriber = async () => {
    if (!confirm(`Supprimer définitivement l'abonné ${user.email} ? Ses données seront effacées et il devra demander un réabonnement pour recréer un compte.`)) return;
    setDeleting(true);
    try {
      const res = await base44.functions.invoke('deleteSubscriber', { user_id: user.id });
      toast({ title: "Abonné supprimé", description: res?.userDeleted ? "Compte utilisateur supprimé." : "Données effacées (compte auth conservé)." });
      onOpenChange?.(false);
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    } finally {
      setDeleting(false);
    }
  };
  const mySubs = subscriptions.filter((s) => s.created_by_id === user.id);
  const totalPaid = mySubs.reduce((sum, s) => sum + (Number(s.amount) || 0), 0);
  const companies = mySubs.length ? Math.max(...mySubs.map((s) => Number(s.companies_count) || 1)) : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">{user.full_name || user.email}</DialogTitle>
          <DialogDescription>{user.email}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4 text-sm">
          <div className="grid grid-cols-2 gap-3">
            <Info label="Rôle" value={user.role} />
            <Info label="Type de compte" value={accountTypeLabel(user)} />
            <Info label="Entreprises" value={companies || "—"} />
            <Info label="Total payé" value={formatCurrency(totalPaid, "XAF")} />
            <Info label="Inscrit le" value={user.created_date ? formatDateFr(user.created_date) : "—"} />
          </div>

          <div>
            <p className="font-medium mb-2">Abonnements ({mySubs.length})</p>
            {mySubs.length === 0 ? (
              <p className="text-muted-foreground">Aucun abonnement enregistré.</p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {mySubs.map((s) => (
                  <div key={s.id} className="border border-border rounded-lg p-2 text-xs">
                    <div className="flex justify-between">
                      <span>{s.account_type === "entreprise" ? "Entreprise" : "Particulier"}</span>
                      <span className="font-medium">{formatCurrency(s.amount, "XAF")}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>{s.provider} · {s.status}</span>
                      <span>{s.paid_at ? formatDateFr(s.paid_at, true) : "—"}</span>
                    </div>
                    {Number(s.companies_count) > 0 && (
                      <p className="text-muted-foreground">{s.companies_count} entreprise(s)</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <p className="text-xs text-muted-foreground">
            Note : la consultation des conversations avec les agents IA nécessite une API admin
            côté plateforme (à venir). Le SDK actuel limite les conversations à l'utilisateur connecté.
          </p>

          <div className="border-t border-border pt-3">
            <Button variant="destructive" size="sm" onClick={removeSubscriber} disabled={deleting} className="flex items-center gap-1">
              {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Supprimer cet abonné
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}