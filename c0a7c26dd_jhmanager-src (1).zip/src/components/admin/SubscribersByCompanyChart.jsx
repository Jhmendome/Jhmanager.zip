import React, { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";

export default function SubscribersByCompanyChart({ data = [] }) {
  if (!data.length) {
    return (
      <div className="bg-card border border-border rounded-2xl p-5 sm:p-6">
        <h2 className="font-display text-lg mb-3">Abonnés JBM par nombre d'entreprises</h2>
        <p className="text-sm text-muted-foreground">Aucun abonné entreprise pour l'instant.</p>
      </div>
    );
  }
  return (
    <div className="bg-card border border-border rounded-2xl p-5 sm:p-6">
      <h2 className="font-display text-lg mb-4">Abonnés JBM par nombre d'entreprises</h2>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="companies" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
            <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
            <Tooltip />
            <Bar dataKey="count" name="Abonnés" fill="hsl(var(--chart-1))" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}