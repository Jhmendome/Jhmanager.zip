import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Flag, CheckCircle2, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { formatDateFr } from "@/lib/format";

const REASONS = {
  spam: "Spam",
  harcelement: "Harcèlement",
  contenu_inapproprie: "Contenu inapproprié",
  arnaque: "Arnaque",
  usurpation: "Usurpation",
  autre: "Autre",
};

export default function AdminReports() {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);

  const load = async () => {
    try {
      const list = await base44.entities.Report.list("-created_date", 200);
      setItems(list || []);
    } catch { setItems([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const markDone = async (r) => {
    setBusy(r.id);
    try {
      await base44.entities.Report.update(r.id, { status: "traite" });
      toast({ title: "Signalement traité" });
      load();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Flag className="w-5 h-5 text-accent" />
        <div>
          <h2 className="font-display text-lg">Signalements ({items.length})</h2>
          <p className="text-xs text-muted-foreground">Utilisateurs et groupes signalés dans la section collaboration.</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-6"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : items.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-4">Aucun signalement pour l'instant.</p>
      ) : (
        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {items.map((r) => (
            <div key={r.id} className="border border-border rounded-xl p-3 space-y-1">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-medium truncate">
                  {r.target_name || "Cible inconnue"}
                  <span className="text-xs text-muted-foreground ml-2">({r.target_type === "group" ? "Groupe" : "Utilisateur"})</span>
                </p>
                <span className={`text-[11px] px-2 py-0.5 rounded-full ${r.status === "traite" ? "bg-primary/15 text-primary" : "bg-accent/15 text-accent-foreground"}`}>
                  {r.status === "traite" ? "Traité" : "Nouveau"}
                </span>
              </div>
              <p className="text-xs text-muted-foreground">
                Raison : {REASONS[r.reason] || r.reason || "—"}
                {r.custom_reason && <span className="block mt-0.5">{r.custom_reason}</span>}
              </p>
              <p className="text-[11px] text-muted-foreground">{r.created_date ? formatDateFr(r.created_date, true) : "—"}</p>
              {r.status !== "traite" && (
                <Button size="sm" variant="outline" onClick={() => markDone(r)} disabled={busy === r.id} className="flex items-center gap-1">
                  {busy === r.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />} Marquer traité
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}