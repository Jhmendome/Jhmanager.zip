import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Lightbulb, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const CAT = { amelioration: "Amélioration", correction: "Correction", autre: "Autre" };

export default function AdminSuggestions() {
  const [loading, setLoading] = useState(false);
  const [groups, setGroups] = useState(null);
  const [totalUsers, setTotalUsers] = useState(0);
  const [error, setError] = useState("");

  const run = async () => {
    setLoading(true); setError("");
    try {
      const res = await base44.functions.invoke('analyzeSuggestions', {});
      if (res?.success) { setGroups(res.groups || []); setTotalUsers(res.totalUsers || 0); }
      else setError(res?.error || "Échec de l'analyse");
    } catch (e) { setError(e?.message || "Erreur"); }
    setLoading(false);
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-accent" />
          <div>
            <h2 className="font-display text-lg">Suggestions (synthèse IA)</h2>
            <p className="text-xs text-muted-foreground">L'IA regroupe les suggestions similaires en idées uniques.</p>
          </div>
        </div>
        <Button onClick={run} disabled={loading}>
          {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyse…</> : <><Lightbulb className="w-4 h-4 mr-2" /> Analyser</>}
        </Button>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}

      {groups && (
        <div className="space-y-2">
          {groups.length === 0 ? (
            <p className="text-sm text-muted-foreground">Aucune suggestion pour l'instant.</p>
          ) : (
            <>
              <p className="text-xs text-muted-foreground">{groups.length} idée(s) unique(s) · {totalUsers} utilisateur(s) distinct(s)</p>
              {groups.map((g, i) => (
                <div key={i} className="border border-border rounded-xl p-3">
                  <div className="flex items-start justify-between gap-3">
                    <p className="text-sm font-medium">{g.label}</p>
                    <div className="flex items-center gap-2 shrink-0 text-xs">
                      <span className="px-2 py-0.5 rounded-full bg-secondary">{CAT[g.category] || g.category}</span>
                      <span className="text-muted-foreground">{g.users} utilisateur(s)</span>
                      <span className="font-medium">{g.percentage}%</span>
                    </div>
                  </div>
                  {g.occurrences !== g.users && <p className="text-xs text-muted-foreground mt-1">{g.occurrences} occurrence(s) au total</p>}
                </div>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );
}