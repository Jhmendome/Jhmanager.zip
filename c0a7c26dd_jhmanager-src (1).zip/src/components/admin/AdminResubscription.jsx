import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { UserCheck, Check, X, Loader2, Clock, CheckCircle2, XCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { formatDateFr } from "@/lib/format";

const STATUS = {
  pending: { label: "En attente", icon: Clock, cls: "bg-accent/15 text-accent-foreground" },
  approved: { label: "Approuvée", icon: CheckCircle2, cls: "bg-primary/15 text-primary" },
  rejected: { label: "Refusée", icon: XCircle, cls: "bg-destructive/15 text-destructive" },
};

export default function AdminResubscription() {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);

  const load = async () => {
    try {
      const list = await base44.entities.ReSubscriptionRequest.list("-created_date", 200);
      setItems(list || []);
    } catch { setItems([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const decide = async (r, decision) => {
    setBusy(r.id);
    try {
      await base44.entities.ReSubscriptionRequest.update(r.id, { status: decision });
      if (decision === "approved") {
        try { await base44.entities.DeletedAccount.deleteMany({ email: r.email }); } catch { /* ignore */ }
      }
      toast({ title: decision === "approved" ? "Demande approuvée" : "Demande refusée" });
      load();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center gap-2">
        <UserCheck className="w-5 h-5 text-accent" />
        <div>
          <h2 className="font-display text-lg">Demandes de réabonnement ({items.length})</h2>
          <p className="text-xs text-muted-foreground">Abonnés supprimés souhaitant recréer un compte.</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-6"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
      ) : items.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-4">Aucune demande pour l'instant.</p>
      ) : (
        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {items.map((r) => {
            const st = STATUS[r.status] || STATUS.pending;
            return (
              <div key={r.id} className="border border-border rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{r.email}</p>
                    <p className="text-xs text-muted-foreground">{r.created_date ? formatDateFr(r.created_date, true) : "—"}</p>
                  </div>
                  <span className={`text-[11px] px-2 py-0.5 rounded-full flex items-center gap-1 ${st.cls}`}>
                    <st.icon className="w-3 h-3" /> {st.label}
                  </span>
                </div>
                {r.message && <p className="text-sm text-muted-foreground bg-muted/40 rounded-lg p-2">{r.message}</p>}
                {r.status !== "approved" && (
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => decide(r, "approved")} disabled={busy === r.id} className="flex items-center gap-1">
                      {busy === r.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />} Approuver
                    </Button>
                    {r.status !== "rejected" && (
                      <Button size="sm" variant="outline" onClick={() => decide(r, "rejected")} disabled={busy === r.id} className="flex items-center gap-1">
                        <X className="w-3.5 h-3.5" /> Refuser
                      </Button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}