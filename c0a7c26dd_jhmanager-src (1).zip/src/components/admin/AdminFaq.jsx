import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Sparkles, Loader2, CheckCircle2, Tag, Users } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { formatCurrency } from "@/lib/format";

export default function AdminFaq() {
  const { toast } = useToast();
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [triaging, setTriaging] = useState(false);
  const [answering, setAnswering] = useState(null);

  const load = async () => {
    try {
      const list = await base44.entities.FaqQuestion.list("-created_date", 200);
      setQuestions(list || []);
    } catch { setQuestions([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const triage = async () => {
    setTriaging(true);
    try {
      const res = await base44.functions.invoke('triageFaq', {});
      toast({ title: res?.message || "Tri IA terminé", description: `${res?.grouped || 0} question(s) regroupée(s).` });
      load();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    } finally { setTriaging(false); }
  };

  const save = async (q) => {
    setAnswering(q.id);
    try {
      await base44.entities.FaqQuestion.update(q.id, {
        answer: q.answer || "",
        is_published: !!q.is_published,
        status: q.answer ? "traite" : "en_cours",
      });
      toast({ title: "Réponse enregistrée" });
      load();
    } catch (e) {
      toast({ title: "Erreur", description: e?.message, variant: "destructive" });
    } finally { setAnswering(null); }
  };

  const update = (id, patch) => setQuestions((prev) => prev.map((q) => (q.id === id ? { ...q, ...patch } : q)));

  // Regrouper par group_label
  const groups = {};
  questions.forEach((q) => {
    const key = q.group_label || "Non triées";
    if (!groups[key]) groups[key] = [];
    groups[key].push(q);
  });

  if (loading) {
    return (
      <div className="bg-card border border-border rounded-2xl p-5 flex items-center justify-center h-40">
        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-accent" />
          <h2 className="font-display text-lg">FAQ reçues ({questions.length})</h2>
        </div>
        <Button onClick={triage} disabled={triaging} variant="outline" size="sm">
          {triaging ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          Trier avec l'IA
        </Button>
      </div>

      {questions.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-6">Aucune question pour l'instant.</p>
      ) : (
        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
          {Object.entries(groups).map(([label, items]) => (
            <div key={label} className="rounded-xl border border-border p-3">
              <div className="flex items-center gap-2 mb-2">
                <Tag className="w-3.5 h-3.5 text-accent" />
                <span className="text-sm font-medium">{label}</span>
                <span className="text-xs text-muted-foreground">· {items.length}</span>
              </div>
              <div className="space-y-3">
                {items.map((q) => (
                  <div key={q.id} className="rounded-lg bg-muted/40 p-3">
                    <p className="text-sm font-medium">{q.question}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {q.category} · {new Date(q.created_date).toLocaleDateString("fr-FR")}
                      {q.status === "traite" && <CheckCircle2 className="inline w-3 h-3 ml-1 text-primary" />}
                    </p>
                    <Textarea
                      value={q.answer || ""}
                      onChange={(e) => update(q.id, { answer: e.target.value })}
                      placeholder="Réponse / synthèse…"
                      rows={2}
                      className="mt-2 bg-background text-sm"
                    />
                    <div className="flex items-center justify-between mt-2">
                      <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <input
                          type="checkbox"
                          checked={!!q.is_published}
                          onChange={(e) => update(q.id, { is_published: e.target.checked })}
                        />
                        Publier sur l'accueil
                      </label>
                      <Button size="sm" onClick={() => save(q)} disabled={answering === q.id}>
                        {answering === q.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Enregistrer"}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}