import React, { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';
import { ThemeProvider } from '@/lib/ThemeProvider';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Privacy from '@/pages/Privacy';
import Terms from '@/pages/Terms';
import Layout from '@/components/Layout';
import { I18nProvider } from '@/lib/i18n';
import OAuthConsent from '@/pages/OAuthConsent';
import Onboarding from '@/pages/Onboarding';
import Home from '@/pages/Home';
import Finances from '@/pages/Finances';
import Tasks from '@/pages/Tasks';
import Planning from '@/pages/Planning';
import CalendarPage from '@/pages/Calendar';
import Admin from '@/pages/Admin';
import Affiliation from '@/pages/Affiliation';
import NotificationsPage from '@/pages/NotificationsPage';
import Settings from '@/pages/Settings';
import Agents from '@/pages/Agents';
import BusinessDashboard from '@/pages/BusinessDashboard';
import Inventory from '@/pages/Inventory';
import Sales from '@/pages/Sales';
import Personnel from '@/pages/Personnel';
import Companies from '@/pages/Companies';
import Calculators from '@/pages/Calculators';
import Thresholds from '@/pages/Thresholds';
import Clients from '@/pages/Clients';
import Quotes from '@/pages/Quotes';
import Suppliers from '@/pages/Suppliers';
import Taxes from '@/pages/Taxes';
import Loans from '@/pages/Loans';
import Partnerships from '@/pages/Partnerships';
import SuggestionsPage from '@/pages/SuggestionsPage';
import Reporting from '@/pages/Reporting';
import Export from '@/pages/Export';
import Events from '@/pages/Events';
import Categories from '@/pages/Categories';
import Collaborateurs from '@/pages/Collaborateurs';
import Faq from '@/pages/Faq';
import MorningBriefing from '@/pages/MorningBriefing';
import ResubscriptionGate from '@/components/ResubscriptionGate';
import Demo from '@/pages/Demo';

const AuthenticatedApp = () => {
  const { user, isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const [resub, setResub] = useState(null);
  const checkResub = async () => {
    if (!user || user.role === 'admin') { setResub({ blocked: false }); return; }
    try { setResub(await base44.functions.invoke('resubscriptionStatus', {})); }
    catch { setResub({ blocked: false }); }
  };
  useEffect(() => { checkResub(); /* eslint-disable-next-line */ }, [user?.id]);

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Compte supprimé par un admin : réabonnement requis avant tout accès.
  if (user && user.role !== 'admin' && !resub) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }
  if (resub?.blocked) {
    return <ResubscriptionGate status={resub.status} onSubmitted={checkResub} />;
  }

  // Authenticated user with no account type (and not admin) must pick a subscription / account type first.
  const accountType = user?.data?.account_type || user?.account_type;
  const needsOnboarding = !!user && user.role !== "admin" && !accountType;

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/confidentialite" element={<Privacy />} />
      <Route path="/conditions" element={<Terms />} />
      <Route path="/oauth-consent" element={<OAuthConsent />} />
      <Route path="/" element={<Home />} />
      <Route path="/demo" element={<Demo />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        {needsOnboarding ? (
          <Route path="/*" element={<Onboarding />} />
        ) : (
          <Route element={<Layout />}>
            <Route path="/finances" element={<Finances />} />
            <Route path="/taches" element={<Tasks />} />
            <Route path="/planning" element={<Planning />} />
            <Route path="/calendrier" element={<CalendarPage />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/affiliation" element={<Affiliation />} />
            <Route path="/notifications" element={<NotificationsPage />} />
            <Route path="/parametres" element={<Settings />} />
            <Route path="/assistants" element={<Agents />} />
            <Route path="/jbm" element={<BusinessDashboard />} />
            <Route path="/jbm/stock" element={<Inventory />} />
            <Route path="/jbm/ventes" element={<Sales />} />
            <Route path="/jbm/personnel" element={<Personnel />} />
            <Route path="/jbm/entreprises" element={<Companies />} />
            <Route path="/calculateurs" element={<Calculators />} />
            <Route path="/seuils" element={<Thresholds />} />
            <Route path="/suggestions" element={<SuggestionsPage />} />
            <Route path="/reporting" element={<Reporting />} />
            <Route path="/exportations" element={<Export />} />
            <Route path="/evenements" element={<Events />} />
            <Route path="/categories" element={<Categories />} />
            <Route path="/collaborateurs" element={<Collaborateurs />} />
            <Route path="/faq" element={<Faq />} />
            <Route path="/resume-matinal" element={<MorningBriefing />} />
            <Route path="/taxes" element={<Taxes scope="jpm" />} />
            <Route path="/emprunts" element={<Loans />} />

            <Route path="/jbm/clients" element={<Clients />} />
            <Route path="/jbm/devis" element={<Quotes />} />
            <Route path="/jbm/prestataires" element={<Suppliers />} />
            <Route path="/jbm/taxes" element={<Taxes scope="jbm" />} />
            <Route path="/jbm/partenariats" element={<Partnerships />} />
          </Route>
        )}
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <ThemeProvider>
        <I18nProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <ScrollToTop />
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </I18nProvider>
      </ThemeProvider>
    </AuthProvider>
  )
}

export default App