// Logique partagée de tri/regroupement des questions FAQ par l'IA.
// Garde les réponses robustes : si l'IA renvoie n'importe quoi, on retombe
// sur un regroupement par mot-clé simple pour ne jamais perdre les questions.

export function triageFaqs(llmResult, fresh) {
  const items = Array.isArray(llmResult?.items) ? llmResult.items : [];
  // Index par question (texte) pour faire correspondre la sortie de l'IA.
  const byText = {};
  items.forEach((it) => {
    if (it && it.question) {
      byText[normalize(it.question)] = it;
    }
  });

  return fresh.map((q) => {
    const match = byText[normalize(q.question)];
    if (match && match.group_key && match.group_label) {
      return {
        id: q.id,
        group_key: slug(match.group_key),
        group_label: String(match.group_label).slice(0, 80),
      };
    }
    // Fallback : regroupement par mot-clé simple.
    return { id: q.id, group_key: keywordGroup(q.question), group_label: keywordLabel(q.question) };
  });
}

function normalize(s) {
  return String(s || '').toLowerCase().trim().replace(/\s+/g, ' ');
}

function slug(s) {
  return String(s || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40) || 'divers';
}

const KEYWORDS = [
  { keys: ['prix', 'tarif', 'combien', 'coût', 'cout', 'abonnement'], key: 'tarif', label: 'Tarif & abonnement' },
  { keys: ['paiement', 'payer', 'airtel', 'moov', 'mobile money', 'transaction'], key: 'paiement', label: 'Paiement Mobile Money' },
  { keys: ['affili', 'parrain', 'commission', 'filleul', 'lien'], key: 'affiliation', label: 'Affiliation & commissions' },
  { keys: ['entreprise', 'jbm', 'stock', 'vente', 'facture'], key: 'jbm', label: 'Espace entreprise (JBM)' },
  { keys: ['personnel', 'jpm', 'budget', 'tache', 'planning'], key: 'jpm', label: 'Espace personnel (JPM)' },
  { keys: ['compte', 'connexion', 'inscript', 'mot de passe', 'email'], key: 'compte', label: 'Compte & connexion' },
];

function keywordGroup(q) {
  const s = String(q || '').toLowerCase();
  for (const k of KEYWORDS) if (k.keys.some((w) => s.includes(w))) return k.key;
  return 'divers';
}
function keywordLabel(q) {
  const s = String(q || '').toLowerCase();
  for (const k of KEYWORDS) if (k.keys.some((w) => s.includes(w))) return k.label;
  return 'Autres questions';
}