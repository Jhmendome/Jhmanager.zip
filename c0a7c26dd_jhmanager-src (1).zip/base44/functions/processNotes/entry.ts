import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const note = String(body.note || '').trim();
    if (!note) return Response.json({ error: 'Note vide' }, { status: 400 });
    const scope = body.scope === 'jbm' ? 'jbm' : 'jpm';
    const companyId = body.company_id ? String(body.company_id) : null;

    const llm = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt:
        'Analyse la note suivante rédigée par un utilisateur au sujet d\'un partenaire ou prestataire. ' +
        'Extrais les éléments actionnables : dépenses (finances), tâches (tâches), activités ou rendez-vous (événements). ' +
        'Pour chaque élément remplis les champs. Les dates doivent être au format ISO (YYYY-MM-DD ou YYYY-MM-DDTHH:mm:ss). ' +
        'Si une information est inconnue, mets null (jamais de texte inventé). Réponds uniquement via le schéma JSON. ' +
        'Note : """' + note + '"""',
      response_json_schema: {
        type: 'object',
        properties: {
          expenses: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                unit_cost: { type: 'number' },
                quantity: { type: 'number' },
                date: { type: 'string' }
              },
              required: ['name']
            }
          },
          tasks: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                start: { type: 'string' },
                end: { type: 'string' },
                duration_minutes: { type: 'number' }
              },
              required: ['title']
            }
          },
          events: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                start: { type: 'string' },
                end: { type: 'string' },
                location: { type: 'string' }
              },
              required: ['title']
            }
          },
          summary: { type: 'string' }
        },
        required: ['expenses', 'tasks', 'events', 'summary']
      }
    });

    const created = { expenses: 0, tasks: 0, events: 0 };

    for (const e of (llm.expenses || [])) {
      try {
        await base44.entities.Expense.create({
          name: e.name,
          unit_cost: e.unit_cost || 0,
          quantity: e.quantity || 1,
          date: e.date || new Date().toISOString().slice(0, 10)
        });
        created.expenses++;
      } catch (err) {
        console.error('Expense create failed:', err.message);
      }
    }
    for (const tk of (llm.tasks || [])) {
      try {
        const start = tk.start || new Date().toISOString();
        const end = tk.end || new Date(new Date(start).getTime() + ((tk.duration_minutes || 60) * 60000)).toISOString();
        await base44.entities.Task.create({ title: tk.title, start, end });
        created.tasks++;
      } catch (err) {
        console.error('Task create failed:', err.message);
      }
    }
    for (const ev of (llm.events || [])) {
      try {
        const start = ev.start || new Date().toISOString();
        const end = ev.end || new Date(new Date(start).getTime() + 3600000).toISOString();
        await base44.entities.Event.create({
          title: ev.title,
          start,
          end,
          location: ev.location || null,
          company_id: scope === 'jbm' ? companyId : null
        });
        created.events++;
      } catch (err) {
        console.error('Event create failed:', err.message);
      }
    }

    return Response.json({ success: true, summary: llm.summary, created });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}