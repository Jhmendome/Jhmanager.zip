import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Non autorisé' }, { status: 401 });

    const userId = user.id;

    // Delete all of the user's own data (service role bypasses RLS for a clean wipe).
    await base44.asServiceRole.entities.Task.deleteMany({ created_by_id: userId });
    await base44.asServiceRole.entities.Expense.deleteMany({ created_by_id: userId });
    await base44.asServiceRole.entities.Preferences.deleteMany({ created_by_id: userId });

    // Verify the data is actually gone.
    const remainingTasks = await base44.asServiceRole.entities.Task.filter({ created_by_id: userId });
    const remainingExpenses = await base44.asServiceRole.entities.Expense.filter({ created_by_id: userId });
    const remainingPrefs = await base44.asServiceRole.entities.Preferences.filter({ created_by_id: userId });

    if (remainingTasks.length || remainingExpenses.length || remainingPrefs.length) {
      return Response.json({
        error: "Certaines données n'ont pas pu être supprimées.",
        remaining: {
          tasks: remainingTasks.length,
          expenses: remainingExpenses.length,
          preferences: remainingPrefs.length,
        },
      }, { status: 500 });
    }

    // Finally, delete the user account itself.
    try {
      await base44.asServiceRole.entities.User.delete(userId);
    } catch (e) {
      // Some deployments restrict user deletion; report clearly.
      return Response.json({
        warning: 'Données supprimées mais le compte utilisateur ne peut pas être supprimé automatiquement.',
        dataDeleted: true,
        userDeleted: false,
      }, { status: 200 });
    }

    return Response.json({ success: true, dataDeleted: true, userDeleted: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}