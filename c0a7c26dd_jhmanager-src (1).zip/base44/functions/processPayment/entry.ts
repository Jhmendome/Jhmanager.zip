import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const PAYMENT_ENDPOINT = 'https://backend-paiement-gabon.onrender.com/api/payments/pay';
const VALID_ACCOUNT_TYPES = ['particulier', 'entreprise'];
const VALID_PROVIDERS = ['airtel', 'moov'];
const TEST_EMAILS = ['jhmendome@gmail.com', 'obiangmbarosly4@gmail.com'];

// --- Vérification du statut de la transaction (défensive) ---
// Le contrat exact du backend externe n'étant pas connu, on inspecte la réponse
// de /pay puis on tente, si une référence est disponible, d'interroger des routes
// de vérification candidates. On ne bloque QUE les échecs explicites ; en cas
// d'ambiguïté (route absente ou statut pending non résolu), on conserve le
// comportement actuel (activation) pour ne pas pénaliser les paiements valides.
const SUCCESS_KW = ['success', 'succeeded', 'successful', 'completed', 'complete', 'paid', 'confirmed', 'ok', 'settled'];
const PENDING_KW = ['pending', 'processing', 'in_progress', 'waiting', 'initiated', 'submitted', 'ongoing', 'en_attente'];
const FAILED_KW = ['failed', 'error', 'declined', 'rejected', 'cancelled', 'canceled', 'insufficient', 'timeout', 'expired', 'abandoned', 'echoue'];

const STATUS_ROUTE_FNS = [
  (r) => `/api/payments/status?reference=${encodeURIComponent(r)}`,
  (r) => `/api/payments/verify?reference=${encodeURIComponent(r)}`,
  (r) => `/api/payments/check?reference=${encodeURIComponent(r)}`,
  (r) => `/api/payments/transaction/${encodeURIComponent(r)}`,
  (r) => `/api/payments/${encodeURIComponent(r)}`,
];

function extractStatusText(obj) {
  if (!obj || typeof obj !== 'object') return '';
  const vals = [];
  for (const k of ['status', 'state', 'transaction_status', 'payment_status', 'result', 'code', 'message']) {
    if (obj[k] != null) vals.push(String(obj[k]));
  }
  for (const k of ['data', 'transaction', 'payment', 'response', 'result']) {
    if (obj[k] && typeof obj[k] === 'object') {
      for (const sk of ['status', 'state', 'payment_status', 'transaction_status']) {
        if (obj[k][sk] != null) vals.push(String(obj[k][sk]));
      }
    }
  }
  return vals.join(' ').toLowerCase();
}

function classifyStatus(text) {
  if (!text) return 'unknown';
  if (FAILED_KW.some((k) => text.includes(k))) return 'failed';
  if (PENDING_KW.some((k) => text.includes(k))) return 'pending';
  if (SUCCESS_KW.some((k) => text.includes(k))) return 'confirmed';
  return 'unknown';
}

async function verifyPaymentStatus(reference, initialData) {
  const initial = classifyStatus(extractStatusText(initialData));
  if (initial === 'confirmed') return { confirmed: true, failed: false, source: 'pay_response', note: 'Succès détecté dans la réponse /pay' };
  if (initial === 'failed') return { confirmed: false, failed: true, source: 'pay_response', note: 'Échec détecté dans la réponse /pay' };
  if (!reference) return { confirmed: false, failed: false, source: 'none', note: 'Aucune référence pour vérifier le statut' };

  const base = PAYMENT_ENDPOINT.replace(/\/api\/payments\/pay$/, '');
  for (let attempt = 0; attempt < 4; attempt++) {
    if (attempt > 0) await new Promise((res) => setTimeout(res, 2500));
    let anyRouteResponded = false; // une route qui n'est pas un 404/erreur
    for (const routeFn of STATUS_ROUTE_FNS) {
      try {
        const r = await fetch(base + routeFn(reference), { method: 'GET', headers: { Accept: 'application/json' } });
        if (r.status === 404) continue; // route inexistante : on essaie la suivante
        if (!r.ok) { anyRouteResponded = true; continue; }
        anyRouteResponded = true;
        const j = await r.json().catch(() => null);
        const cls = classifyStatus(extractStatusText(j));
        if (cls === 'confirmed') return { confirmed: true, failed: false, source: 'status_route', note: 'Succès confirmé par la route de vérification' };
        if (cls === 'failed') return { confirmed: false, failed: true, source: 'status_route', note: 'Échec confirmé par la route de vérification' };
        // pending ou unknown : on continue à sonder les autres routes
      } catch {
        // route indisponible ou réponse illisible : on essaie la suivante
      }
    }
    // Si aucune route de statut n'existe (tout en 404/erreur), inutile de
    // re-sonder : on s'arrête immédiatement pour ne pas ralentir le paiement.
    if (!anyRouteResponded) break;
  }
  return { confirmed: false, failed: false, source: 'timeout', note: 'Route de statut indisponible ou statut ambigu — activation conservée par défaut' };
}

function flattenGatewayError(data) {
  if (!data) return 'réponse illisible';
  const cand = [];
  const push = (v) => { if (v != null && v !== '') cand.push(String(v)); };
  push(data.message);
  push(data.error_description);
  push(data.detail);
  if (typeof data.error === 'string') push(data.error);
  else if (data.error && typeof data.error === 'object') {
    push(data.error.error_description);
    push(data.error.message);
    push(data.error.error);
  }
  const txt = cand.filter(Boolean).join(' — ').trim();
  return txt || 'erreur inconnue';
}

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const accountName = String(body.account_name || '').trim();
    const phoneNumber = String(body.phoneNumber || '').trim();
    const provider = String(body.provider || '').trim();
    const accountType = String(body.account_type || '').trim();

    // Pricing is computed server-side to prevent client tampering.
    // Particulier (JPM): flat 5 000 XAF.
    // Entreprise (JBM): 20 000 XAF per managed company (1 = 20 000, 2 = 40 000, 3 = 60 000...).
    const companiesCount =
      accountType === 'entreprise' ? Math.max(1, Math.floor(Number(body.companies_count) || 1)) : 1;
    // Lors d'un ajout d'entreprise (mise à niveau), on ne facture que les entreprises
    // nouvellement couvertes : celles déjà payées (already_covered) ne sont pas re-débitées.
    // Le total de l'abonnement reste 20 000 × nombre d'entreprises couvertes.
    const alreadyCovered =
      accountType === 'entreprise' ? Math.max(0, Math.floor(Number(body.already_covered) || 0)) : 0;
    const billableUnits =
      accountType === 'entreprise' ? Math.max(0, companiesCount - alreadyCovered) : 1;
    let normalAmount;
    if (accountType === 'entreprise') {
      normalAmount = 20000 * billableUnits;
    } else {
      normalAmount = 5000;
    }

    // Affiliation : détermine si l'utilisateur est parrainé et s'il bénéficie de
    // la réduction de 20 % valable les 6 premiers mois.
    const refCode = String(body.referral_code || '').trim();
    let affiliate = null;
    let isReferred = false;
    if (refCode) {
      const affs = await base44.asServiceRole.entities.Affiliate.filter(
        { referral_code: refCode }, null, 1
      );
      affiliate = affs?.[0];
      if (affiliate && affiliate.created_by_id !== user.id) isReferred = true;
    }
    // Même si le code n'est plus en localStorage, on détecte un parrainage antérieur.
    if (!isReferred) {
      const prior = await base44.asServiceRole.entities.Commission.filter(
        { referred_user_email: user.email || '' }, null, 1
      );
      if (prior && prior.length) isReferred = true;
    }

    let discount = false;
    if (isReferred) {
      const priorSubs = await base44.asServiceRole.entities.Subscription.filter(
        { created_by_id: user.id }, 'paid_at', 500
      );
      let firstTs = Date.now();
      for (const s of (priorSubs || [])) {
        const t = new Date(s.paid_at || s.created_date).getTime();
        if (t && t < firstTs) firstTs = t;
      }
      const sixMonthsMs = 6 * 30 * 24 * 60 * 60 * 1000;
      if (!priorSubs?.length || Date.now() - firstTs < sixMonthsMs) discount = true;
    }
    const amount = discount ? Math.round(normalAmount * 0.8) : normalAmount;

    const isTest = body.test === true || String(body.test || '') === 'true';

    if (!VALID_ACCOUNT_TYPES.includes(accountType)) {
      return Response.json({ error: 'Type de compte invalide' }, { status: 400 });
    }

    // Mode test : réservé aux adresses autorisées. Aucun débit Mobile Money réel.
    let data = null;
    if (isTest) {
      const email = (user.email || '').trim().toLowerCase();
      if (!TEST_EMAILS.includes(email)) {
        return Response.json({ error: 'Mode test non autorisé pour ce compte' }, { status: 403 });
      }
      data = { test: true, reference: 'TEST-' + Date.now() };
    } else {
      if (!phoneNumber) {
        return Response.json({ error: 'Numéro de téléphone requis' }, { status: 400 });
      }
      if (!VALID_PROVIDERS.includes(provider)) {
        return Response.json({ error: 'Opérateur invalide' }, { status: 400 });
      }
      // Credentials Airtel transmis à la passerelle (OAuth2 client_credentials).
      // Renseignés via les secrets de l'app : PAYMENT_CLIENT_ID / PAYMENT_CLIENT_SECRET.
      const client_id = process.env.PAYMENT_CLIENT_ID;
      const client_secret = process.env.PAYMENT_CLIENT_SECRET;
      if (!client_id || !client_secret) {
        return Response.json(
          {
            success: false,
            error: 'Service de paiement non configuré : credentials de la passerelle manquants (PAYMENT_CLIENT_ID / PAYMENT_CLIENT_SECRET).',
          },
          { status: 200 }
        );
      }
      const apiRes = await fetch(PAYMENT_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount, phoneNumber, provider, client_id, client_secret }),
      });
      data = await apiRes.json().catch(() => null);
      if (!apiRes.ok) {
        // On renvoie 200 + success:false pour que le frontend affiche la cause
        // réelle (au lieu d'un "Request failed with status code 500" générique).
        return Response.json(
          {
            success: false,
            error: 'Paiement refusé par la passerelle (' + flattenGatewayError(data) + '). Le service Mobile Money n\'est pas correctement configuré.',
            gateway_status: apiRes.status,
            details: data,
          },
          { status: 200 }
        );
      }
    }

    // --- Vérification du statut de la transaction ---
    // En mode test, aucun débit réel : on considère le paiement comme confirmé.
    // En mode réel, on inspecte la réponse et, si possible, une route de statut.
    let verification = { confirmed: true, failed: false, source: 'test', note: 'Mode test — aucun débit réel' };
    if (!isTest) {
      const ref = (data && (data.reference || data.transactionId || data.id || data.paymentId)) || phoneNumber;
      verification = await verifyPaymentStatus(ref, data);
      if (verification.failed) {
        return Response.json(
          { success: false, error: 'Paiement non confirmé par la passerelle', verification, details: data },
          { status: 200 }
        );
      }
    }

    // Record the subscription server-side (service role bypasses RLS) so revenue is trustworthy.
    let subscription = null;
    try {
      subscription = await base44.asServiceRole.entities.Subscription.create({
        account_type: accountType,
        amount,
        companies_count: accountType === 'entreprise' ? companiesCount : 1,
        account_name: accountName || null,
        phone_number: phoneNumber || 'TEST',
        provider: isTest ? (VALID_PROVIDERS.includes(provider) ? provider : 'airtel') : provider,
        status: 'payee',
        paid_at: new Date().toISOString(),
        // La référence passerelle est conservée si présente ; à défaut, on ancre
        // l'identification sur le numéro Mobile Money (unique par compte), qui
        // devient l'identifiant de l'abonnement — les renouvellements restent
        // distincts via l'horodatage (paid_at / created_date).
        reference:
          (data && (data.reference || data.transactionId || data.id || data.paymentId)) || phoneNumber || null,
      });
    } catch (recErr) {
      // Payment succeeded; recording failure must not fail the whole request.
      console.error('Subscription record failed:', recErr.message);
    }

    // Affiliation : 20 % de commission calculés sur le prix NORMAL (non réduit).
    // Le parrain touche toujours 1 000 XAF/mois (particulier) ou 4 000 XAF/mois
    // (entreprise, × nombre d'entreprises), quelle que soit la réduction du filleul.
    try {
      if (affiliate && affiliate.created_by_id !== user.id) {
        const commission = Math.round(normalAmount * 0.2);
        await base44.asServiceRole.entities.Commission.create({
          affiliate_id: affiliate.id,
          affiliate_owner_id: affiliate.created_by_id,
          referred_user_email: user.email || null,
          source_amount: normalAmount,
          amount: commission,
          account_type: accountType,
          paid_at: new Date().toISOString(),
        });
      }
    } catch (affErr) {
      console.error('Affiliation commission failed:', affErr.message);
    }

    return Response.json({ success: true, data, subscription, verification });
  } catch (error) {
    // Erreur interne : on renvoie 200 + success:false pour que le frontend
    // affiche un message lisible au lieu d'un 500 générique masqué par axios.
    return Response.json({ success: false, error: 'Erreur technique lors du paiement : ' + (error && error.message || 'erreur inconnue') }, { status: 200 });
  }
}