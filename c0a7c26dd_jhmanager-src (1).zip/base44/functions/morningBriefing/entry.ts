import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const [prefs, tasks, events, expenses, savings, loans, taxes] = await Promise.all([
      base44.entities.Preferences.list().catch(() => []),
      base44.entities.Task.list("-start", 200).catch(() => []),
      base44.entities.Event.list("-start", 200).catch(() => []),
      base44.entities.Expense.list("-date", 200).catch(() => []),
      base44.entities.SavingsPlan.list("-created_date", 100).catch(() => []),
      base44.entities.Loan.list("-created_date", 100).catch(() => []),
      base44.entities.Tax.list("-created_date", 200).catch(() => []),
    ]);

    const pref = prefs?.[0] || {};
    const currency = pref.currency || 'XAF';
    const reminderDays = Number(pref.reminder_days) || 7;
    const budget = Number(pref.initial_budget) || 0;

    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const horizon = new Date(now.getTime() + reminderDays * 86400000);

    const expenseAmt = (e) => (Number(e.quantity) || 1) * (Number(e.unit_cost) || 0);
    const totalExpense = (expenses || []).reduce((s, e) => s + expenseAmt(e), 0);
    const depensesJour = (expenses || []).filter((e) => e.date === todayStr).reduce((s, e) => s + expenseAmt(e), 0);

    const tasksToday = (tasks || []).filter((t) => (t.start || "").slice(0, 10) === todayStr && t.status !== "terminee");
    const tasksUpcoming = (tasks || []).filter((t) => {
      const d = (t.start || "").slice(0, 10);
      return d > todayStr && new Date(t.start) <= horizon && t.status !== "terminee";
    });
    const eventsToday = (events || []).filter((ev) => (ev.start || "").slice(0, 10) === todayStr);
    const eventsUpcoming = (events || []).filter((ev) => {
      const d = (ev.start || "").slice(0, 10);
      return d > todayStr && new Date(ev.start) <= horizon;
    });

    const loanBurden = (loans || []).filter((l) => l.status === "en_cours").reduce((s, l) => s + (Number(l.monthly_payment) || 0), 0);
    const taxBurden = (taxes || []).filter((t) => t.scope === "jpm").reduce((s, t) => s + (Number(t.amount) || 0), 0);
    const reste = budget - totalExpense - loanBurden - taxBurden;
    const activePlans = (savings || []).filter((p) => p.status !== "archive").length;

    const kpis = {
      budget, totalExpense, reste, depensesJour, loanBurden, taxBurden, currency,
      tasksToday: tasksToday.length, tasksUpcoming: tasksUpcoming.length,
      eventsToday: eventsToday.length, eventsUpcoming: eventsUpcoming.length,
      activePlans,
    };

    let message = '';
    try {
      const prompt = `Tu es le Briefing Quotidien de JH Manager. Voici le résumé du jour pour un utilisateur. Rédige une synthèse courte, structurée et motivante en français (max 180 mots), avec des puces.\nDonnées:\n- Tâches du jour: ${tasksToday.length}\n- Tâches à venir (${reminderDays}j): ${tasksUpcoming.length}\n- Événements du jour: ${eventsToday.length}\n- Dépenses du jour: ${depensesJour} ${currency}\n- Total dépenses: ${totalExpense} ${currency}\n- Budget: ${budget} ${currency}\n- Reste: ${reste} ${currency}`;
      const res = await base44.asServiceRole.integrations.Core.InvokeLLM({ prompt });
      message = typeof res === 'string' ? res : (res?.text || res?.response || JSON.stringify(res));
    } catch { /* ignore */ }

    return Response.json({
      date: todayStr,
      greeting: `Bonjour ${user.full_name || ''}`.trim(),
      kpis,
      message,
      tasksToday: tasksToday.map((t) => ({ title: t.title, priority: t.priority, start: t.start })),
      tasksUpcoming: tasksUpcoming.slice(0, 10).map((t) => ({ title: t.title, priority: t.priority, start: t.start })),
      eventsToday: eventsToday.map((ev) => ({ title: ev.title, start: ev.start, location: ev.location })),
      eventsUpcoming: eventsUpcoming.slice(0, 10).map((ev) => ({ title: ev.title, start: ev.start })),
      recentExpenses: (expenses || []).slice(0, 6).map((e) => ({ name: e.name, amount: expenseAmt(e), date: e.date })),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}