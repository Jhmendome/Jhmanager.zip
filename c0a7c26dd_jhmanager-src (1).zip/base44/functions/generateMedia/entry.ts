import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

// Génère un fichier multimédia (image, audio ou vidéo) via les intégrations Core.
// Exposé comme outil aux agents IA pour qu'ils produisent et partagent des médias.
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const kind = String(body?.kind || 'image').toLowerCase();
    const prompt = String(body?.prompt || '').slice(0, 1200);
    if (!prompt) return Response.json({ error: 'Prompt requis' }, { status: 400 });

    let res;
    if (kind === 'image') {
      res = await base44.asServiceRole.integrations.Core.GenerateImage({ prompt });
      return Response.json({ kind: 'image', file_url: res?.url, prompt });
    }
    if (kind === 'audio') {
      const text = String(body?.text || prompt).slice(0, 5000);
      const voice = body?.voice || 'river';
      res = await base44.asServiceRole.integrations.Core.GenerateSpeech({ text, voice });
      return Response.json({ kind: 'audio', file_url: res?.url, prompt });
    }
    if (kind === 'video') {
      const aspect_ratio = body?.aspect_ratio === '9:16' ? '9:16' : '16:9';
      res = await base44.asServiceRole.integrations.Core.GenerateVideo({ prompt, aspect_ratio, generate_audio: true });
      return Response.json({ kind: 'video', file_url: res?.url, prompt });
    }
    return Response.json({ error: "kind inconnu (image|audio|video)" }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}