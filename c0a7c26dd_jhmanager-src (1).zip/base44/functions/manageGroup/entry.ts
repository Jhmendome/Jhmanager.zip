import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

// Gestion des membres d'un groupe (actions nécessitant un contournement de RLS).
// - accept_invite : l'invité s'ajoute au groupe et marque l'invitation acceptée
// - remove_member : un admin retire un membre, OU un membre se retire lui-même
// - add_member : un admin ajoute directement un membre
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const action = body.action;
    const Group = base44.asServiceRole.entities.Group;

    if (action === 'accept_invite') {
      const invite = await base44.entities.GroupInvite.get(body.invite_id);
      if (!invite) return Response.json({ error: 'Invitation introuvable' }, { status: 404 });
      if (invite.to_user_id !== user.id) return Response.json({ error: 'Non autorisé' }, { status: 403 });
      if (invite.status !== 'pending') return Response.json({ error: 'Invitation déjà traitée' }, { status: 400 });
      const group = await Group.get(invite.group_id);
      if (group) {
        const members = group.members || [];
        if (!members.includes(user.id)) {
          await Group.update(group.id, { members: [...members, user.id] });
        }
      }
      await base44.entities.GroupInvite.update(invite.id, { status: 'accepted' });
      return Response.json({ ok: true });
    }

    if (action === 'remove_member') {
      const group = await base44.entities.Group.get(body.group_id);
      if (!group) return Response.json({ error: 'Groupe introuvable' }, { status: 404 });
      const target = body.target_id;
      if (!target) return Response.json({ error: 'target_id requis' }, { status: 400 });
      const isSelf = target === user.id;
      const isAdmin = group.created_by_id === user.id || (group.admins || []).includes(user.id);
      if (!isSelf && !isAdmin) return Response.json({ error: 'Non autorisé' }, { status: 403 });
      await Group.update(body.group_id, {
        members: (group.members || []).filter((m) => m !== target),
        admins: (group.admins || []).filter((a) => a !== target),
        allowed_writers: (group.allowed_writers || []).filter((a) => a !== target),
        allowed_media: (group.allowed_media || []).filter((a) => a !== target),
      });
      return Response.json({ ok: true });
    }

    if (action === 'add_member') {
      const group = await base44.entities.Group.get(body.group_id);
      if (!group) return Response.json({ error: 'Groupe introuvable' }, { status: 404 });
      const isAdmin = group.created_by_id === user.id || (group.admins || []).includes(user.id);
      if (!isAdmin) return Response.json({ error: 'Non autorisé' }, { status: 403 });
      const members = group.members || [];
      if (!members.includes(body.user_id)) {
        await Group.update(body.group_id, { members: [...members, body.user_id] });
      }
      return Response.json({ ok: true });
    }

    return Response.json({ error: 'Action inconnue' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}