import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const APP_URL = 'https://jhmanager.base44.app';

const REASON_LABELS = {
  spam: 'Spam',
  harcelement: 'Harcèlement',
  contenu_inapproprie: 'Contenu inapproprié',
  arnaque: 'Arnaque',
  usurpation: 'Usurpation',
  autre: 'Autre',
};

function esc(s) {
  return (s == null ? '' : String(s)).replace(/[&<>"]/g, (c) => ({ '&': '&', '<': '<', '>': '>', '"': '"' }[c]));
}

function link(label, path) {
  return `<a href="${APP_URL}${path}" style="background:#2f6b54;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;display:inline-block;margin-top:12px">${label}</a>`;
}

function wrap(title, inner) {
  return `<div style="font-family:Inter,Arial,sans-serif;color:#1a2e2a;max-width:560px;margin:auto"><h2 style="color:#2f6b54">${title}</h2>${inner}<p style="color:#6b7280;font-size:12px;margin-top:24px">Notification automatique JH Manager.</p></div>`;
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json().catch(() => ({}));
    const type = body?.event_type;
    const recordId = body?.record_id;
    if (!type || !recordId) return Response.json({ sent: false, reason: 'missing_args' });

    const get = async (name) => {
      try { return await base44.asServiceRole.entities[name].get(recordId); }
      catch { return null; }
    };
    const allUsers = async () => {
      try { return await base44.asServiceRole.entities.User.list(); }
      catch { return []; }
    };
    const prefsEnabled = async (userId) => {
      try {
        const p = await base44.asServiceRole.entities.Preferences.filter({ created_by_id: userId });
        return p?.[0]?.notifications_enabled !== false;
      } catch { return true; }
    };
    const send = async (to, subject, html) => {
      if (!to) return false;
      try { await base44.asServiceRole.integrations.Core.SendEmail({ to, subject, html }); return true; }
      catch { return false; }
    };
    const displayName = async (userId) => {
      try {
        const c = await base44.asServiceRole.entities.Collaborator.filter({ created_by_id: userId });
        return c?.[0]?.display_name || '';
      } catch { return ''; }
    };

    // 1) Demande de collaboration reçue
    if (type === 'collab_request') {
      const r = await get('CollaborationRequest');
      if (!r) return Response.json({ sent: false });
      const users = await allUsers();
      const toUser = users.find((u) => u.id === r.to_user_id);
      if (!toUser || !(await prefsEnabled(toUser.id))) return Response.json({ sent: false, reason: 'disabled' });
      const fromName = (await displayName(r.created_by_id)) || 'Un utilisateur';
      const ok = await send(toUser.email, 'JH Manager — Nouvelle demande de collaboration',
        wrap('Nouvelle demande de collaboration',
          `<p><strong>${esc(fromName)}</strong> souhaite collaborer avec vous.</p>${link('Voir la demande', '/collaborateurs')}`));
      return Response.json({ sent: ok, to: toUser.email });
    }

    // 2) Message reçu
    if (type === 'message') {
      const m = await get('Message');
      if (!m) return Response.json({ sent: false });
      const users = await allUsers();
      const senderName = (await displayName(m.created_by_id)) || users.find((u) => u.id === m.created_by_id)?.full_name || 'Un utilisateur';
      const recipients = (m.participants || []).filter((id) => id !== m.created_by_id);
      let count = 0;
      for (const rid of recipients) {
        const u = users.find((x) => x.id === rid);
        if (!u || !(await prefsEnabled(u.id))) continue;
        const preview = m.content ? esc(m.content.slice(0, 300)) : (m.attachment_name ? `Fichier joint : ${esc(m.attachment_name)}` : 'Nouveau message');
        const ok = await send(u.email, 'JH Manager — Nouveau message',
          wrap(`Nouveau message de ${esc(senderName)}`, `<p>${preview}</p>${link('Ouvrir la conversation', '/collaborateurs')}`));
        if (ok) count++;
      }
      return Response.json({ sent: count > 0, to: count });
    }

    // 3) Alertes admin : question FAQ, suggestion, signalement
    if (type === 'faq' || type === 'suggestion' || type === 'report') {
      const map = { faq: 'FaqQuestion', suggestion: 'Suggestion', report: 'Report' };
      const rec = await get(map[type]);
      if (!rec) return Response.json({ sent: false });
      const users = await allUsers();
      const admins = (users || []).filter((u) => u.role === 'admin');

      let subject, inner;
      if (type === 'faq') {
        subject = 'JH Manager — Nouvelle question FAQ';
        inner = `<p><strong>${esc(rec.question)}</strong></p><p style="color:#6b7280">Catégorie : ${esc(rec.category || '-')}</p>`;
      } else if (type === 'suggestion') {
        subject = 'JH Manager — Nouvelle suggestion';
        inner = `<p><strong>${esc(rec.content)}</strong></p><p style="color:#6b7280">Catégorie : ${esc(rec.category || '-')}</p>`;
      } else {
        subject = 'JH Manager — Nouveau signalement';
        const kind = rec.target_type === 'group' ? 'Groupe' : 'Utilisateur';
        inner = `<p><strong>${esc(rec.target_name || 'Cible inconnue')}</strong> (${kind})</p><p>Raison : ${esc(REASON_LABELS[rec.reason] || rec.reason || '-')}</p>${rec.custom_reason ? `<p>Détails : ${esc(rec.custom_reason)}</p>` : ''}`;
      }
      const html = wrap(subject, inner + link('Ouvrir le tableau de bord', '/admin'));

      let count = 0;
      for (const a of admins) {
        if (!(await prefsEnabled(a.id))) continue;
        if (await send(a.email, subject, html)) count++;
      }
      return Response.json({ sent: count > 0, to: count });
    }

    return Response.json({ sent: false, reason: 'unknown_type' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}