import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Non autorisé' }, { status: 401 });

    const email = (user.email || '').toLowerCase().trim();
    if (!email) return Response.json({ blocked: false, status: 'active' });

    const deleted = await base44.asServiceRole.entities.DeletedAccount.filter({ email });
    if (!deleted || deleted.length === 0) {
      return Response.json({ blocked: false, status: 'active' });
    }

    const reqs = await base44.asServiceRole.entities.ReSubscriptionRequest.filter({ email }, '-created_date', 1);
    const latest = (reqs && reqs[0]) || null;
    const status = latest?.status || 'none';
    const blocked = status !== 'approved';

    return Response.json({
      blocked,
      status,
      requestId: latest?.id || null,
      message: latest?.message || '',
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}