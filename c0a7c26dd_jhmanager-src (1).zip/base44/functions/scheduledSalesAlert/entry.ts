import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';

const APP_URL = 'https://jhmanager.base44.app';

function esc(s) {
  return (s == null ? '' : String(s)).replace(/[&<>"]/g, (c) => ({ '&': '&', '<': '<', '>': '>', '"': '"' }[c]));
}

function fmtDate(d) {
  return new Date(d).toLocaleDateString('fr-FR');
}

function wrap(title, inner) {
  return `<div style="font-family:Inter,Arial,sans-serif;color:#1a2e2a;max-width:560px;margin:auto"><h2 style="color:#2f6b54">${title}</h2>${inner}<p style="color:#6b7280;font-size:12px;margin-top:24px">Rappel automatique JH Manager — ventes programmées.</p></div>`;
}

// Rappel J-1 et jour J pour les ventes programmées (status en_attente + scheduled).
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const sales = await base44.asServiceRole.entities.Sale.list("-date", 2000);
    const users = await base44.asServiceRole.entities.User.list();

    const todayStr = new Date().toISOString().slice(0, 10);
    const tomorrow = new Date(Date.now() + 86400000);
    const tomorrowStr = tomorrow.toISOString().slice(0, 10);

    const upcoming = (sales || []).filter((s) =>
      s.scheduled && s.status === "en_attente" && (s.date === todayStr || s.date === tomorrowStr)
    );

    // Group by owner
    const byOwner = {};
    for (const s of upcoming) {
      const k = s.created_by_id;
      if (!k) continue;
      if (!byOwner[k]) byOwner[k] = [];
      byOwner[k].push(s);
    }

    let sent = 0;
    for (const [ownerId, items] of Object.entries(byOwner)) {
      const u = users.find((x) => x.id === ownerId);
      if (!u || !u.email) continue;
      try {
        const prefs = await base44.asServiceRole.entities.Preferences.filter({ created_by_id: ownerId });
        if (prefs?.[0]?.notifications_enabled === false) continue;
      } catch { /* ignore */ }

      const rows = items.map((s) => {
        const when = s.date === todayStr ? "Aujourd'hui" : "Demain";
        const total = (Number(s.quantity) || 0) * (Number(s.unit_price) || 0);
        return `<tr><td style="padding:6px 8px">${esc(when)}</td><td style="padding:6px 8px">${esc(s.item_name)}</td><td style="padding:6px 8px">${esc(s.customer_name || '-')}</td><td style="padding:6px 8px;text-align:right">${Number(s.quantity) || 0} × ${Number(s.unit_price) || 0} = ${total}</td></tr>`;
      }).join("");
      const html = wrap("Rappel : ventes programmées",
        `<p>Voici les ventes programmées à venir :</p>` +
        `<table style="border-collapse:collapse;width:100%;font-size:13px"><thead><tr style="background:#eef5f1"><th style="padding:6px 8px;text-align:left">Quand</th><th style="padding:6px 8px;text-align:left">Article</th><th style="padding:6px 8px;text-align:left">Client</th><th style="padding:6px 8px;text-align:right">Montant</th></tr></thead><tbody>${rows}</tbody></table>` +
        `<p style="margin-top:12px"><a href="${APP_URL}/jbm/ventes" style="background:#2f6b54;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none;display:inline-block">Voir les ventes</a></p>`
      );
      try {
        await base44.asServiceRole.integrations.Core.SendEmail({
          to: u.email,
          subject: "JH Manager — Rappel de ventes programmées",
          html,
        });
        sent++;
      } catch { /* ignore per-user failure */ }
    }

    return Response.json({ sent, checked: upcoming.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}