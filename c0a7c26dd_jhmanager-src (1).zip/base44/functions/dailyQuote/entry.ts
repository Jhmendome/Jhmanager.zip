import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const space = body?.space || "jpm";

    const domains = {
      jpm: "la gestion personnelle (budget, dépenses, tâches, planning, calendrier)",
      jbm: "la gestion d'entreprise (ventes, stock, personnel, facturation, clients, partenariats)",
      ecole: "la gestion d'un établissement scolaire (classes, étudiants, matières, notes, pédagogie)"
    };
    const domaine = domains[space] || domains.jpm;

    const prompt = `Tu es un coach bienveillant pour un abonné d'une app de gestion au Gabon. Donne UN conseil pratique du jour, en français, lié à ${domaine}. Le conseil doit aider à la fois dans l'usage de l'application ET dans sa vie active/professionnelle, en restant sur ces sujets. Une seule phrase, max 28 mots, directe et actionnable. Réponds uniquement par le conseil, sans guillemets ni explication.`;
    const res = await base44.asServiceRole.integrations.Core.InvokeLLM({ prompt, model: "gpt_5_mini" });
    const quote = typeof res === "string" ? res : (res?.text || res?.content || "");
    return Response.json({ quote });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}