import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const domain = body?.domain || "finances";

    let columns = [], rows = [], filename = "rapport";
    const cell = (c) => { const s = String(c ?? ""); return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };

    if (domain === "finances") {
      const exp = await base44.entities.Expense.list("-date", 1000);
      columns = ["name", "category", "quantity", "unit_cost", "date"];
      rows = (exp || []).map((e) => [e.name || "", e.category || "", Number(e.quantity) || 0, Number(e.unit_cost) || 0, e.date ? e.date.slice(0, 10) : ""]);
      filename = "depenses";
    } else if (domain === "stock") {
      const p = await base44.entities.Product.list("-created_date", 1000);
      columns = ["name", "sku", "category", "quantity", "unit_cost", "sale_price"];
      rows = (p || []).map((x) => [x.name || "", x.sku || "", x.category || "", Number(x.quantity) || 0, Number(x.unit_cost) || 0, Number(x.sale_price) || 0]);
      filename = "stock";
    } else if (domain === "ventes") {
      const s = await base44.entities.Sale.list("-date", 1000);
      columns = ["item_name", "customer_name", "quantity", "unit_price", "date", "status"];
      rows = (s || []).map((x) => [x.item_name || "", x.customer_name || "", Number(x.quantity) || 0, Number(x.unit_price) || 0, x.date ? x.date.slice(0, 10) : "", x.status || ""]);
      filename = "ventes";
    } else if (domain === "taches") {
      const t = await base44.entities.Task.list("-start", 1000);
      columns = ["title", "status", "priority", "start", "end"];
      rows = (t || []).map((x) => [x.title || "", x.status || "", x.priority || "", x.start ? x.start.slice(0, 10) : "", x.end ? x.end.slice(0, 10) : ""]);
      filename = "taches";
    } else {
      return Response.json({ error: "Domaine inconnu" }, { status: 400 });
    }

    const csv = "\uFEFF" + columns.join(";") + "\n" + rows.map((r) => r.map(cell).join(";")).join("\n");
    const stamp = new Date().toISOString().slice(0, 10);
    const fname = `${filename}_${stamp}.csv`;
    const file = new File([csv], fname, { type: "text/csv;charset=utf-8;" });
    const res = await base44.asServiceRole.integrations.Core.UploadPublicFile({ file });
    return Response.json({ file_url: res?.file_url, filename: fname });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}