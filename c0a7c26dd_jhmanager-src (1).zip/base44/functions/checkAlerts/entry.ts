import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const [thresholds, prefs, exp, prod, inv, tsk, notifs] = await Promise.all([
      base44.entities.Threshold.list("-created_date", 50),
      base44.entities.Preferences.list(),
      base44.entities.Expense.list("-date", 1000),
      base44.entities.Product.list("-created_date", 1000),
      base44.entities.Invoice.list("-issue_date", 1000),
      base44.entities.Task.list("-start", 1000),
      base44.entities.Notification.list("-created_date", 200),
    ]);

    const budget = (prefs?.[0]?.initial_budget || 0) - (exp || []).reduce((s, e) => s + (Number(e.quantity) || 0) * (Number(e.unit_cost) || 0), 0);
    const stock = (prod || []).reduce((s, p) => s + (Number(p.quantity) || 0) * (Number(p.unit_cost) || 0), 0);
    const invoices = (inv || []).filter((i) => i.status !== "payee").reduce((s, i) => s + (Number(i.amount) || 0), 0);
    const now = new Date();
    const tasks = (tsk || []).filter((x) => x.status !== "terminee" && x.end && new Date(x.end) < now).length;

    const today = new Date().toISOString().slice(0, 10);
    const defs = [
      { domain: "budget", value: budget, direction: "low", label: "Budget restant", money: true },
      { domain: "stock", value: stock, direction: "low", label: "Valeur du stock", money: true },
      { domain: "invoices", value: invoices, direction: "high", label: "Factures impayées", money: true },
      { domain: "tasks", value: tasks, direction: "high", label: "Tâches en retard", money: false },
    ];

    const toCreate = [];
    for (const d of defs) {
      const th = (thresholds || []).find((x) => x.domain === d.domain);
      if (!th) continue;
      const v = Number(d.value) || 0;
      const med = Number(th.medium_value) || 0;
      const crit = Number(th.critical_value) || 0;
      let level = null;
      if (d.direction === "low") {
        if (v <= crit) level = "critique";
        else if (v <= med) level = "moyen";
      } else {
        if (v >= crit) level = "critique";
        else if (v >= med) level = "moyen";
      }
      if (!level) continue;
      const prefix = `Alerte ${level} : ${d.label}`;
      const exists = (notifs || []).some((n) => (n.title || "").startsWith(prefix) && (n.created_date || "").slice(0, 10) === today);
      if (exists) continue;
      const disp = d.money ? `${Math.round(v).toLocaleString("fr-FR")} XAF` : `${v}`;
      toCreate.push({
        title: prefix,
        message: `${d.label} : ${disp} — seuil ${level} atteint. Consultez la section concernée pour agir.`,
        type: "rappel",
        source: "auto",
        read: false,
        enabled: true,
      });
    }

    let created = [];
    if (toCreate.length) created = await base44.entities.Notification.bulkCreate(toCreate);
    return Response.json({ created: created || [], count: (created || []).length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}