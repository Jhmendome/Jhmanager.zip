import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

// Rupture d'une collaboration 1-à-1.
// - supprime la collaboration
// - retire automatiquement l'ex-collaborateur des groupes dont l'autre est créateur
//   (dans les deux sens : si je suis créateur du groupe → je retire l'autre ;
//    si l'autre est créateur du groupe → je m'en retire)
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const collaborationId = body.collaboration_id;
    if (!collaborationId) return Response.json({ error: 'collaboration_id requis' }, { status: 400 });

    const collab = await base44.entities.Collaboration.get(collaborationId);
    if (!collab) return Response.json({ error: 'Collaboration introuvable' }, { status: 404 });

    const members = collab.members || [];
    if (!members.includes(user.id)) {
      return Response.json({ error: 'Non autorisé' }, { status: 403 });
    }
    const otherId = members.find((m) => m !== user.id);

    // Suppression de la collaboration (l'utilisateur est membre, donc autorisé)
    await base44.entities.Collaboration.delete(collaborationId);

    // Retrait automatique dans les groupes communs (lecture limitée par RLS aux groupes dont je suis membre)
    if (otherId) {
      const groups = await base44.entities.Group.list();
      for (const g of groups) {
        const gm = g.members || [];
        const creator = g.created_by_id;
        const toRemove = creator === user.id ? otherId : (creator === otherId ? user.id : null);
        if (toRemove && gm.includes(toRemove)) {
          const patch = {
            members: gm.filter((m) => m !== toRemove),
            admins: (g.admins || []).filter((a) => a !== toRemove),
            allowed_writers: (g.allowed_writers || []).filter((a) => a !== toRemove),
            allowed_media: (g.allowed_media || []).filter((a) => a !== toRemove),
          };
          // Mise à jour via service role : garantit le retrait même si le créateur est l'autre
          await base44.asServiceRole.entities.Group.update(g.id, patch);
        }
      }
    }

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}