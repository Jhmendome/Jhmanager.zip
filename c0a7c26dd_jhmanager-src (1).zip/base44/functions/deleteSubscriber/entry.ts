import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

// Entités appartenant à l'utilisateur dont on efface les enregistrements.
const USER_ENTITIES = [
  'Task', 'Expense', 'Preferences', 'Tax', 'Loan', 'LoanPayment', 'SavingsPlan',
  'Category', 'Company', 'Collaborator', 'CollaborationRequest', 'Collaboration',
  'Group', 'GroupInvite', 'Message', 'Event', 'Partnership', 'Product', 'Sale',
  'Invoice', 'Client', 'Quote', 'Supplier', 'Employee', 'Notification',
  'Subscription', 'PersonalItem', 'Threshold', 'FaqQuestion', 'Suggestion',
  'Report', 'ReSubscriptionRequest',
];

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const caller = await base44.auth.me();
    if (!caller) return Response.json({ error: 'Non autorisé' }, { status: 401 });
    if (caller.role !== 'admin') return Response.json({ error: 'Réservé aux administrateurs' }, { status: 403 });

    const body = await req.json().catch(() => ({}));
    const targetId = body?.user_id;
    if (!targetId) return Response.json({ error: 'user_id requis' }, { status: 400 });
    if (targetId === caller.id) return Response.json({ error: 'Vous ne pouvez pas supprimer votre propre compte' }, { status: 400 });

    const users = await base44.asServiceRole.entities.User.list();
    const target = (users || []).find((u) => u.id === targetId);
    if (!target) return Response.json({ error: 'Utilisateur introuvable' }, { status: 404 });
    if (target.role === 'admin') return Response.json({ error: 'Impossible de supprimer un administrateur' }, { status: 400 });

    const email = (target.email || '').toLowerCase().trim();
    const reason = (body?.reason || '').toString().slice(0, 500);

    // Efface toutes les données créées par l'abonné (service role = contournement RLS).
    let dataDeleted = 0;
    for (const name of USER_ENTITIES) {
      try {
        const res = await base44.asServiceRole.entities[name].deleteMany({ created_by_id: targetId });
        dataDeleted += res?.deletedCount || 0;
      } catch { /* entité inexistante ou non disponible */ }
    }

    // Tente de supprimer le compte auth lui-même.
    let userDeleted = false;
    try {
      await base44.asServiceRole.entities.User.delete(targetId);
      userDeleted = true;
    } catch { /* certaines plateformes refusent la suppression du User */ }

    // Marque l'email comme supprimé : toute réinscription devra passer par une demande de réabonnement.
    try {
      await base44.asServiceRole.entities.DeletedAccount.deleteMany({ email });
      await base44.asServiceRole.entities.DeletedAccount.create({
        email,
        full_name: target.full_name || '',
        reason,
        deleted_by: caller.id,
      });
    } catch { /* échec non bloquant */ }

    return Response.json({ success: true, dataDeleted, userDeleted, email });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}