import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    // Find the user's latest paid (active) subscription.
    const subs = await base44.asServiceRole.entities.Subscription.filter(
      { created_by_id: user.id, status: 'payee' },
      '-paid_at',
      1
    );
    const sub = subs?.[0];
    if (!sub) {
      return Response.json({ error: 'Aucun abonnement actif' }, { status: 404 });
    }

    await base44.asServiceRole.entities.Subscription.update(sub.id, { status: 'resilie' });
    return Response.json({ success: true, subscriptionId: sub.id });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}