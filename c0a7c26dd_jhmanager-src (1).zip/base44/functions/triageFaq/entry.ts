import { triageFaqs } from "../../shared/faqTriage.ts";

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Forbidden' }, { status: 403 });

    // Charge toutes les questions non triées (sans group_label).
    const all = await base44.asServiceRole.entities.FaqQuestion.list('-created_date', 500);
    const fresh = (all || []).filter((q) => !q.group_label);

    if (!fresh.length) {
      return Response.json({ message: 'Rien à trier', grouped: 0 });
    }

    // Demande à l'IA de regrouper les questions similaires.
    const res = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `Voici des questions posées par les utilisateurs sur une app SaaS (JM : JPM gestion perso, JBM gestion entreprise).
Pour CHAQUE question, attribue un "group_key" court (slug anglais, ex: "price_jbm", "mobile_money_payment", "affiliate_payout")
et un "group_label" clair en français (ex: "Tarif abonnement entreprise", "Paiement Mobile Money").
Regroupe sous le MÊME group_key/group_label les questions qui traitent du même sujet, pour éviter les répétitions.
Réponds en JSON strict conforme au schéma.`,
      response_json_schema: {
        type: 'object',
        properties: {
          items: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                question: { type: 'string' },
                group_key: { type: 'string' },
                group_label: { type: 'string' },
              },
              required: ['question', 'group_key', 'group_label'],
            },
          },
        },
        required: ['items'],
      },
      model: 'gemini_3_8_flash',
    });

    const mapping = triageFaqs(res, fresh);

    let grouped = 0;
    for (const m of mapping) {
      try {
        await base44.asServiceRole.entities.FaqQuestion.update(m.id, {
          group_key: m.group_key,
          group_label: m.group_label,
          status: 'en_cours',
        });
        grouped++;
      } catch (e) { /* ignore single failure */ }
    }

    return Response.json({ message: 'Tri terminé', grouped });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}