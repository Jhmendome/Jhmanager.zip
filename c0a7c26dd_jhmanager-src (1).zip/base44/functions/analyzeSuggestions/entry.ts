import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

// Analyse les suggestions utilisateur et regroupe les suggestions sémantiquement
// équivalentes (dédoublonnage par IA). Renvoie des "idées uniques" avec le nombre
// d'utilisateurs distincts les ayant émises et le pourcentage correspondant.
export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Admin only' }, { status: 403 });

    const suggestions = await base44.asServiceRole.entities.Suggestion.list('-created_date', 1000);
    if (!suggestions || suggestions.length === 0) {
      return Response.json({ success: true, groups: [], totalUsers: 0 });
    }

    const items = suggestions.map((s, i) => ({
      index: i,
      content: String(s.content || '').slice(0, 280),
      category: s.category || 'autre',
      author: s.created_by_id || s.id,
    }));

    const prompt = `Tu es un assistant qui regroupe des suggestions d'utilisateurs.
Voici une liste de suggestions (index, contenu, catégorie). Regroupe en clusters les
suggestions qui expriment la même idée (même amélioration ou correction demandée),
même si formulées différemment. Pour chaque cluster, donne un titre court représentatif
et la liste des index concernés. Réponds UNIQUEMENT au format JSON attendu.

Suggestions:
${JSON.stringify(items.map((x) => ({ index: x.index, content: x.content, category: x.category })))}`;

    const llm = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      model: 'gpt_5_mini',
      response_json_schema: {
        type: 'object',
        properties: {
          groups: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                label: { type: 'string' },
                indices: { type: 'array', items: { type: 'number' } },
              },
              required: ['label', 'indices'],
            },
          },
        },
        required: ['groups'],
      },
    });

    const groupsRaw = (llm && llm.groups) || (Array.isArray(llm) ? llm : []);

    const totalUsers = new Set(items.map((x) => x.author)).size || 1;
    const groups = groupsRaw
      .map((grp) => {
        const idxs = Array.isArray(grp.indices) ? grp.indices : [];
        const members = idxs
          .map((i) => items.find((x) => x.index === i))
          .filter(Boolean);
        const distinctAuthors = new Set(members.map((m) => m.author)).size;
        return {
          label: String(grp.label || '').slice(0, 140),
          occurrences: members.length,
          users: distinctAuthors,
          percentage: Math.round((distinctAuthors / totalUsers) * 1000) / 10,
          category: members[0]?.category || 'autre',
        };
      })
      .filter((g) => g.users > 0)
      .sort((a, b) => b.users - a.users);

    return Response.json({ success: true, groups, totalUsers });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}