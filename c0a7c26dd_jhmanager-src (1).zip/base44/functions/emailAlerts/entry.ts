import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';

const URGENT_HORIZON_DAYS = 3;
const BIG_EXPENSE_THRESHOLD = 50000;

function fmtDate(iso) {
  try {
    return new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
  } catch {
    return iso || '';
  }
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const now = new Date();
    const horizon = new Date(now.getTime() + URGENT_HORIZON_DAYS * 24 * 60 * 60 * 1000);
    const since = new Date(now.getTime() - 24 * 60 * 60 * 1000);

    const tasks = await base44.asServiceRole.entities.Task.filter({});
    const urgent = (tasks || []).filter((t) => {
      if (!t.start) return false;
      if (t.status === 'termine' || t.status === 'done') return false;
      const d = new Date(t.start);
      return d <= horizon && (t.priority === 'haute' || d <= now);
    });

    const expenses = await base44.asServiceRole.entities.Expense.filter({});
    const big = (expenses || []).filter((e) => {
      const created = e.created_date ? new Date(e.created_date) : null;
      const amount = Number(e.amount) || 0;
      return created && created >= since && amount >= BIG_EXPENSE_THRESHOLD;
    });

    if (urgent.length === 0 && big.length === 0) {
      return Response.json({ sent: false, reason: 'no_alerts', urgent: 0, big: 0 });
    }

    const users = await base44.asServiceRole.entities.User.list();
    const admin = (users || []).find((u) => u.role === 'admin') || (users || [])[0];
    if (!admin || !admin.email) {
      return Response.json({ sent: false, reason: 'no_recipient' });
    }

    let html = `<div style="font-family:Inter,Arial,sans-serif;color:#1a2e2a">
      <h2 style="color:#2f6b54">JH Manager — Alertes du ${fmtDate(now.toISOString())}</h2>`;
    if (urgent.length) {
      html += `<h3 style="color:#b45309">⏰ ${urgent.length} tâche(s) urgente(s)</h3><ul>`;
      urgent.slice(0, 20).forEach((t) => {
        html += `<li><strong>${t.title || 'Sans titre'}</strong> — échéance ${fmtDate(t.start)}${t.priority === 'haute' ? ' · priorité haute' : ''}</li>`;
      });
      html += `</ul>`;
    }
    if (big.length) {
      html += `<h3 style="color:#b91c1c">💸 ${big.length} dépense(s) importante(s)</h3><ul>`;
      big.slice(0, 20).forEach((e) => {
        html += `<li><strong>${(Number(e.amount) || 0).toLocaleString('fr-FR')} XAF</strong> — ${e.category || 'dépense'}${e.date ? ` · ${fmtDate(e.date)}` : ''}</li>`;
      });
      html += `</ul>`;
    }
    html += `<p style="color:#6b7280;font-size:12px;margin-top:24px">Alerte automatique JH Manager.</p></div>`;

    await base44.asServiceRole.integrations.Core.SendEmail({
      to: admin.email,
      subject: `JH Manager — Alertes du ${fmtDate(now.toISOString())}`,
      html,
    });

    return Response.json({ sent: true, to: admin.email, urgent: urgent.length, big: big.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}